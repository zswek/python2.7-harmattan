from other import *
from sample import *


class MyObjectType(ObjectType):
    pass

class MyOtherObjectType(OtherObjectType):
    value = 10


obj = MyObjectType()
