from MA_version import version as __version__
from MA_version import version_info as __version_info__
from MA import *
