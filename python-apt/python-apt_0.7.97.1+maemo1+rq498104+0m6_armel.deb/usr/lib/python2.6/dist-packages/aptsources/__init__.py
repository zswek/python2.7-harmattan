import apt_pkg

# init the package system
apt_pkg.init()
