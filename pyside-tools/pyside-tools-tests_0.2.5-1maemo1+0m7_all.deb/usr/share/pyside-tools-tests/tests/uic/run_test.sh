#!/bin/sh

# This is a nasty workaround of a CTest limitation
# of setting the environment variables for the test.

# $1: python executable
# $2: python test
# $3: ui file
# $5: pyside-uic path

$5/pyside-uic -o $4/form_tmp.py $3
sed -e '/^#/d' $4/form_tmp.py > $4/form_new.py && rm $4/form_tmp.py
cd $4
$1 $2
