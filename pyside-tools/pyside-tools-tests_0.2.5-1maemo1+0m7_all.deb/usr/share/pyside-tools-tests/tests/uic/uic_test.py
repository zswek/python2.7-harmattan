
import unittest

class TestUICSimple(unittest.TestCase):
    def testSimple(self):
        handle = open("form.py", "r")
        original = open("form_new.py", "r")
        self.assertEqual(handle.readline(), original.readline())

if __name__ == '__main__':
    unittest.main()
