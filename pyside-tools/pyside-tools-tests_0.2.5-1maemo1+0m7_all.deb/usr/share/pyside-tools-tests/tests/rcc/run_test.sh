#!/bin/sh

# This is a nasty workaround of a CTest limitation
# of setting the environment variables for the test.

# $1: python executable
# $2: python test
# $3: qrc file
# $5: pyside-rcc path

export PYTHONPATH=$PYTHONPATH:`pwd`
$5/pyside-rcc -o `basename $3 .qrc`_rc.py $3
cd $4
$1 $2
