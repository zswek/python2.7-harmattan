
import unittest

from PySide.QtCore import QFile

class TestLUpdateSimple(unittest.TestCase):
    def testSimple(self):
        handle = open("i18n_new.ts", "r")
        original = open("i18n.ts", "r")
        self.assertEqual(handle.readline(), original.readline())

if __name__ == '__main__':
    unittest.main()
