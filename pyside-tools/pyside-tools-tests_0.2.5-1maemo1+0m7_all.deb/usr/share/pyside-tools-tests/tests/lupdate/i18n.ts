<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="i18n.py" line="179"/>
        <source>English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="i18n.py" line="150"/>
        <source>First</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="i18n.py" line="151"/>
        <source>Second</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="i18n.py" line="154"/>
        <source>Third</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="i18n.py" line="172"/>
        <source>E&amp;xit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="i18n.py" line="175"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="i18n.py" line="179"/>
        <source>Language: %s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="i18n.py" line="180"/>
        <source>Internationalization Example</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="i18n.py" line="182"/>
        <source>LTR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="i18n.py" line="186"/>
        <source>View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="i18n.py" line="187"/>
        <source>Perspective</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="i18n.py" line="188"/>
        <source>Isometric</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="i18n.py" line="189"/>
        <source>Oblique</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
