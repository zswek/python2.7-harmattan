#!/bin/sh

# This is a nasty workaround of a CTest limitation
# of setting the environment variables for the test.

# $1: python executable
# $2: python test
# $3: python script
# $5: pyside-lupdate path

$5/pyside-lupdate $3 -ts $4/i18n_new.ts
cd $4
$1 $2
