/*
 * This file is part of PySide: Python for Qt
 *
 * Copyright (C) 2009-2011 Nokia Corporation and/or its subsidiary(-ies).
 *
 * Contact: PySide team <contact@pyside.org>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * version 2.1 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA
 *
 */



#ifndef SBK_QTWEBKIT_PYTHON_H
#define SBK_QTWEBKIT_PYTHON_H

//workaround to access protected functions
#define protected public

#include <Python.h>
#include <conversions.h>
#include <sbkenum.h>
#include <basewrapper.h>
#include <bindingmanager.h>
#include <memory>

#include <pysidesignal.h>
// Module Includes
#include <pyside_qtcore_python.h>
#include <pyside_qtgui_python.h>
#include <pyside_qtnetwork_python.h>

// Binded library includes
#include <qwebpluginfactory.h>
#include <qwebhistoryinterface.h>
#include <qwebpage.h>
#include <qgraphicswebview.h>
#include <qwebsecurityorigin.h>
#include <qwebelement.h>
#include <qwebinspector.h>
#include <qwebhistory.h>
#include <qwebdatabase.h>
#include <qwebview.h>
#include <qwebframe.h>
#include <qwebsettings.h>
// Conversion Includes - Primitive Types
#include <QStringList>
#include <QString>
#include <datetime.h>
#include <signalmanager.h>
#include <typeresolver.h>
#include <QTextDocument>
#include <QtConcurrentFilter>

// Conversion Includes - Container Types
#include <QMap>
#include <QStack>
#include <qlinkedlist.h>
#include <QVector>
#include <QSet>
#include <QPair>
#include <pysideconversions.h>
#include <qqueue.h>
#include <QList>
#include <QMultiMap>

// Type indices
#define SBK_WEBCORE_IDX                                              38
#define SBK_QWEBHISTORY_IDX                                          8
#define SBK_QWEBHISTORYITEM_IDX                                      10
#define SBK_QWEBELEMENTCOLLECTION_IDX                                5
#define SBK_QWEBELEMENT_IDX                                          3
#define SBK_QWEBELEMENT_STYLERESOLVESTRATEGY_IDX                     4
#define SBK_QWEBSECURITYORIGIN_IDX                                   31
#define SBK_QWEBDATABASE_IDX                                         2
#define SBK_QWEBSETTINGS_IDX                                         32
#define SBK_QWEBSETTINGS_FONTSIZE_IDX                                34
#define SBK_QWEBSETTINGS_WEBGRAPHIC_IDX                              36
#define SBK_QWEBSETTINGS_FONTFAMILY_IDX                              33
#define SBK_QWEBSETTINGS_WEBATTRIBUTE_IDX                            35
#define SBK_QWEBHITTESTRESULT_IDX                                    11
#define SBK_QWEBINSPECTOR_IDX                                        12
#define SBK_QWEBHISTORYINTERFACE_IDX                                 9
#define SBK_QWEBPAGE_IDX                                             13
#define SBK_QWEBPAGE_ERRORDOMAIN_IDX                                 16
#define SBK_QWEBPAGE_NAVIGATIONTYPE_IDX                              24
#define SBK_QWEBPAGE_WEBACTION_IDX                                   25
#define SBK_QWEBPAGE_WEBWINDOWTYPE_IDX                               26
#define SBK_QWEBPAGE_FINDFLAG_IDX                                    22
#define SBK_QFLAGS_QWEBPAGE_FINDFLAG__IDX                            0
#define SBK_QWEBPAGE_EXTENSION_IDX                                   19
#define SBK_QWEBPAGE_LINKDELEGATIONPOLICY_IDX                        23
#define SBK_QWEBPAGE_EXTENSIONRETURN_IDX                             21
#define SBK_QWEBPAGE_CHOOSEMULTIPLEFILESEXTENSIONRETURN_IDX          15
#define SBK_QWEBPAGE_EXTENSIONOPTION_IDX                             20
#define SBK_QWEBPAGE_CHOOSEMULTIPLEFILESEXTENSIONOPTION_IDX          14
#define SBK_QWEBPAGE_ERRORPAGEEXTENSIONRETURN_IDX                    18
#define SBK_QWEBPAGE_ERRORPAGEEXTENSIONOPTION_IDX                    17
#define SBK_QWEBPLUGINFACTORY_IDX                                    27
#define SBK_QWEBPLUGINFACTORY_EXTENSION_IDX                          28
#define SBK_QWEBPLUGINFACTORY_PLUGIN_IDX                             30
#define SBK_QWEBPLUGINFACTORY_MIMETYPE_IDX                           29
#define SBK_QWEBVIEW_IDX                                             37
#define SBK_QGRAPHICSWEBVIEW_IDX                                     1
#define SBK_QWEBFRAME_IDX                                            6
#define SBK_QWEBFRAME_RENDERLAYER_IDX                                7
#define SBK_QtWebKit_IDX_COUNT                                       39

// This variable stores all python types exported by this module
extern PyTypeObject** SbkPySide_QtWebKitTypes;

// Macros for type check

namespace Shiboken
{

// PyType functions, to get the PyObjectType for a type T
template<> inline PyTypeObject* SbkType< ::QWebHistory >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtWebKitTypes[SBK_QWEBHISTORY_IDX]); }
template<> inline PyTypeObject* SbkType< ::QWebHistoryItem >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtWebKitTypes[SBK_QWEBHISTORYITEM_IDX]); }
template<> inline PyTypeObject* SbkType< ::QWebElementCollection >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtWebKitTypes[SBK_QWEBELEMENTCOLLECTION_IDX]); }
template<> inline PyTypeObject* SbkType< ::QWebElement::StyleResolveStrategy >() { return SbkPySide_QtWebKitTypes[SBK_QWEBELEMENT_STYLERESOLVESTRATEGY_IDX]; }
template<> inline PyTypeObject* SbkType< ::QWebElement >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtWebKitTypes[SBK_QWEBELEMENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QWebSecurityOrigin >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtWebKitTypes[SBK_QWEBSECURITYORIGIN_IDX]); }
template<> inline PyTypeObject* SbkType< ::QWebDatabase >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtWebKitTypes[SBK_QWEBDATABASE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QWebSettings::FontSize >() { return SbkPySide_QtWebKitTypes[SBK_QWEBSETTINGS_FONTSIZE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QWebSettings::WebGraphic >() { return SbkPySide_QtWebKitTypes[SBK_QWEBSETTINGS_WEBGRAPHIC_IDX]; }
template<> inline PyTypeObject* SbkType< ::QWebSettings::FontFamily >() { return SbkPySide_QtWebKitTypes[SBK_QWEBSETTINGS_FONTFAMILY_IDX]; }
template<> inline PyTypeObject* SbkType< ::QWebSettings::WebAttribute >() { return SbkPySide_QtWebKitTypes[SBK_QWEBSETTINGS_WEBATTRIBUTE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QWebSettings >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtWebKitTypes[SBK_QWEBSETTINGS_IDX]); }
template<> inline PyTypeObject* SbkType< ::QWebHitTestResult >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtWebKitTypes[SBK_QWEBHITTESTRESULT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QWebInspector >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtWebKitTypes[SBK_QWEBINSPECTOR_IDX]); }
template<> inline PyTypeObject* SbkType< ::QWebHistoryInterface >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtWebKitTypes[SBK_QWEBHISTORYINTERFACE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QWebPage::ErrorDomain >() { return SbkPySide_QtWebKitTypes[SBK_QWEBPAGE_ERRORDOMAIN_IDX]; }
template<> inline PyTypeObject* SbkType< ::QWebPage::NavigationType >() { return SbkPySide_QtWebKitTypes[SBK_QWEBPAGE_NAVIGATIONTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QWebPage::WebAction >() { return SbkPySide_QtWebKitTypes[SBK_QWEBPAGE_WEBACTION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QWebPage::WebWindowType >() { return SbkPySide_QtWebKitTypes[SBK_QWEBPAGE_WEBWINDOWTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QWebPage::FindFlag >() { return SbkPySide_QtWebKitTypes[SBK_QWEBPAGE_FINDFLAG_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QWebPage::FindFlag> >() { return SbkPySide_QtWebKitTypes[SBK_QFLAGS_QWEBPAGE_FINDFLAG__IDX]; }
template<> inline PyTypeObject* SbkType< ::QWebPage::Extension >() { return SbkPySide_QtWebKitTypes[SBK_QWEBPAGE_EXTENSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QWebPage::LinkDelegationPolicy >() { return SbkPySide_QtWebKitTypes[SBK_QWEBPAGE_LINKDELEGATIONPOLICY_IDX]; }
template<> inline PyTypeObject* SbkType< ::QWebPage >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtWebKitTypes[SBK_QWEBPAGE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QWebPage::ExtensionReturn >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtWebKitTypes[SBK_QWEBPAGE_EXTENSIONRETURN_IDX]); }
template<> inline PyTypeObject* SbkType< ::QWebPage::ChooseMultipleFilesExtensionReturn >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtWebKitTypes[SBK_QWEBPAGE_CHOOSEMULTIPLEFILESEXTENSIONRETURN_IDX]); }
template<> inline PyTypeObject* SbkType< ::QWebPage::ExtensionOption >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtWebKitTypes[SBK_QWEBPAGE_EXTENSIONOPTION_IDX]); }
template<> inline PyTypeObject* SbkType< ::QWebPage::ChooseMultipleFilesExtensionOption >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtWebKitTypes[SBK_QWEBPAGE_CHOOSEMULTIPLEFILESEXTENSIONOPTION_IDX]); }
template<> inline PyTypeObject* SbkType< ::QWebPage::ErrorPageExtensionReturn >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtWebKitTypes[SBK_QWEBPAGE_ERRORPAGEEXTENSIONRETURN_IDX]); }
template<> inline PyTypeObject* SbkType< ::QWebPage::ErrorPageExtensionOption >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtWebKitTypes[SBK_QWEBPAGE_ERRORPAGEEXTENSIONOPTION_IDX]); }
template<> inline PyTypeObject* SbkType< ::QWebPluginFactory::Extension >() { return SbkPySide_QtWebKitTypes[SBK_QWEBPLUGINFACTORY_EXTENSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QWebPluginFactory >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtWebKitTypes[SBK_QWEBPLUGINFACTORY_IDX]); }
template<> inline PyTypeObject* SbkType< ::QWebPluginFactory::Plugin >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtWebKitTypes[SBK_QWEBPLUGINFACTORY_PLUGIN_IDX]); }
template<> inline PyTypeObject* SbkType< ::QWebPluginFactory::MimeType >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtWebKitTypes[SBK_QWEBPLUGINFACTORY_MIMETYPE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QWebView >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtWebKitTypes[SBK_QWEBVIEW_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsWebView >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtWebKitTypes[SBK_QGRAPHICSWEBVIEW_IDX]); }
template<> inline PyTypeObject* SbkType< ::QWebFrame::RenderLayer >() { return SbkPySide_QtWebKitTypes[SBK_QWEBFRAME_RENDERLAYER_IDX]; }
template<> inline PyTypeObject* SbkType< ::QWebFrame >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtWebKitTypes[SBK_QWEBFRAME_IDX]); }

template<>
inline PyObject* createWrapper<QWebInspector >(const QWebInspector* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QWebInspector* value = const_cast<QWebInspector* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QWebInspector >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QWebHistoryInterface >(const QWebHistoryInterface* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QWebHistoryInterface* value = const_cast<QWebHistoryInterface* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QWebHistoryInterface >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QWebPage >(const QWebPage* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QWebPage* value = const_cast<QWebPage* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QWebPage >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QWebPluginFactory >(const QWebPluginFactory* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QWebPluginFactory* value = const_cast<QWebPluginFactory* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QWebPluginFactory >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QWebView >(const QWebView* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QWebView* value = const_cast<QWebView* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QWebView >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QGraphicsWebView >(const QGraphicsWebView* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QGraphicsWebView* value = const_cast<QGraphicsWebView* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QGraphicsWebView >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QWebFrame >(const QWebFrame* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QWebFrame* value = const_cast<QWebFrame* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QWebFrame >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
// Generated converters declarations ----------------------------------

template<>
struct Converter< ::QWebHistory* > : ObjectTypeConverter< ::QWebHistory >
{
};

template<>
struct Converter< ::QWebHistory > : ObjectTypeReferenceConverter< ::QWebHistory >
{
};

template<>
struct Converter< ::QWebHistoryItem > : ValueTypeConverter< ::QWebHistoryItem >
{
};

template<>
struct Converter< ::QWebElementCollection > : ValueTypeConverter< ::QWebElementCollection >
{
};

template<>
struct Converter< ::QWebElement::StyleResolveStrategy > : EnumConverter< ::QWebElement::StyleResolveStrategy >
{
};

template<>
struct Converter< ::QWebElement > : ValueTypeConverter< ::QWebElement >
{
};

template<>
struct Converter< ::QWebSecurityOrigin > : ValueTypeConverter< ::QWebSecurityOrigin >
{
};

template<>
struct Converter< ::QWebDatabase > : ValueTypeConverter< ::QWebDatabase >
{
};

template<>
struct Converter< ::QWebSettings::FontSize > : EnumConverter< ::QWebSettings::FontSize >
{
};

template<>
struct Converter< ::QWebSettings::WebGraphic > : EnumConverter< ::QWebSettings::WebGraphic >
{
};

template<>
struct Converter< ::QWebSettings::FontFamily > : EnumConverter< ::QWebSettings::FontFamily >
{
};

template<>
struct Converter< ::QWebSettings::WebAttribute > : EnumConverter< ::QWebSettings::WebAttribute >
{
};

template<>
struct Converter< ::QWebSettings* > : ObjectTypeConverter< ::QWebSettings >
{
};

template<>
struct Converter< ::QWebSettings > : ObjectTypeReferenceConverter< ::QWebSettings >
{
};

template<>
struct Converter< ::QWebHitTestResult > : ValueTypeConverter< ::QWebHitTestResult >
{
};

template<>
struct Converter< ::QWebInspector* > : ObjectTypeConverter< ::QWebInspector >
{
};

template<>
struct Converter< ::QWebInspector > : ObjectTypeReferenceConverter< ::QWebInspector >
{
};

template<>
struct Converter< ::QWebHistoryInterface* > : ObjectTypeConverter< ::QWebHistoryInterface >
{
};

template<>
struct Converter< ::QWebHistoryInterface > : ObjectTypeReferenceConverter< ::QWebHistoryInterface >
{
};

template<>
struct Converter< ::QWebPage::ErrorDomain > : EnumConverter< ::QWebPage::ErrorDomain >
{
};

template<>
struct Converter< ::QWebPage::NavigationType > : EnumConverter< ::QWebPage::NavigationType >
{
};

template<>
struct Converter< ::QWebPage::WebAction > : EnumConverter< ::QWebPage::WebAction >
{
};

template<>
struct Converter< ::QWebPage::WebWindowType > : EnumConverter< ::QWebPage::WebWindowType >
{
};

template<>
struct Converter< ::QWebPage::FindFlag > : EnumConverter< ::QWebPage::FindFlag >
{
};
template<>
struct Converter< ::QFlags<QWebPage::FindFlag> > : QFlagsConverter< ::QFlags<QWebPage::FindFlag> >
{
};

template<>
struct Converter< ::QWebPage::Extension > : EnumConverter< ::QWebPage::Extension >
{
};

template<>
struct Converter< ::QWebPage::LinkDelegationPolicy > : EnumConverter< ::QWebPage::LinkDelegationPolicy >
{
};

template<>
struct Converter< ::QWebPage* > : ObjectTypeConverter< ::QWebPage >
{
};

template<>
struct Converter< ::QWebPage > : ObjectTypeReferenceConverter< ::QWebPage >
{
};

template<>
struct Converter< ::QWebPage::ExtensionReturn > : ValueTypeConverter< ::QWebPage::ExtensionReturn >
{
};

template<>
struct Converter< ::QWebPage::ChooseMultipleFilesExtensionReturn > : ValueTypeConverter< ::QWebPage::ChooseMultipleFilesExtensionReturn >
{
};

template<>
struct Converter< ::QWebPage::ExtensionOption > : ValueTypeConverter< ::QWebPage::ExtensionOption >
{
};

template<>
struct Converter< ::QWebPage::ChooseMultipleFilesExtensionOption > : ValueTypeConverter< ::QWebPage::ChooseMultipleFilesExtensionOption >
{
};

template<>
struct Converter< ::QWebPage::ErrorPageExtensionReturn > : ValueTypeConverter< ::QWebPage::ErrorPageExtensionReturn >
{
};

template<>
struct Converter< ::QWebPage::ErrorPageExtensionOption > : ValueTypeConverter< ::QWebPage::ErrorPageExtensionOption >
{
};

template<>
struct Converter< ::QWebPluginFactory::Extension > : EnumConverter< ::QWebPluginFactory::Extension >
{
};

template<>
struct Converter< ::QWebPluginFactory* > : ObjectTypeConverter< ::QWebPluginFactory >
{
};

template<>
struct Converter< ::QWebPluginFactory > : ObjectTypeReferenceConverter< ::QWebPluginFactory >
{
};

template<>
struct Converter< ::QWebPluginFactory::Plugin > : ValueTypeConverter< ::QWebPluginFactory::Plugin >
{
};

template<>
struct Converter< ::QWebPluginFactory::MimeType > : ValueTypeConverter< ::QWebPluginFactory::MimeType >
{
};

template<>
struct Converter< ::QWebView* > : ObjectTypeConverter< ::QWebView >
{
};

template<>
struct Converter< ::QWebView > : ObjectTypeReferenceConverter< ::QWebView >
{
};

template<>
struct Converter< ::QGraphicsWebView* > : ObjectTypeConverter< ::QGraphicsWebView >
{
};

template<>
struct Converter< ::QGraphicsWebView > : ObjectTypeReferenceConverter< ::QGraphicsWebView >
{
};

template<>
struct Converter< ::QWebFrame::RenderLayer > : EnumConverter< ::QWebFrame::RenderLayer >
{
};

template<>
struct Converter< ::QWebFrame* > : ObjectTypeConverter< ::QWebFrame >
{
};

template<>
struct Converter< ::QWebFrame > : ObjectTypeReferenceConverter< ::QWebFrame >
{
};

} // namespace Shiboken

// User defined converters --------------------------------------------
// Generated converters implemantations -------------------------------


#endif // SBK_QTWEBKIT_PYTHON_H

