/*
 * This file is part of PySide: Python for Qt
 *
 * Copyright (C) 2009-2011 Nokia Corporation and/or its subsidiary(-ies).
 *
 * Contact: PySide team <contact@pyside.org>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * version 2.1 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA
 *
 */



#ifndef SBK_QTDECLARATIVE_PYTHON_H
#define SBK_QTDECLARATIVE_PYTHON_H

//workaround to access protected functions
#define protected public

#include <Python.h>
#include <conversions.h>
#include <sbkenum.h>
#include <basewrapper.h>
#include <bindingmanager.h>
#include <memory>

#include <pysidesignal.h>
// Module Includes
#include <pyside_qtcore_python.h>
#include <pyside_qtnetwork_python.h>
#include <pyside_qtgui_python.h>

// Binded library includes
#include <qdeclarativescriptstring.h>
#include <qdeclarativeproperty.h>
#include <qdeclarativenetworkaccessmanagerfactory.h>
#include <qdeclarativeparserstatus.h>
#include <qdeclarativeexpression.h>
#include <qdeclarativepropertymap.h>
#include <qdeclarativecomponent.h>
#include <qdeclarativeview.h>
#include <qdeclarativeitem.h>
#include <qdeclarativeextensionplugin.h>
#include <qdeclarativelist.h>
#include <qdeclarativepropertyvaluesource.h>
#include <qdeclarativeengine.h>
#include <qdeclarativeerror.h>
#include <qdeclarativeimageprovider.h>
#include <qdeclarativecontext.h>
#include <qdeclarativeextensioninterface.h>
// Conversion Includes - Primitive Types
#include <QStringList>
#include <QString>
#include <datetime.h>
#include <signalmanager.h>
#include <typeresolver.h>
#include <QTextDocument>
#include <QtConcurrentFilter>

// Conversion Includes - Container Types
#include <QMap>
#include <QStack>
#include <qlinkedlist.h>
#include <QVector>
#include <QSet>
#include <QPair>
#include <pysideconversions.h>
#include <qqueue.h>
#include <QList>
#include <QMultiMap>

// Type indices
#define SBK_QDECLARATIVESCRIPTSTRING_IDX                             21
#define SBK_QDECLARATIVEPROPERTY_IDX                                 16
#define SBK_QDECLARATIVEPROPERTY_TYPE_IDX                            18
#define SBK_QDECLARATIVEPROPERTY_PROPERTYTYPECATEGORY_IDX            17
#define SBK_QDECLARATIVENETWORKACCESSMANAGERFACTORY_IDX              14
#define SBK_QDECLARATIVEIMAGEPROVIDER_IDX                            9
#define SBK_QDECLARATIVEIMAGEPROVIDER_IMAGETYPE_IDX                  10
#define SBK_QDECLARATIVEEXTENSIONINTERFACE_IDX                       7
#define SBK_QDECLARATIVEERROR_IDX                                    5
#define SBK_QDECLARATIVELISTREFERENCE_IDX                            13
#define SBK_QDECLARATIVEPROPERTYVALUESOURCE_IDX                      20
#define SBK_QDECLARATIVEPARSERSTATUS_IDX                             15
#define SBK_QDECLARATIVEVIEW_IDX                                     22
#define SBK_QDECLARATIVEVIEW_RESIZEMODE_IDX                          23
#define SBK_QDECLARATIVEVIEW_STATUS_IDX                              24
#define SBK_QDECLARATIVEITEM_IDX                                     11
#define SBK_QDECLARATIVEITEM_TRANSFORMORIGIN_IDX                     12
#define SBK_QDECLARATIVEPROPERTYMAP_IDX                              19
#define SBK_QDECLARATIVEEXTENSIONPLUGIN_IDX                          8
#define SBK_QDECLARATIVEEXPRESSION_IDX                               6
#define SBK_QDECLARATIVEENGINE_IDX                                   3
#define SBK_QDECLARATIVEENGINE_OBJECTOWNERSHIP_IDX                   4
#define SBK_QDECLARATIVECONTEXT_IDX                                  2
#define SBK_QDECLARATIVECOMPONENT_IDX                                0
#define SBK_QDECLARATIVECOMPONENT_STATUS_IDX                         1
#define SBK_QML_HAS_ATTACHED_PROPERTIES_IDX                          25
#define SBK_QtDeclarative_IDX_COUNT                                  26

// This variable stores all python types exported by this module
extern PyTypeObject** SbkPySide_QtDeclarativeTypes;

// Macros for type check

namespace Shiboken
{

// PyType functions, to get the PyObjectType for a type T
template<> inline PyTypeObject* SbkType< ::QDeclarativeScriptString >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtDeclarativeTypes[SBK_QDECLARATIVESCRIPTSTRING_IDX]); }
template<> inline PyTypeObject* SbkType< ::QDeclarativeProperty::Type >() { return SbkPySide_QtDeclarativeTypes[SBK_QDECLARATIVEPROPERTY_TYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QDeclarativeProperty::PropertyTypeCategory >() { return SbkPySide_QtDeclarativeTypes[SBK_QDECLARATIVEPROPERTY_PROPERTYTYPECATEGORY_IDX]; }
template<> inline PyTypeObject* SbkType< ::QDeclarativeProperty >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtDeclarativeTypes[SBK_QDECLARATIVEPROPERTY_IDX]); }
template<> inline PyTypeObject* SbkType< ::QDeclarativeNetworkAccessManagerFactory >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtDeclarativeTypes[SBK_QDECLARATIVENETWORKACCESSMANAGERFACTORY_IDX]); }
template<> inline PyTypeObject* SbkType< ::QDeclarativeImageProvider::ImageType >() { return SbkPySide_QtDeclarativeTypes[SBK_QDECLARATIVEIMAGEPROVIDER_IMAGETYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QDeclarativeImageProvider >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtDeclarativeTypes[SBK_QDECLARATIVEIMAGEPROVIDER_IDX]); }
template<> inline PyTypeObject* SbkType< ::QDeclarativeExtensionInterface >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtDeclarativeTypes[SBK_QDECLARATIVEEXTENSIONINTERFACE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QDeclarativeError >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtDeclarativeTypes[SBK_QDECLARATIVEERROR_IDX]); }
template<> inline PyTypeObject* SbkType< ::QDeclarativeListReference >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtDeclarativeTypes[SBK_QDECLARATIVELISTREFERENCE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QDeclarativePropertyValueSource >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtDeclarativeTypes[SBK_QDECLARATIVEPROPERTYVALUESOURCE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QDeclarativeParserStatus >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtDeclarativeTypes[SBK_QDECLARATIVEPARSERSTATUS_IDX]); }
template<> inline PyTypeObject* SbkType< ::QDeclarativeView::ResizeMode >() { return SbkPySide_QtDeclarativeTypes[SBK_QDECLARATIVEVIEW_RESIZEMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QDeclarativeView::Status >() { return SbkPySide_QtDeclarativeTypes[SBK_QDECLARATIVEVIEW_STATUS_IDX]; }
template<> inline PyTypeObject* SbkType< ::QDeclarativeView >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtDeclarativeTypes[SBK_QDECLARATIVEVIEW_IDX]); }
template<> inline PyTypeObject* SbkType< ::QDeclarativeItem::TransformOrigin >() { return SbkPySide_QtDeclarativeTypes[SBK_QDECLARATIVEITEM_TRANSFORMORIGIN_IDX]; }
template<> inline PyTypeObject* SbkType< ::QDeclarativeItem >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtDeclarativeTypes[SBK_QDECLARATIVEITEM_IDX]); }
template<> inline PyTypeObject* SbkType< ::QDeclarativePropertyMap >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtDeclarativeTypes[SBK_QDECLARATIVEPROPERTYMAP_IDX]); }
template<> inline PyTypeObject* SbkType< ::QDeclarativeExtensionPlugin >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtDeclarativeTypes[SBK_QDECLARATIVEEXTENSIONPLUGIN_IDX]); }
template<> inline PyTypeObject* SbkType< ::QDeclarativeExpression >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtDeclarativeTypes[SBK_QDECLARATIVEEXPRESSION_IDX]); }
template<> inline PyTypeObject* SbkType< ::QDeclarativeEngine::ObjectOwnership >() { return SbkPySide_QtDeclarativeTypes[SBK_QDECLARATIVEENGINE_OBJECTOWNERSHIP_IDX]; }
template<> inline PyTypeObject* SbkType< ::QDeclarativeEngine >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtDeclarativeTypes[SBK_QDECLARATIVEENGINE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QDeclarativeContext >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtDeclarativeTypes[SBK_QDECLARATIVECONTEXT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QDeclarativeComponent::Status >() { return SbkPySide_QtDeclarativeTypes[SBK_QDECLARATIVECOMPONENT_STATUS_IDX]; }
template<> inline PyTypeObject* SbkType< ::QDeclarativeComponent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtDeclarativeTypes[SBK_QDECLARATIVECOMPONENT_IDX]); }

template<>
inline PyObject* createWrapper<QDeclarativeView >(const QDeclarativeView* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QDeclarativeView* value = const_cast<QDeclarativeView* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QDeclarativeView >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QDeclarativeItem >(const QDeclarativeItem* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QDeclarativeItem* value = const_cast<QDeclarativeItem* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QDeclarativeItem >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QDeclarativePropertyMap >(const QDeclarativePropertyMap* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QDeclarativePropertyMap* value = const_cast<QDeclarativePropertyMap* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QDeclarativePropertyMap >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QDeclarativeExtensionPlugin >(const QDeclarativeExtensionPlugin* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QDeclarativeExtensionPlugin* value = const_cast<QDeclarativeExtensionPlugin* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QDeclarativeExtensionPlugin >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QDeclarativeExpression >(const QDeclarativeExpression* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QDeclarativeExpression* value = const_cast<QDeclarativeExpression* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QDeclarativeExpression >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QDeclarativeEngine >(const QDeclarativeEngine* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QDeclarativeEngine* value = const_cast<QDeclarativeEngine* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QDeclarativeEngine >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QDeclarativeContext >(const QDeclarativeContext* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QDeclarativeContext* value = const_cast<QDeclarativeContext* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QDeclarativeContext >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QDeclarativeComponent >(const QDeclarativeComponent* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QDeclarativeComponent* value = const_cast<QDeclarativeComponent* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QDeclarativeComponent >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
// Generated converters declarations ----------------------------------

template<>
struct Converter< ::QDeclarativeScriptString > : ValueTypeConverter< ::QDeclarativeScriptString >
{
};

template<>
struct Converter< ::QDeclarativeProperty::Type > : EnumConverter< ::QDeclarativeProperty::Type >
{
};

template<>
struct Converter< ::QDeclarativeProperty::PropertyTypeCategory > : EnumConverter< ::QDeclarativeProperty::PropertyTypeCategory >
{
};

template<>
struct Converter< ::QDeclarativeProperty > : ValueTypeConverter< ::QDeclarativeProperty >
{
    static ::QDeclarativeProperty toCpp(PyObject* pyobj);
    static bool isConvertible(PyObject* pyobj);
};

template<>
struct Converter< ::QDeclarativeNetworkAccessManagerFactory* > : ObjectTypeConverter< ::QDeclarativeNetworkAccessManagerFactory >
{
};

template<>
struct Converter< ::QDeclarativeNetworkAccessManagerFactory > : ObjectTypeReferenceConverter< ::QDeclarativeNetworkAccessManagerFactory >
{
};

template<>
struct Converter< ::QDeclarativeImageProvider::ImageType > : EnumConverter< ::QDeclarativeImageProvider::ImageType >
{
};

template<>
struct Converter< ::QDeclarativeImageProvider* > : ObjectTypeConverter< ::QDeclarativeImageProvider >
{
};

template<>
struct Converter< ::QDeclarativeImageProvider > : ObjectTypeReferenceConverter< ::QDeclarativeImageProvider >
{
};

template<>
struct Converter< ::QDeclarativeExtensionInterface* > : ObjectTypeConverter< ::QDeclarativeExtensionInterface >
{
};

template<>
struct Converter< ::QDeclarativeExtensionInterface > : ObjectTypeReferenceConverter< ::QDeclarativeExtensionInterface >
{
};

template<>
struct Converter< ::QDeclarativeError > : ValueTypeConverter< ::QDeclarativeError >
{
};

template<>
struct Converter< ::QDeclarativeListReference > : ValueTypeConverter< ::QDeclarativeListReference >
{
};

template<>
struct Converter< ::QDeclarativePropertyValueSource* > : ObjectTypeConverter< ::QDeclarativePropertyValueSource >
{
};

template<>
struct Converter< ::QDeclarativePropertyValueSource > : ObjectTypeReferenceConverter< ::QDeclarativePropertyValueSource >
{
};

template<>
struct Converter< ::QDeclarativeParserStatus* > : ObjectTypeConverter< ::QDeclarativeParserStatus >
{
};

template<>
struct Converter< ::QDeclarativeParserStatus > : ObjectTypeReferenceConverter< ::QDeclarativeParserStatus >
{
};

template<>
struct Converter< ::QDeclarativeView::ResizeMode > : EnumConverter< ::QDeclarativeView::ResizeMode >
{
};

template<>
struct Converter< ::QDeclarativeView::Status > : EnumConverter< ::QDeclarativeView::Status >
{
};

template<>
struct Converter< ::QDeclarativeView* > : ObjectTypeConverter< ::QDeclarativeView >
{
};

template<>
struct Converter< ::QDeclarativeView > : ObjectTypeReferenceConverter< ::QDeclarativeView >
{
};

template<>
struct Converter< ::QDeclarativeItem::TransformOrigin > : EnumConverter< ::QDeclarativeItem::TransformOrigin >
{
};

template<>
struct Converter< ::QDeclarativeItem* > : ObjectTypeConverter< ::QDeclarativeItem >
{
};

template<>
struct Converter< ::QDeclarativeItem > : ObjectTypeReferenceConverter< ::QDeclarativeItem >
{
};

template<>
struct Converter< ::QDeclarativePropertyMap* > : ObjectTypeConverter< ::QDeclarativePropertyMap >
{
};

template<>
struct Converter< ::QDeclarativePropertyMap > : ObjectTypeReferenceConverter< ::QDeclarativePropertyMap >
{
};

template<>
struct Converter< ::QDeclarativeExtensionPlugin* > : ObjectTypeConverter< ::QDeclarativeExtensionPlugin >
{
};

template<>
struct Converter< ::QDeclarativeExtensionPlugin > : ObjectTypeReferenceConverter< ::QDeclarativeExtensionPlugin >
{
};

template<>
struct Converter< ::QDeclarativeExpression* > : ObjectTypeConverter< ::QDeclarativeExpression >
{
};

template<>
struct Converter< ::QDeclarativeExpression > : ObjectTypeReferenceConverter< ::QDeclarativeExpression >
{
};

template<>
struct Converter< ::QDeclarativeEngine::ObjectOwnership > : EnumConverter< ::QDeclarativeEngine::ObjectOwnership >
{
};

template<>
struct Converter< ::QDeclarativeEngine* > : ObjectTypeConverter< ::QDeclarativeEngine >
{
};

template<>
struct Converter< ::QDeclarativeEngine > : ObjectTypeReferenceConverter< ::QDeclarativeEngine >
{
};

template<>
struct Converter< ::QDeclarativeContext* > : ObjectTypeConverter< ::QDeclarativeContext >
{
};

template<>
struct Converter< ::QDeclarativeContext > : ObjectTypeReferenceConverter< ::QDeclarativeContext >
{
};

template<>
struct Converter< ::QDeclarativeComponent::Status > : EnumConverter< ::QDeclarativeComponent::Status >
{
};

template<>
struct Converter< ::QDeclarativeComponent* > : ObjectTypeConverter< ::QDeclarativeComponent >
{
};

template<>
struct Converter< ::QDeclarativeComponent > : ObjectTypeReferenceConverter< ::QDeclarativeComponent >
{
};

} // namespace Shiboken

// User defined converters --------------------------------------------
// Generated converters implemantations -------------------------------

inline bool Shiboken::Converter< ::QDeclarativeProperty >::isConvertible(PyObject* pyobj)
{
    if (ValueTypeConverter< ::QDeclarativeProperty >::isConvertible(pyobj))
        return true;
    SbkObjectType* shiboType = reinterpret_cast<SbkObjectType*>(SbkType< ::QDeclarativeProperty >());
    return Shiboken::Converter< ::QObject * >::checkType(pyobj)
         || (ObjectType::isExternalConvertible(shiboType, pyobj));
}

inline ::QDeclarativeProperty Shiboken::Converter< ::QDeclarativeProperty >::toCpp(PyObject* pyobj)
{
    if (PyObject_TypeCheck(pyobj, SbkType< ::QDeclarativeProperty >()))
        return *Shiboken::Converter< ::QDeclarativeProperty* >::toCpp(pyobj);
    else if (Shiboken::Converter< ::QObject * >::checkType(pyobj))
        return QDeclarativeProperty(Shiboken::Converter< ::QObject * >::toCpp(pyobj));
    else
        return Shiboken::ValueTypeConverter< ::QDeclarativeProperty >::toCpp(pyobj);
}


#endif // SBK_QTDECLARATIVE_PYTHON_H

