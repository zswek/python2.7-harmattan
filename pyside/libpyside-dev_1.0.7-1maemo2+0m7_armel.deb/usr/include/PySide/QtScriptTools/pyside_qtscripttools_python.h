/*
 * This file is part of PySide: Python for Qt
 *
 * Copyright (C) 2009-2011 Nokia Corporation and/or its subsidiary(-ies).
 *
 * Contact: PySide team <contact@pyside.org>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * version 2.1 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA
 *
 */



#ifndef SBK_QTSCRIPTTOOLS_PYTHON_H
#define SBK_QTSCRIPTTOOLS_PYTHON_H

//workaround to access protected functions
#define protected public

#include <Python.h>
#include <conversions.h>
#include <sbkenum.h>
#include <basewrapper.h>
#include <bindingmanager.h>
#include <memory>

#include <pysidesignal.h>
// Module Includes
#include <pyside_qtscript_python.h>
#include <pyside_qtcore_python.h>
#include <pyside_qtgui_python.h>

// Binded library includes
#include <qscriptenginedebugger.h>
// Conversion Includes - Primitive Types
#include <QStringList>
#include <QString>
#include <datetime.h>
#include <signalmanager.h>
#include <typeresolver.h>
#include <QTextDocument>
#include <QtConcurrentFilter>

// Conversion Includes - Container Types
#include <QMap>
#include <QStack>
#include <qlinkedlist.h>
#include <QVector>
#include <QSet>
#include <QPair>
#include <pysideconversions.h>
#include <qqueue.h>
#include <QList>
#include <QMultiMap>

// Type indices
#define SBK_QSCRIPTENGINEDEBUGGER_IDX                                0
#define SBK_QSCRIPTENGINEDEBUGGER_DEBUGGERWIDGET_IDX                 3
#define SBK_QSCRIPTENGINEDEBUGGER_DEBUGGERACTION_IDX                 1
#define SBK_QSCRIPTENGINEDEBUGGER_DEBUGGERSTATE_IDX                  2
#define SBK_QtScriptTools_IDX_COUNT                                  4

// This variable stores all python types exported by this module
extern PyTypeObject** SbkPySide_QtScriptToolsTypes;

// Macros for type check

namespace Shiboken
{

// PyType functions, to get the PyObjectType for a type T
template<> inline PyTypeObject* SbkType< ::QScriptEngineDebugger::DebuggerWidget >() { return SbkPySide_QtScriptToolsTypes[SBK_QSCRIPTENGINEDEBUGGER_DEBUGGERWIDGET_IDX]; }
template<> inline PyTypeObject* SbkType< ::QScriptEngineDebugger::DebuggerAction >() { return SbkPySide_QtScriptToolsTypes[SBK_QSCRIPTENGINEDEBUGGER_DEBUGGERACTION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QScriptEngineDebugger::DebuggerState >() { return SbkPySide_QtScriptToolsTypes[SBK_QSCRIPTENGINEDEBUGGER_DEBUGGERSTATE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QScriptEngineDebugger >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtScriptToolsTypes[SBK_QSCRIPTENGINEDEBUGGER_IDX]); }

template<>
inline PyObject* createWrapper<QScriptEngineDebugger >(const QScriptEngineDebugger* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QScriptEngineDebugger* value = const_cast<QScriptEngineDebugger* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QScriptEngineDebugger >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
// Generated converters declarations ----------------------------------

template<>
struct Converter< ::QScriptEngineDebugger::DebuggerWidget > : EnumConverter< ::QScriptEngineDebugger::DebuggerWidget >
{
};

template<>
struct Converter< ::QScriptEngineDebugger::DebuggerAction > : EnumConverter< ::QScriptEngineDebugger::DebuggerAction >
{
};

template<>
struct Converter< ::QScriptEngineDebugger::DebuggerState > : EnumConverter< ::QScriptEngineDebugger::DebuggerState >
{
};

template<>
struct Converter< ::QScriptEngineDebugger* > : ObjectTypeConverter< ::QScriptEngineDebugger >
{
};

template<>
struct Converter< ::QScriptEngineDebugger > : ObjectTypeReferenceConverter< ::QScriptEngineDebugger >
{
};

} // namespace Shiboken

// User defined converters --------------------------------------------
// Generated converters implemantations -------------------------------


#endif // SBK_QTSCRIPTTOOLS_PYTHON_H

