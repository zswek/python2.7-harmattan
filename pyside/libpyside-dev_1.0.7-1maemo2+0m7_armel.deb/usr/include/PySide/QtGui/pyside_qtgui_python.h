/*
 * This file is part of PySide: Python for Qt
 *
 * Copyright (C) 2009-2011 Nokia Corporation and/or its subsidiary(-ies).
 *
 * Contact: PySide team <contact@pyside.org>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * version 2.1 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA
 *
 */



#ifndef SBK_QTGUI_PYTHON_H
#define SBK_QTGUI_PYTHON_H

//workaround to access protected functions
#define protected public

#include <Python.h>
#include <conversions.h>
#include <sbkenum.h>
#include <basewrapper.h>
#include <bindingmanager.h>
#include <memory>

#include <pysidesignal.h>
// Module Includes
#include <pyside_qtcore_python.h>

// Binded library includes
#include <qwhatsthis.h>
#include <qtransform.h>
#include <qtextobject.h>
#include <qquaternion.h>
#include <qpen.h>
#include <qcleanlooksstyle.h>
#include <qpolygon.h>
#include <qabstractprintdialog.h>
#include <qsortfilterproxymodel.h>
#include <qcolordialog.h>
#include <qcursor.h>
#include <qtextcursor.h>
#include <qevent.h>
#include <qlabel.h>
#include <qprintpreviewdialog.h>
#include <qinputdialog.h>
#include <qsizegrip.h>
#include <qtabbar.h>
#include <qabstractbutton.h>
#include <qradiobutton.h>
#include <qtoolbar.h>
#include <qtreewidget.h>
#include <qiconengine.h>
#include <QTextEdit>
#include <qwizard.h>
#include <qboxlayout.h>
#include <qundoview.h>
#include <qplastiquestyle.h>
#include <qundogroup.h>
#include <qfont.h>
#include <qgraphicsanchorlayout.h>
#include <qpushbutton.h>
#include <qgraphicsitemanimation.h>
#include <qsplashscreen.h>
#include <qgesturerecognizer.h>
#include <qpixmap.h>
#include <qprinterinfo.h>
#include <qprogressbar.h>
#include <qpainterpath.h>
#include <qtoolbox.h>
#include <qlcdnumber.h>
#include <qabstractscrollarea.h>
#include <qabstractspinbox.h>
#include <qprogressdialog.h>
#include <qgraphicsscene.h>
#include <qtextbrowser.h>
#include <qfileiconprovider.h>
#include <qlistwidget.h>
#include <qundostack.h>
#include <qworkspace.h>
#include <qicon.h>
#include <qdirmodel.h>
#include <qformlayout.h>
#include <QAbstractTextDocumentLayout>
#include <qitemselectionmodel.h>
#include <qclipboard.h>
#include <qtextdocumentfragment.h>
#include <qgroupbox.h>
#include <qinputcontextfactory.h>
#include <qregion.h>
#include <qcolumnview.h>
#include <qwidget.h>
#include <qgraphicsproxywidget.h>
#include <qitemdelegate.h>
#include <qtextformat.h>
#include <qabstractslider.h>
#include <qkeyeventtransition.h>
#include <qgenericmatrix.h>
#include <qpalette.h>
#include <qpixmapcache.h>
#include <qfontdatabase.h>
#include <qtextlist.h>
#include <qgraphicswidget.h>
#include <qgraphicstransform.h>
#include <qvector4d.h>
#include <qmdisubwindow.h>
#include <qwidgetaction.h>
#include <qsound.h>
#include <qbuttongroup.h>
#include <qfocusframe.h>
#include <qstyleditemdelegate.h>
#include <qx11info_x11.h>
#include <qstringlistmodel.h>
#include <qerrormessage.h>
#include <qplaintextedit.h>
#include <qproxymodel.h>
#include <qdockwidget.h>
#include <qtabwidget.h>
#include <qabstractitemview.h>
#include <qspinbox.h>
#include <qcalendarwidget.h>
#include <qmatrix4x4.h>
#include <qprintdialog.h>
#include <qitemeditorfactory.h>
#include <qdatawidgetmapper.h>
#include <qrubberband.h>
#include <qabstracttextdocumentlayout.h>
#include <qaction.h>
#include <qpytextobject.h>
#include <qvector2d.h>
#include <qimagewriter.h>
#include <qmenu.h>
#include <qtextoption.h>
#include <qmouseeventtransition.h>
#include <qinputcontext.h>
#include <qtextedit.h>
#include <qfontinfo.h>
#include <qfontmetrics.h>
#include <qtextlayout.h>
#include <qwindowsstyle.h>
#include <qvector3d.h>
#include <qlistview.h>
#include <qsyntaxhighlighter.h>
#include <qtextdocument.h>
#include <qcolor.h>
#include <qgraphicsview.h>
#include <qpaintdevice.h>
#include <qfiledialog.h>
#include <qtablewidget.h>
#include <qfilesystemmodel.h>
#include <qgraphicseffect.h>
#include <qapplication.h>
#include <qtreeview.h>
#include <qtooltip.h>
#include <qlineedit.h>
#include <qtableview.h>
#include <qimage.h>
#include <qx11embed_x11.h>
#include <qbrush.h>
#include <qstyleoption.h>
#include <qgraphicslayoutitem.h>
#include <QPainterPath>
#include <qaccessible.h>
#include <qtoolbutton.h>
#include <qcombobox.h>
#include <qbitmap.h>
#include <QTextBlock>
#include <qpaintengine.h>
#include <qcommonstyle.h>
#include <qkeysequence.h>
#include <qstylepainter.h>
#include <qstylefactory.h>
#include <qtreewidgetitemiterator.h>
#include <qmovie.h>
#include <qimageiohandler.h>
#include <qdialogbuttonbox.h>
#include <qmotifstyle.h>
#include <qstackedwidget.h>
#include <qcheckbox.h>
#include <qstandarditemmodel.h>
#include <qabstractitemdelegate.h>
#include <qdesktopwidget.h>
#include <qgraphicssceneevent.h>
#include <qstackedlayout.h>
#include <qlayoutitem.h>
#include <QTextLayout>
#include <qmessagebox.h>
#include <qpicture.h>
#include <qdialog.h>
#include <qcommandlinkbutton.h>
#include <qfontdialog.h>
#include <qmdiarea.h>
#include <qslider.h>
#include <qcompleter.h>
#include <qprintengine.h>
#include <qlayout.h>
#include <qdial.h>
#include <qdrawutil.h>
#include <qstyle.h>
#include <qtexttable.h>
#include <qvalidator.h>
#include <qpainter.h>
#include <QTextFrame>
#include <qgraphicslayout.h>
#include <qheaderview.h>
#include <qgraphicslinearlayout.h>
#include <qstatusbar.h>
#include <qmatrix.h>
#include <qdrag.h>
#include <qfontcombobox.h>
#include <qdatetimeedit.h>
#include <qsystemtrayicon.h>
#include <qscrollarea.h>
#include <qscrollbar.h>
#include <qshortcut.h>
#include <qgraphicsitem.h>
#include <qsessionmanager.h>
#include <qabstractproxymodel.h>
#include <qdesktopservices.h>
#include <qprintpreviewwidget.h>
#include <qgridlayout.h>
#include <qsplitter.h>
#include <qframe.h>
#include <qactiongroup.h>
#include <QInputMethodEvent>
#include <qpagesetupdialog.h>
#include <qgesture.h>
#include <qimagereader.h>
#include <qprinter.h>
#include <qmenubar.h>
#include <qsizepolicy.h>
#include <qcdestyle.h>
#include <qgraphicsgridlayout.h>
#include <qabstractpagesetupdialog.h>
#include <qmainwindow.h>
// Conversion Includes - Primitive Types
#include <QStringList>
#include <QString>
#include <datetime.h>
#include <signalmanager.h>
#include <typeresolver.h>
#include <QTextDocument>
#include <QtConcurrentFilter>

// Conversion Includes - Container Types
#include <QMap>
#include <QStack>
#include <qlinkedlist.h>
#include <QVector>
#include <QSet>
#include <QPair>
#include <pysideconversions.h>
#include <qqueue.h>
#include <QList>
#include <QMultiMap>

// Type indices
#define SBK_QMATRIX4X3_IDX                                           329
#define SBK_QMATRIX3X4_IDX                                           327
#define SBK_QMATRIX4X2_IDX                                           328
#define SBK_QMATRIX3X3_IDX                                           326
#define SBK_QMATRIX2X4_IDX                                           324
#define SBK_QMATRIX3X2_IDX                                           325
#define SBK_QMATRIX2X3_IDX                                           323
#define SBK_QMATRIX2X2_IDX                                           322
#define SBK_QX11INFO_IDX                                             726
#define SBK_QPIXMAPCACHE_IDX                                         380
#define SBK_QPIXMAPCACHE_KEY_IDX                                     381
#define SBK_QPICTUREIO_IDX                                           375
#define SBK_QIMAGEIOHANDLER_IDX                                      270
#define SBK_QIMAGEIOHANDLER_IMAGEOPTION_IDX                          271
#define SBK_QICONENGINE_IDX                                          264
#define SBK_QVECTOR2D_IDX                                            702
#define SBK_QINPUTCONTEXTFACTORY_IDX                                 278
#define SBK_QMATRIX4X4_IDX                                           330
#define SBK_QQUATERNION_IDX                                          414
#define SBK_QVECTOR4D_IDX                                            704
#define SBK_QVECTOR3D_IDX                                            703
#define SBK_QTEXTTABLECELL_IDX                                       672
#define SBK_QTEXTDOCUMENTFRAGMENT_IDX                                633
#define SBK_QTEXTFRAGMENT_IDX                                        643
#define SBK_QTEXTBLOCK_IDX                                           615
#define SBK_QTEXTBLOCK_ITERATOR_IDX                                  616
#define SBK_QTEXTBLOCKUSERDATA_IDX                                   619
#define SBK_QFONTDATABASE_IDX                                        170
#define SBK_QFONTDATABASE_WRITINGSYSTEM_IDX                          171
#define SBK_QTEXTOBJECTINTERFACE_IDX                                 665
#define SBK_QTEXTCURSOR_IDX                                          624
#define SBK_QTEXTCURSOR_MOVEMODE_IDX                                 625
#define SBK_QTEXTCURSOR_MOVEOPERATION_IDX                            626
#define SBK_QTEXTCURSOR_SELECTIONTYPE_IDX                            627
#define SBK_QTEXTLINE_IDX                                            658
#define SBK_QTEXTLINE_EDGE_IDX                                       660
#define SBK_QTEXTLINE_CURSORPOSITION_IDX                             659
#define SBK_QTEXTINLINEOBJECT_IDX                                    650
#define SBK_QTEXTFORMAT_IDX                                          638
#define SBK_QTEXTFORMAT_PROPERTY_IDX                                 642
#define SBK_QTEXTFORMAT_FORMATTYPE_IDX                               639
#define SBK_QTEXTFORMAT_OBJECTTYPES_IDX                              640
#define SBK_QTEXTFORMAT_PAGEBREAKFLAG_IDX                            641
#define SBK_QFLAGS_QTEXTFORMAT_PAGEBREAKFLAG__IDX                    152
#define SBK_QTEXTFRAMEFORMAT_IDX                                     646
#define SBK_QTEXTFRAMEFORMAT_POSITION_IDX                            648
#define SBK_QTEXTFRAMEFORMAT_BORDERSTYLE_IDX                         647
#define SBK_QTEXTTABLEFORMAT_IDX                                     674
#define SBK_QTEXTLISTFORMAT_IDX                                      662
#define SBK_QTEXTLISTFORMAT_STYLE_IDX                                663
#define SBK_QTEXTBLOCKFORMAT_IDX                                     617
#define SBK_QTEXTLENGTH_IDX                                          656
#define SBK_QTEXTLENGTH_TYPE_IDX                                     657
#define SBK_QUNDOCOMMAND_IDX                                         695
#define SBK_QDESKTOPSERVICES_IDX                                     79
#define SBK_QDESKTOPSERVICES_STANDARDLOCATION_IDX                    80
#define SBK_QSTYLEFACTORY_IDX                                        465
#define SBK_QWHATSTHIS_IDX                                           705
#define SBK_QTOOLTIP_IDX                                             682
#define SBK_QGESTURERECOGNIZER_IDX                                   188
#define SBK_QGESTURERECOGNIZER_RESULTFLAG_IDX                        189
#define SBK_QFLAGS_QGESTURERECOGNIZER_RESULTFLAG__IDX                123
#define SBK_QLAYOUTITEM_IDX                                          306
#define SBK_QWIDGETITEM_IDX                                          711
#define SBK_QTREEWIDGETITEM_IDX                                      690
#define SBK_QTREEWIDGETITEM_ITEMTYPE_IDX                             692
#define SBK_QTREEWIDGETITEM_CHILDINDICATORPOLICY_IDX                 691
#define SBK_QTREEWIDGETITEMITERATOR_IDX                              693
#define SBK_QTREEWIDGETITEMITERATOR_ITERATORFLAG_IDX                 694
#define SBK_QFLAGS_QTREEWIDGETITEMITERATOR_ITERATORFLAG__IDX         155
#define SBK_QTABLEWIDGETITEM_IDX                                     607
#define SBK_QTABLEWIDGETITEM_ITEMTYPE_IDX                            608
#define SBK_QTABLEWIDGETSELECTIONRANGE_IDX                           609
#define SBK_QSTANDARDITEM_IDX                                        447
#define SBK_QSTANDARDITEM_ITEMTYPE_IDX                               448
#define SBK_QLISTWIDGETITEM_IDX                                      317
#define SBK_QLISTWIDGETITEM_ITEMTYPE_IDX                             318
#define SBK_QITEMEDITORFACTORY_IDX                                   289
#define SBK_QITEMEDITORCREATORBASE_IDX                               288
#define SBK_QFILEICONPROVIDER_IDX                                    108
#define SBK_QFILEICONPROVIDER_ICONTYPE_IDX                           109
#define SBK_QITEMSELECTION_IDX                                       290
#define SBK_QLIST_QITEMSELECTIONRANGE_IDX                            290
#define SBK_QITEMSELECTIONRANGE_IDX                                  293
#define SBK_QSTYLEOPTION_IDX                                         476
#define SBK_QSTYLEOPTION_STYLEOPTIONVERSION_IDX                      479
#define SBK_QSTYLEOPTION_STYLEOPTIONTYPE_IDX                         478
#define SBK_QSTYLEOPTION_OPTIONTYPE_IDX                              477
#define SBK_QSTYLEOPTIONTOOLBAR_IDX                                  562
#define SBK_QSTYLEOPTIONTOOLBAR_STYLEOPTIONVERSION_IDX               564
#define SBK_QSTYLEOPTIONTOOLBAR_STYLEOPTIONTYPE_IDX                  563
#define SBK_QSTYLEOPTIONTOOLBAR_TOOLBARPOSITION_IDX                  566
#define SBK_QSTYLEOPTIONTOOLBAR_TOOLBARFEATURE_IDX                   565
#define SBK_QFLAGS_QSTYLEOPTIONTOOLBAR_TOOLBARFEATURE__IDX           147
#define SBK_QSTYLEOPTIONBUTTON_IDX                                   480
#define SBK_QSTYLEOPTIONBUTTON_STYLEOPTIONVERSION_IDX                483
#define SBK_QSTYLEOPTIONBUTTON_BUTTONFEATURE_IDX                     481
#define SBK_QFLAGS_QSTYLEOPTIONBUTTON_BUTTONFEATURE__IDX             144
#define SBK_QSTYLEOPTIONBUTTON_STYLEOPTIONTYPE_IDX                   482
#define SBK_QSTYLEOPTIONCOMPLEX_IDX                                  487
#define SBK_QSTYLEOPTIONCOMPLEX_STYLEOPTIONVERSION_IDX               489
#define SBK_QSTYLEOPTIONCOMPLEX_STYLEOPTIONTYPE_IDX                  488
#define SBK_QSTYLEOPTIONCOMBOBOX_IDX                                 484
#define SBK_QSTYLEOPTIONCOMBOBOX_STYLEOPTIONVERSION_IDX              486
#define SBK_QSTYLEOPTIONCOMBOBOX_STYLEOPTIONTYPE_IDX                 485
#define SBK_QSTYLEOPTIONTOOLBUTTON_IDX                               574
#define SBK_QSTYLEOPTIONTOOLBUTTON_STYLEOPTIONVERSION_IDX            576
#define SBK_QSTYLEOPTIONTOOLBUTTON_TOOLBUTTONFEATURE_IDX             577
#define SBK_QFLAGS_QSTYLEOPTIONTOOLBUTTON_TOOLBUTTONFEATURE__IDX     148
#define SBK_QSTYLEOPTIONTOOLBUTTON_STYLEOPTIONTYPE_IDX               575
#define SBK_QSTYLEOPTIONSPINBOX_IDX                                  538
#define SBK_QSTYLEOPTIONSPINBOX_STYLEOPTIONVERSION_IDX               540
#define SBK_QSTYLEOPTIONSPINBOX_STYLEOPTIONTYPE_IDX                  539
#define SBK_QSTYLEOPTIONSLIDER_IDX                                   535
#define SBK_QSTYLEOPTIONSLIDER_STYLEOPTIONVERSION_IDX                537
#define SBK_QSTYLEOPTIONSLIDER_STYLEOPTIONTYPE_IDX                   536
#define SBK_QSTYLEOPTIONSIZEGRIP_IDX                                 532
#define SBK_QSTYLEOPTIONSIZEGRIP_STYLEOPTIONVERSION_IDX              534
#define SBK_QSTYLEOPTIONSIZEGRIP_STYLEOPTIONTYPE_IDX                 533
#define SBK_QSTYLEOPTIONGROUPBOX_IDX                                 509
#define SBK_QSTYLEOPTIONGROUPBOX_STYLEOPTIONVERSION_IDX              511
#define SBK_QSTYLEOPTIONGROUPBOX_STYLEOPTIONTYPE_IDX                 510
#define SBK_QSTYLEOPTIONTITLEBAR_IDX                                 559
#define SBK_QSTYLEOPTIONTITLEBAR_STYLEOPTIONVERSION_IDX              561
#define SBK_QSTYLEOPTIONTITLEBAR_STYLEOPTIONTYPE_IDX                 560
#define SBK_QSTYLEOPTIONHEADER_IDX                                   512
#define SBK_QSTYLEOPTIONHEADER_STYLEOPTIONVERSION_IDX                517
#define SBK_QSTYLEOPTIONHEADER_SECTIONPOSITION_IDX                   513
#define SBK_QSTYLEOPTIONHEADER_SELECTEDPOSITION_IDX                  514
#define SBK_QSTYLEOPTIONHEADER_STYLEOPTIONTYPE_IDX                   516
#define SBK_QSTYLEOPTIONHEADER_SORTINDICATOR_IDX                     515
#define SBK_QSTYLEOPTIONRUBBERBAND_IDX                               529
#define SBK_QSTYLEOPTIONRUBBERBAND_STYLEOPTIONVERSION_IDX            531
#define SBK_QSTYLEOPTIONRUBBERBAND_STYLEOPTIONTYPE_IDX               530
#define SBK_QSTYLEOPTIONTABBARBASE_IDX                               547
#define SBK_QSTYLEOPTIONTABBARBASE_STYLEOPTIONVERSION_IDX            549
#define SBK_QSTYLEOPTIONTABBARBASE_STYLEOPTIONTYPE_IDX               548
#define SBK_QSTYLEOPTIONTABBARBASEV2_IDX                             550
#define SBK_QSTYLEOPTIONTABBARBASEV2_STYLEOPTIONVERSION_IDX          551
#define SBK_QSTYLEOPTIONTOOLBOX_IDX                                  567
#define SBK_QSTYLEOPTIONTOOLBOX_STYLEOPTIONVERSION_IDX               569
#define SBK_QSTYLEOPTIONTOOLBOX_STYLEOPTIONTYPE_IDX                  568
#define SBK_QSTYLEOPTIONTOOLBOXV2_IDX                                570
#define SBK_QSTYLEOPTIONTOOLBOXV2_STYLEOPTIONVERSION_IDX             572
#define SBK_QSTYLEOPTIONTOOLBOXV2_TABPOSITION_IDX                    573
#define SBK_QSTYLEOPTIONTOOLBOXV2_SELECTEDPOSITION_IDX               571
#define SBK_QSTYLEOPTIONTABWIDGETFRAME_IDX                           556
#define SBK_QSTYLEOPTIONTABWIDGETFRAME_STYLEOPTIONVERSION_IDX        558
#define SBK_QSTYLEOPTIONTABWIDGETFRAME_STYLEOPTIONTYPE_IDX           557
#define SBK_QSTYLEOPTIONVIEWITEM_IDX                                 578
#define SBK_QSTYLEOPTIONVIEWITEM_STYLEOPTIONVERSION_IDX              581
#define SBK_QSTYLEOPTIONVIEWITEM_STYLEOPTIONTYPE_IDX                 580
#define SBK_QSTYLEOPTIONVIEWITEM_POSITION_IDX                        579
#define SBK_QSTYLEOPTIONVIEWITEMV2_IDX                               582
#define SBK_QSTYLEOPTIONVIEWITEMV2_STYLEOPTIONVERSION_IDX            583
#define SBK_QSTYLEOPTIONVIEWITEMV2_VIEWITEMFEATURE_IDX               584
#define SBK_QFLAGS_QSTYLEOPTIONVIEWITEMV2_VIEWITEMFEATURE__IDX       149
#define SBK_QSTYLEOPTIONVIEWITEMV3_IDX                               585
#define SBK_QSTYLEOPTIONVIEWITEMV3_STYLEOPTIONVERSION_IDX            586
#define SBK_QSTYLEOPTIONVIEWITEMV4_IDX                               587
#define SBK_QSTYLEOPTIONVIEWITEMV4_VIEWITEMPOSITION_IDX              589
#define SBK_QSTYLEOPTIONVIEWITEMV4_STYLEOPTIONVERSION_IDX            588
#define SBK_QSTYLEOPTIONFRAME_IDX                                    498
#define SBK_QSTYLEOPTIONFRAME_STYLEOPTIONVERSION_IDX                 500
#define SBK_QSTYLEOPTIONFRAME_STYLEOPTIONTYPE_IDX                    499
#define SBK_QSTYLEOPTIONFRAMEV2_IDX                                  501
#define SBK_QSTYLEOPTIONFRAMEV2_STYLEOPTIONVERSION_IDX               503
#define SBK_QSTYLEOPTIONFRAMEV2_FRAMEFEATURE_IDX                     502
#define SBK_QFLAGS_QSTYLEOPTIONFRAMEV2_FRAMEFEATURE__IDX             145
#define SBK_QSTYLEOPTIONFRAMEV3_IDX                                  504
#define SBK_QSTYLEOPTIONFRAMEV3_STYLEOPTIONVERSION_IDX               505
#define SBK_QSTYLEOPTIONFOCUSRECT_IDX                                495
#define SBK_QSTYLEOPTIONFOCUSRECT_STYLEOPTIONVERSION_IDX             497
#define SBK_QSTYLEOPTIONFOCUSRECT_STYLEOPTIONTYPE_IDX                496
#define SBK_QSTYLEHINTRETURN_IDX                                     466
#define SBK_QSTYLEHINTRETURN_HINTRETURNTYPE_IDX                      467
#define SBK_QSTYLEHINTRETURN_STYLEOPTIONVERSION_IDX                  469
#define SBK_QSTYLEHINTRETURN_STYLEOPTIONTYPE_IDX                     468
#define SBK_QSTYLEHINTRETURNVARIANT_IDX                              473
#define SBK_QSTYLEHINTRETURNVARIANT_STYLEOPTIONVERSION_IDX           475
#define SBK_QSTYLEHINTRETURNVARIANT_STYLEOPTIONTYPE_IDX              474
#define SBK_QSTYLEHINTRETURNMASK_IDX                                 470
#define SBK_QSTYLEHINTRETURNMASK_STYLEOPTIONVERSION_IDX              472
#define SBK_QSTYLEHINTRETURNMASK_STYLEOPTIONTYPE_IDX                 471
#define SBK_QSTYLEOPTIONDOCKWIDGET_IDX                               490
#define SBK_QSTYLEOPTIONDOCKWIDGET_STYLEOPTIONVERSION_IDX            492
#define SBK_QSTYLEOPTIONDOCKWIDGET_STYLEOPTIONTYPE_IDX               491
#define SBK_QSTYLEOPTIONDOCKWIDGETV2_IDX                             493
#define SBK_QSTYLEOPTIONDOCKWIDGETV2_STYLEOPTIONVERSION_IDX          494
#define SBK_QSTYLEOPTIONGRAPHICSITEM_IDX                             506
#define SBK_QSTYLEOPTIONGRAPHICSITEM_STYLEOPTIONVERSION_IDX          508
#define SBK_QSTYLEOPTIONGRAPHICSITEM_STYLEOPTIONTYPE_IDX             507
#define SBK_QSTYLEOPTIONMENUITEM_IDX                                 518
#define SBK_QSTYLEOPTIONMENUITEM_STYLEOPTIONVERSION_IDX              522
#define SBK_QSTYLEOPTIONMENUITEM_STYLEOPTIONTYPE_IDX                 521
#define SBK_QSTYLEOPTIONMENUITEM_CHECKTYPE_IDX                       519
#define SBK_QSTYLEOPTIONMENUITEM_MENUITEMTYPE_IDX                    520
#define SBK_QSTYLEOPTIONPROGRESSBAR_IDX                              523
#define SBK_QSTYLEOPTIONPROGRESSBAR_STYLEOPTIONVERSION_IDX           525
#define SBK_QSTYLEOPTIONPROGRESSBAR_STYLEOPTIONTYPE_IDX              524
#define SBK_QSTYLEOPTIONPROGRESSBARV2_IDX                            526
#define SBK_QSTYLEOPTIONPROGRESSBARV2_STYLEOPTIONVERSION_IDX         528
#define SBK_QSTYLEOPTIONPROGRESSBARV2_STYLEOPTIONTYPE_IDX            527
#define SBK_QKEYSEQUENCE_IDX                                         296
#define SBK_QKEYSEQUENCE_SEQUENCEFORMAT_IDX                          297
#define SBK_QKEYSEQUENCE_STANDARDKEY_IDX                             299
#define SBK_QKEYSEQUENCE_SEQUENCEMATCH_IDX                           298
#define SBK_QCURSOR_IDX                                              73
#define SBK_QSIZEPOLICY_IDX                                          431
#define SBK_QSIZEPOLICY_CONTROLTYPE_IDX                              432
#define SBK_QFLAGS_QSIZEPOLICY_CONTROLTYPE__IDX                      141
#define SBK_QSIZEPOLICY_POLICYFLAG_IDX                               434
#define SBK_QSIZEPOLICY_POLICY_IDX                                   433
#define SBK_QSPACERITEM_IDX                                          439
#define SBK_QPALETTE_IDX                                             369
#define SBK_QPALETTE_COLORGROUP_IDX                                  370
#define SBK_QPALETTE_COLORROLE_IDX                                   371
#define SBK_QPRINTERINFO_IDX                                         407
#define SBK_QPRINTENGINE_IDX                                         389
#define SBK_QPRINTENGINE_PRINTENGINEPROPERTYKEY_IDX                  390
#define SBK_QPAINTENGINESTATE_IDX                                    359
#define SBK_QPAINTENGINE_IDX                                         354
#define SBK_QPAINTENGINE_POLYGONDRAWMODE_IDX                         357
#define SBK_QPAINTENGINE_TYPE_IDX                                    358
#define SBK_QPAINTENGINE_PAINTENGINEFEATURE_IDX                      356
#define SBK_QFLAGS_QPAINTENGINE_PAINTENGINEFEATURE__IDX              137
#define SBK_QPAINTENGINE_DIRTYFLAG_IDX                               355
#define SBK_QFLAGS_QPAINTENGINE_DIRTYFLAG__IDX                       136
#define SBK_QTEXTITEM_IDX                                            651
#define SBK_QTEXTITEM_RENDERFLAG_IDX                                 652
#define SBK_QFLAGS_QTEXTITEM_RENDERFLAG__IDX                         153
#define SBK_QFONTMETRICSF_IDX                                        176
#define SBK_QFONTMETRICS_IDX                                         175
#define SBK_QFONTINFO_IDX                                            174
#define SBK_QFONT_IDX                                                160
#define SBK_QFONT_STYLESTRATEGY_IDX                                  166
#define SBK_QFONT_SPACINGTYPE_IDX                                    162
#define SBK_QFONT_STYLEHINT_IDX                                      165
#define SBK_QFONT_WEIGHT_IDX                                         167
#define SBK_QFONT_CAPITALIZATION_IDX                                 161
#define SBK_QFONT_STRETCH_IDX                                        163
#define SBK_QFONT_STYLE_IDX                                          164
#define SBK_QTEXTCHARFORMAT_IDX                                      621
#define SBK_QTEXTCHARFORMAT_VERTICALALIGNMENT_IDX                    623
#define SBK_QTEXTCHARFORMAT_UNDERLINESTYLE_IDX                       622
#define SBK_QTEXTTABLECELLFORMAT_IDX                                 673
#define SBK_QTEXTIMAGEFORMAT_IDX                                     649
#define SBK_QPEN_IDX                                                 373
#define SBK_QTEXTOPTION_IDX                                          666
#define SBK_QTEXTOPTION_TABTYPE_IDX                                  669
#define SBK_QTEXTOPTION_FLAG_IDX                                     667
#define SBK_QFLAGS_QTEXTOPTION_FLAG__IDX                             154
#define SBK_QTEXTOPTION_WRAPMODE_IDX                                 670
#define SBK_QTEXTOPTION_TAB_IDX                                      668
#define SBK_QTILERULES_IDX                                           675
#define SBK_QGRADIENT_IDX                                            190
#define SBK_QGRADIENT_COORDINATEMODE_IDX                             191
#define SBK_QGRADIENT_SPREAD_IDX                                     193
#define SBK_QGRADIENT_TYPE_IDX                                       194
#define SBK_QGRADIENT_INTERPOLATIONMODE_IDX                          192
#define SBK_QCONICALGRADIENT_IDX                                     70
#define SBK_QRADIALGRADIENT_IDX                                      415
#define SBK_QLINEARGRADIENT_IDX                                      309
#define SBK_QBRUSH_IDX                                               44
#define SBK_QPAINTDEVICE_IDX                                         352
#define SBK_QPAINTDEVICE_PAINTDEVICEMETRIC_IDX                       353
#define SBK_QPRINTER_IDX                                             395
#define SBK_QPRINTER_OUTPUTFORMAT_IDX                                399
#define SBK_QPRINTER_DUPLEXMODE_IDX                                  397
#define SBK_QPRINTER_PRINTRANGE_IDX                                  403
#define SBK_QPRINTER_UNIT_IDX                                        406
#define SBK_QPRINTER_PRINTERMODE_IDX                                 404
#define SBK_QPRINTER_ORIENTATION_IDX                                 398
#define SBK_QPRINTER_PRINTERSTATE_IDX                                405
#define SBK_QPRINTER_COLORMODE_IDX                                   396
#define SBK_QPRINTER_PAPERSOURCE_IDX                                 402
#define SBK_QPRINTER_PAGEORDER_IDX                                   400
#define SBK_QPRINTER_PAGESIZE_IDX                                    401
#define SBK_QPICTURE_IDX                                             374
#define SBK_QTRANSFORM_IDX                                           686
#define SBK_QTRANSFORM_TRANSFORMATIONTYPE_IDX                        687
#define SBK_QPAINTERPATHSTROKER_IDX                                  368
#define SBK_QMATRIX_IDX                                              321
#define SBK_QPAINTERPATH_IDX                                         365
#define SBK_QPAINTERPATH_ELEMENTTYPE_IDX                             367
#define SBK_QPAINTERPATH_ELEMENT_IDX                                 366
#define SBK_QPOLYGONF_IDX                                            387
#define SBK_QVECTOR_QPOINTF_IDX                                      387
#define SBK_QPOLYGON_IDX                                             386
#define SBK_QVECTOR_QPOINT_IDX                                       386
#define SBK_QCOLOR_IDX                                               57
#define SBK_QCOLOR_SPEC_IDX                                          58
#define SBK_QTEXTLAYOUT_IDX                                          653
#define SBK_QTEXTLAYOUT_CURSORMODE_IDX                               654
#define SBK_QTEXTLAYOUT_FORMATRANGE_IDX                              655
#define SBK_QPIXMAP_IDX                                              378
#define SBK_QPIXMAP_SHAREMODE_IDX                                    379
#define SBK_QIMAGE_IDX                                               267
#define SBK_QIMAGE_INVERTMODE_IDX                                    269
#define SBK_QIMAGE_FORMAT_IDX                                        268
#define SBK_QBITMAP_IDX                                              41
#define SBK_QGRAPHICSLAYOUTITEM_IDX                                  215
#define SBK_QGRAPHICSLAYOUT_IDX                                      214
#define SBK_QGRAPHICSLINEARLAYOUT_IDX                                217
#define SBK_QGRAPHICSGRIDLAYOUT_IDX                                  205
#define SBK_QGRAPHICSANCHORLAYOUT_IDX                                196
#define SBK_QGRAPHICSITEM_IDX                                        206
#define SBK_QGRAPHICSITEM_CACHEMODE_IDX                              207
#define SBK_QGRAPHICSITEM_PANELMODALITY_IDX                          211
#define SBK_QGRAPHICSITEM_GRAPHICSITEMFLAG_IDX                       210
#define SBK_QFLAGS_QGRAPHICSITEM_GRAPHICSITEMFLAG__IDX               126
#define SBK_QGRAPHICSITEM_GRAPHICSITEMCHANGE_IDX                     209
#define SBK_QGRAPHICSITEM_EXTENSION_IDX                              208
#define SBK_QABSTRACTGRAPHICSSHAPEITEM_IDX                           1
#define SBK_QGRAPHICSITEMGROUP_IDX                                   213
#define SBK_QGRAPHICSSIMPLETEXTITEM_IDX                              241
#define SBK_QGRAPHICSPIXMAPITEM_IDX                                  221
#define SBK_QGRAPHICSPIXMAPITEM_SHAPEMODE_IDX                        222
#define SBK_QGRAPHICSLINEITEM_IDX                                    216
#define SBK_QGRAPHICSPOLYGONITEM_IDX                                 223
#define SBK_QICON_IDX                                                260
#define SBK_QICON_MODE_IDX                                           261
#define SBK_QICON_STATE_IDX                                          262
#define SBK_QICONENGINEV2_IDX                                        265
#define SBK_QICONENGINEV2_ICONENGINEHOOK_IDX                         266
#define SBK_QGRAPHICSRECTITEM_IDX                                    225
#define SBK_QGRAPHICSPATHITEM_IDX                                    220
#define SBK_QPAINTER_IDX                                             361
#define SBK_QPAINTER_COMPOSITIONMODE_IDX                             362
#define SBK_QPAINTER_RENDERHINT_IDX                                  364
#define SBK_QFLAGS_QPAINTER_RENDERHINT__IDX                          139
#define SBK_QPAINTER_PIXMAPFRAGMENTHINT_IDX                          363
#define SBK_QFLAGS_QPAINTER_PIXMAPFRAGMENTHINT__IDX                  138
#define SBK_QSTYLEPAINTER_IDX                                        590
#define SBK_QGRAPHICSELLIPSEITEM_IDX                                 204
#define SBK_QABSTRACTPROXYMODEL_IDX                                  18
#define SBK_QSTRINGLISTMODEL_IDX                                     452
#define SBK_QSTANDARDITEMMODEL_IDX                                   449
#define SBK_QSORTFILTERPROXYMODEL_IDX                                437
#define SBK_QFILESYSTEMMODEL_IDX                                     111
#define SBK_QFILESYSTEMMODEL_ROLES_IDX                               112
#define SBK_QPROXYMODEL_IDX                                          411
#define SBK_QDIRMODEL_IDX                                            89
#define SBK_QDIRMODEL_ROLES_IDX                                      90
#define SBK_QAPPLICATION_IDX                                         38
#define SBK_QAPPLICATION_TYPE_IDX                                    40
#define SBK_QAPPLICATION_COLORSPEC_IDX                               39
#define SBK_QSTYLEOPTIONTAB_IDX                                      541
#define SBK_QSTYLEOPTIONTAB_STYLEOPTIONVERSION_IDX                   545
#define SBK_QSTYLEOPTIONTAB_CORNERWIDGET_IDX                         542
#define SBK_QFLAGS_QSTYLEOPTIONTAB_CORNERWIDGET__IDX                 146
#define SBK_QSTYLEOPTIONTAB_TABPOSITION_IDX                          546
#define SBK_QSTYLEOPTIONTAB_SELECTEDPOSITION_IDX                     543
#define SBK_QSTYLEOPTIONTAB_STYLEOPTIONTYPE_IDX                      544
#define SBK_QSTYLEOPTIONTABV2_IDX                                    552
#define SBK_QSTYLEOPTIONTABV2_STYLEOPTIONVERSION_IDX                 553
#define SBK_QSTYLEOPTIONTABV3_IDX                                    554
#define SBK_QSTYLEOPTIONTABV3_STYLEOPTIONVERSION_IDX                 555
#define SBK_QREGION_IDX                                              418
#define SBK_QREGION_REGIONTYPE_IDX                                   419
#define SBK_QMOUSEEVENTTRANSITION_IDX                                345
#define SBK_QKEYEVENTTRANSITION_IDX                                  295
#define SBK_QINPUTEVENT_IDX                                          282
#define SBK_QTOUCHEVENT_IDX                                          683
#define SBK_QTOUCHEVENT_DEVICETYPE_IDX                               684
#define SBK_QTOUCHEVENT_TOUCHPOINT_IDX                               685
#define SBK_QCONTEXTMENUEVENT_IDX                                    71
#define SBK_QCONTEXTMENUEVENT_REASON_IDX                             72
#define SBK_QKEYEVENT_IDX                                            294
#define SBK_QTABLETEVENT_IDX                                         610
#define SBK_QTABLETEVENT_TABLETDEVICE_IDX                            612
#define SBK_QTABLETEVENT_POINTERTYPE_IDX                             611
#define SBK_QWHEELEVENT_IDX                                          707
#define SBK_QMOUSEEVENT_IDX                                          344
#define SBK_QGESTUREEVENT_IDX                                        187
#define SBK_QWINDOWSTATECHANGEEVENT_IDX                              712
#define SBK_QCLIPBOARDEVENT_IDX                                      55
#define SBK_QSHORTCUTEVENT_IDX                                       428
#define SBK_QTOOLBARCHANGEEVENT_IDX                                  678
#define SBK_QFILEOPENEVENT_IDX                                       110
#define SBK_QACTIONEVENT_IDX                                         36
#define SBK_QWHATSTHISCLICKEDEVENT_IDX                               706
#define SBK_QSTATUSTIPEVENT_IDX                                      451
#define SBK_QHELPEVENT_IDX                                           257
#define SBK_QDRAGLEAVEEVENT_IDX                                      98
#define SBK_QDROPEVENT_IDX                                           100
#define SBK_QDRAGMOVEEVENT_IDX                                       99
#define SBK_QDRAGENTEREVENT_IDX                                      97
#define SBK_QINPUTMETHODEVENT_IDX                                    283
#define SBK_QINPUTMETHODEVENT_ATTRIBUTETYPE_IDX                      285
#define SBK_QINPUTMETHODEVENT_ATTRIBUTE_IDX                          284
#define SBK_QHIDEEVENT_IDX                                           258
#define SBK_QACCESSIBLEEVENT_IDX                                     30
#define SBK_QSHOWEVENT_IDX                                           429
#define SBK_QICONDRAGEVENT_IDX                                       263
#define SBK_QCLOSEEVENT_IDX                                          56
#define SBK_QRESIZEEVENT_IDX                                         420
#define SBK_QMOVEEVENT_IDX                                           346
#define SBK_QGRAPHICSSCENEEVENT_IDX                                  234
#define SBK_QGRAPHICSSCENEMOVEEVENT_IDX                              238
#define SBK_QGRAPHICSSCENERESIZEEVENT_IDX                            239
#define SBK_QGRAPHICSSCENEDRAGDROPEVENT_IDX                          233
#define SBK_QGRAPHICSSCENEHELPEVENT_IDX                              235
#define SBK_QGRAPHICSSCENEHOVEREVENT_IDX                             236
#define SBK_QGRAPHICSSCENECONTEXTMENUEVENT_IDX                       231
#define SBK_QGRAPHICSSCENECONTEXTMENUEVENT_REASON_IDX                232
#define SBK_QGRAPHICSSCENEWHEELEVENT_IDX                             240
#define SBK_QGRAPHICSSCENEMOUSEEVENT_IDX                             237
#define SBK_QPAINTEVENT_IDX                                          360
#define SBK_QFOCUSEVENT_IDX                                          158
#define SBK_QHOVEREVENT_IDX                                          259
#define SBK_QGRAPHICSANCHOR_IDX                                      195
#define SBK_QDATAWIDGETMAPPER_IDX                                    74
#define SBK_QDATAWIDGETMAPPER_SUBMITPOLICY_IDX                       75
#define SBK_QDRAG_IDX                                                96
#define SBK_QCLIPBOARD_IDX                                           53
#define SBK_QCLIPBOARD_MODE_IDX                                      54
#define SBK_QGESTURE_IDX                                             185
#define SBK_QGESTURE_GESTURECANCELPOLICY_IDX                         186
#define SBK_QTAPGESTURE_IDX                                          614
#define SBK_QTAPANDHOLDGESTURE_IDX                                   613
#define SBK_QSWIPEGESTURE_IDX                                        592
#define SBK_QSWIPEGESTURE_SWIPEDIRECTION_IDX                         593
#define SBK_QPINCHGESTURE_IDX                                        376
#define SBK_QPINCHGESTURE_CHANGEFLAG_IDX                             377
#define SBK_QFLAGS_QPINCHGESTURE_CHANGEFLAG__IDX                     140
#define SBK_QPANGESTURE_IDX                                          372
#define SBK_QITEMSELECTIONMODEL_IDX                                  291
#define SBK_QITEMSELECTIONMODEL_SELECTIONFLAG_IDX                    292
#define SBK_QFLAGS_QITEMSELECTIONMODEL_SELECTIONFLAG__IDX            130
#define SBK_QLAYOUT_IDX                                              304
#define SBK_QLAYOUT_SIZECONSTRAINT_IDX                               305
#define SBK_QBOXLAYOUT_IDX                                           42
#define SBK_QBOXLAYOUT_DIRECTION_IDX                                 43
#define SBK_QVBOXLAYOUT_IDX                                          699
#define SBK_QHBOXLAYOUT_IDX                                          254
#define SBK_QSTACKEDLAYOUT_IDX                                       444
#define SBK_QSTACKEDLAYOUT_STACKINGMODE_IDX                          445
#define SBK_QGRIDLAYOUT_IDX                                          251
#define SBK_QFORMLAYOUT_IDX                                          177
#define SBK_QFORMLAYOUT_FIELDGROWTHPOLICY_IDX                        178
#define SBK_QFORMLAYOUT_ROWWRAPPOLICY_IDX                            180
#define SBK_QFORMLAYOUT_ITEMROLE_IDX                                 179
#define SBK_QABSTRACTITEMDELEGATE_IDX                                2
#define SBK_QABSTRACTITEMDELEGATE_ENDEDITHINT_IDX                    3
#define SBK_QSTYLEDITEMDELEGATE_IDX                                  591
#define SBK_QITEMDELEGATE_IDX                                        287
#define SBK_QGRAPHICSEFFECT_IDX                                      201
#define SBK_QGRAPHICSEFFECT_PIXMAPPADMODE_IDX                        203
#define SBK_QGRAPHICSEFFECT_CHANGEFLAG_IDX                           202
#define SBK_QFLAGS_QGRAPHICSEFFECT_CHANGEFLAG__IDX                   125
#define SBK_QGRAPHICSOPACITYEFFECT_IDX                               219
#define SBK_QGRAPHICSDROPSHADOWEFFECT_IDX                            200
#define SBK_QGRAPHICSBLUREFFECT_IDX                                  197
#define SBK_QGRAPHICSBLUREFFECT_BLURHINT_IDX                         198
#define SBK_QFLAGS_QGRAPHICSBLUREFFECT_BLURHINT__IDX                 124
#define SBK_QGRAPHICSCOLORIZEEFFECT_IDX                              199
#define SBK_QPYTEXTOBJECT_IDX                                        413
#define SBK_QINPUTCONTEXT_IDX                                        276
#define SBK_QINPUTCONTEXT_STANDARDFORMAT_IDX                         277
#define SBK_QUNDOSTACK_IDX                                           697
#define SBK_QGRAPHICSOBJECT_IDX                                      218
#define SBK_QGRAPHICSWIDGET_IDX                                      250
#define SBK_QGRAPHICSPROXYWIDGET_IDX                                 224
#define SBK_QGRAPHICSTEXTITEM_IDX                                    242
#define SBK_QACTIONGROUP_IDX                                         37
#define SBK_QUNDOGROUP_IDX                                           696
#define SBK_QACTION_IDX                                              31
#define SBK_QACTION_PRIORITY_IDX                                     34
#define SBK_QACTION_ACTIONEVENT_IDX                                  32
#define SBK_QACTION_SOFTKEYROLE_IDX                                  35
#define SBK_QACTION_MENUROLE_IDX                                     33
#define SBK_QWIDGETACTION_IDX                                        710
#define SBK_QSYSTEMTRAYICON_IDX                                      595
#define SBK_QSYSTEMTRAYICON_MESSAGEICON_IDX                          597
#define SBK_QSYSTEMTRAYICON_ACTIVATIONREASON_IDX                     596
#define SBK_QGRAPHICSTRANSFORM_IDX                                   243
#define SBK_QGRAPHICSROTATION_IDX                                    226
#define SBK_QGRAPHICSSCALE_IDX                                       227
#define SBK_QCOMPLETER_IDX                                           67
#define SBK_QCOMPLETER_MODELSORTING_IDX                              69
#define SBK_QCOMPLETER_COMPLETIONMODE_IDX                            68
#define SBK_QSYNTAXHIGHLIGHTER_IDX                                   594
#define SBK_QVALIDATOR_IDX                                           700
#define SBK_QVALIDATOR_STATE_IDX                                     701
#define SBK_QREGEXPVALIDATOR_IDX                                     417
#define SBK_QDOUBLEVALIDATOR_IDX                                     94
#define SBK_QDOUBLEVALIDATOR_NOTATION_IDX                            95
#define SBK_QINTVALIDATOR_IDX                                        286
#define SBK_QWIDGET_IDX                                              708
#define SBK_QWIDGET_RENDERFLAG_IDX                                   709
#define SBK_QFLAGS_QWIDGET_RENDERFLAG__IDX                           156
#define SBK_QDESKTOPWIDGET_IDX                                       81
#define SBK_QX11EMBEDCONTAINER_IDX                                   722
#define SBK_QX11EMBEDCONTAINER_ERROR_IDX                             723
#define SBK_QX11EMBEDWIDGET_IDX                                      724
#define SBK_QX11EMBEDWIDGET_ERROR_IDX                                725
#define SBK_QWORKSPACE_IDX                                           720
#define SBK_QWORKSPACE_WINDOWORDER_IDX                               721
#define SBK_QTOOLBAR_IDX                                             677
#define SBK_QSTATUSBAR_IDX                                           450
#define SBK_QSPLITTERHANDLE_IDX                                      443
#define SBK_QSPLASHSCREEN_IDX                                        441
#define SBK_QDIALOG_IDX                                              83
#define SBK_QDIALOG_DIALOGCODE_IDX                                   84
#define SBK_QFILEDIALOG_IDX                                          102
#define SBK_QFILEDIALOG_FILEMODE_IDX                                 105
#define SBK_QFILEDIALOG_OPTION_IDX                                   106
#define SBK_QFLAGS_QFILEDIALOG_OPTION__IDX                           120
#define SBK_QFILEDIALOG_DIALOGLABEL_IDX                              104
#define SBK_QFILEDIALOG_VIEWMODE_IDX                                 107
#define SBK_QFILEDIALOG_ACCEPTMODE_IDX                               103
#define SBK_QSIZEGRIP_IDX                                            430
#define SBK_QPROGRESSBAR_IDX                                         408
#define SBK_QPROGRESSBAR_DIRECTION_IDX                               409
#define SBK_QPRINTPREVIEWWIDGET_IDX                                  392
#define SBK_QPRINTPREVIEWWIDGET_ZOOMMODE_IDX                         394
#define SBK_QPRINTPREVIEWWIDGET_VIEWMODE_IDX                         393
#define SBK_QFRAME_IDX                                               181
#define SBK_QFRAME_STYLEMASK_IDX                                     184
#define SBK_QFRAME_SHAPE_IDX                                         183
#define SBK_QFRAME_SHADOW_IDX                                        182
#define SBK_QTOOLBOX_IDX                                             679
#define SBK_QABSTRACTSCROLLAREA_IDX                                  19
#define SBK_QABSTRACTITEMVIEW_IDX                                    4
#define SBK_QABSTRACTITEMVIEW_DRAGDROPMODE_IDX                       6
#define SBK_QABSTRACTITEMVIEW_SELECTIONBEHAVIOR_IDX                  11
#define SBK_QABSTRACTITEMVIEW_EDITTRIGGER_IDX                        8
#define SBK_QFLAGS_QABSTRACTITEMVIEW_EDITTRIGGER__IDX                113
#define SBK_QABSTRACTITEMVIEW_SCROLLMODE_IDX                         10
#define SBK_QABSTRACTITEMVIEW_CURSORACTION_IDX                       5
#define SBK_QABSTRACTITEMVIEW_DROPINDICATORPOSITION_IDX              7
#define SBK_QABSTRACTITEMVIEW_SCROLLHINT_IDX                         9
#define SBK_QABSTRACTITEMVIEW_SELECTIONMODE_IDX                      12
#define SBK_QABSTRACTITEMVIEW_STATE_IDX                              13
#define SBK_QTABLEVIEW_IDX                                           605
#define SBK_QTABLEWIDGET_IDX                                         606
#define SBK_QCOLUMNVIEW_IDX                                          61
#define SBK_QLISTVIEW_IDX                                            310
#define SBK_QLISTVIEW_RESIZEMODE_IDX                                 314
#define SBK_QLISTVIEW_LAYOUTMODE_IDX                                 312
#define SBK_QLISTVIEW_VIEWMODE_IDX                                   315
#define SBK_QLISTVIEW_FLOW_IDX                                       311
#define SBK_QLISTVIEW_MOVEMENT_IDX                                   313
#define SBK_QUNDOVIEW_IDX                                            698
#define SBK_QLISTWIDGET_IDX                                          316
#define SBK_QTREEVIEW_IDX                                            688
#define SBK_QTREEWIDGET_IDX                                          689
#define SBK_QHEADERVIEW_IDX                                          255
#define SBK_QHEADERVIEW_RESIZEMODE_IDX                               256
#define SBK_QSCROLLAREA_IDX                                          423
#define SBK_QSTACKEDWIDGET_IDX                                       446
#define SBK_QSPLITTER_IDX                                            442
#define SBK_QPLAINTEXTEDIT_IDX                                       383
#define SBK_QPLAINTEXTEDIT_LINEWRAPMODE_IDX                          384
#define SBK_QRUBBERBAND_IDX                                          421
#define SBK_QRUBBERBAND_SHAPE_IDX                                    422
#define SBK_QTEXTEDIT_IDX                                            634
#define SBK_QTEXTEDIT_AUTOFORMATTINGFLAG_IDX                         635
#define SBK_QFLAGS_QTEXTEDIT_AUTOFORMATTINGFLAG__IDX                 151
#define SBK_QTEXTEDIT_LINEWRAPMODE_IDX                               637
#define SBK_QTEXTEDIT_EXTRASELECTION_IDX                             636
#define SBK_QTEXTBROWSER_IDX                                         620
#define SBK_QTABWIDGET_IDX                                           602
#define SBK_QTABWIDGET_TABSHAPE_IDX                                  604
#define SBK_QTABWIDGET_TABPOSITION_IDX                               603
#define SBK_QTABBAR_IDX                                              598
#define SBK_QTABBAR_SELECTIONBEHAVIOR_IDX                            600
#define SBK_QTABBAR_BUTTONPOSITION_IDX                               599
#define SBK_QTABBAR_SHAPE_IDX                                        601
#define SBK_QMENUBAR_IDX                                             338
#define SBK_QMENU_IDX                                                337
#define SBK_QABSTRACTSLIDER_IDX                                      20
#define SBK_QABSTRACTSLIDER_SLIDERACTION_IDX                         21
#define SBK_QABSTRACTSLIDER_SLIDERCHANGE_IDX                         22
#define SBK_QSLIDER_IDX                                              435
#define SBK_QSLIDER_TICKPOSITION_IDX                                 436
#define SBK_QSCROLLBAR_IDX                                           424
#define SBK_QMDISUBWINDOW_IDX                                        335
#define SBK_QMDISUBWINDOW_SUBWINDOWOPTION_IDX                        336
#define SBK_QFLAGS_QMDISUBWINDOW_SUBWINDOWOPTION__IDX                133
#define SBK_QABSTRACTSPINBOX_IDX                                     23
#define SBK_QABSTRACTSPINBOX_STEPENABLEDFLAG_IDX                     26
#define SBK_QFLAGS_QABSTRACTSPINBOX_STEPENABLEDFLAG__IDX             115
#define SBK_QABSTRACTSPINBOX_CORRECTIONMODE_IDX                      25
#define SBK_QABSTRACTSPINBOX_BUTTONSYMBOLS_IDX                       24
#define SBK_QDOUBLESPINBOX_IDX                                       93
#define SBK_QSPINBOX_IDX                                             440
#define SBK_QMDIAREA_IDX                                             331
#define SBK_QMDIAREA_WINDOWORDER_IDX                                 334
#define SBK_QMDIAREA_VIEWMODE_IDX                                    333
#define SBK_QMDIAREA_AREAOPTION_IDX                                  332
#define SBK_QFLAGS_QMDIAREA_AREAOPTION__IDX                          132
#define SBK_QMAINWINDOW_IDX                                          319
#define SBK_QMAINWINDOW_DOCKOPTION_IDX                               320
#define SBK_QFLAGS_QMAINWINDOW_DOCKOPTION__IDX                       131
#define SBK_QLCDNUMBER_IDX                                           300
#define SBK_QLCDNUMBER_MODE_IDX                                      301
#define SBK_QLCDNUMBER_SEGMENTSTYLE_IDX                              302
#define SBK_QGROUPBOX_IDX                                            252
#define SBK_QLABEL_IDX                                               303
#define SBK_QFOCUSFRAME_IDX                                          159
#define SBK_QDOCKWIDGET_IDX                                          91
#define SBK_QDOCKWIDGET_DOCKWIDGETFEATURE_IDX                        92
#define SBK_QFLAGS_QDOCKWIDGET_DOCKWIDGETFEATURE__IDX                119
#define SBK_QDIALOGBUTTONBOX_IDX                                     85
#define SBK_QDIALOGBUTTONBOX_BUTTONLAYOUT_IDX                        86
#define SBK_QDIALOGBUTTONBOX_BUTTONROLE_IDX                          87
#define SBK_QDIALOGBUTTONBOX_STANDARDBUTTON_IDX                      88
#define SBK_QFLAGS_QDIALOGBUTTONBOX_STANDARDBUTTON__IDX              118
#define SBK_QDIAL_IDX                                                82
#define SBK_QDATETIMEEDIT_IDX                                        77
#define SBK_QDATETIMEEDIT_SECTION_IDX                                78
#define SBK_QFLAGS_QDATETIMEEDIT_SECTION__IDX                        117
#define SBK_QDATEEDIT_IDX                                            76
#define SBK_QTIMEEDIT_IDX                                            676
#define SBK_QCOMBOBOX_IDX                                            62
#define SBK_QCOMBOBOX_INSERTPOLICY_IDX                               63
#define SBK_QCOMBOBOX_SIZEADJUSTPOLICY_IDX                           64
#define SBK_QFONTCOMBOBOX_IDX                                        168
#define SBK_QFONTCOMBOBOX_FONTFILTER_IDX                             169
#define SBK_QFLAGS_QFONTCOMBOBOX_FONTFILTER__IDX                     121
#define SBK_QCALENDARWIDGET_IDX                                      47
#define SBK_QCALENDARWIDGET_HORIZONTALHEADERFORMAT_IDX               48
#define SBK_QCALENDARWIDGET_VERTICALHEADERFORMAT_IDX                 50
#define SBK_QCALENDARWIDGET_SELECTIONMODE_IDX                        49
#define SBK_QABSTRACTBUTTON_IDX                                      0
#define SBK_QRADIOBUTTON_IDX                                         416
#define SBK_QTOOLBUTTON_IDX                                          680
#define SBK_QTOOLBUTTON_TOOLBUTTONPOPUPMODE_IDX                      681
#define SBK_QPUSHBUTTON_IDX                                          412
#define SBK_QCOMMANDLINKBUTTON_IDX                                   65
#define SBK_QCHECKBOX_IDX                                            51
#define SBK_QWIZARDPAGE_IDX                                          719
#define SBK_QWIZARD_IDX                                              714
#define SBK_QWIZARD_WIZARDBUTTON_IDX                                 715
#define SBK_QWIZARD_WIZARDSTYLE_IDX                                  718
#define SBK_QWIZARD_WIZARDPIXMAP_IDX                                 717
#define SBK_QWIZARD_WIZARDOPTION_IDX                                 716
#define SBK_QFLAGS_QWIZARD_WIZARDOPTION__IDX                         157
#define SBK_QPROGRESSDIALOG_IDX                                      410
#define SBK_QPRINTPREVIEWDIALOG_IDX                                  391
#define SBK_QMESSAGEBOX_IDX                                          339
#define SBK_QMESSAGEBOX_BUTTONROLE_IDX                               340
#define SBK_QMESSAGEBOX_STANDARDBUTTON_IDX                           342
#define SBK_QFLAGS_QMESSAGEBOX_STANDARDBUTTON__IDX                   134
#define SBK_QMESSAGEBOX_ICON_IDX                                     341
#define SBK_QLINEEDIT_IDX                                            307
#define SBK_QLINEEDIT_ECHOMODE_IDX                                   308
#define SBK_QINPUTDIALOG_IDX                                         279
#define SBK_QINPUTDIALOG_INPUTMODE_IDX                               281
#define SBK_QINPUTDIALOG_INPUTDIALOGOPTION_IDX                       280
#define SBK_QFONTDIALOG_IDX                                          172
#define SBK_QFONTDIALOG_FONTDIALOGOPTION_IDX                         173
#define SBK_QFLAGS_QFONTDIALOG_FONTDIALOGOPTION__IDX                 122
#define SBK_QERRORMESSAGE_IDX                                        101
#define SBK_QCOLORDIALOG_IDX                                         59
#define SBK_QCOLORDIALOG_COLORDIALOGOPTION_IDX                       60
#define SBK_QFLAGS_QCOLORDIALOG_COLORDIALOGOPTION__IDX               116
#define SBK_QABSTRACTPRINTDIALOG_IDX                                 15
#define SBK_QABSTRACTPRINTDIALOG_PRINTRANGE_IDX                      17
#define SBK_QABSTRACTPRINTDIALOG_PRINTDIALOGOPTION_IDX               16
#define SBK_QFLAGS_QABSTRACTPRINTDIALOG_PRINTDIALOGOPTION__IDX       114
#define SBK_QPRINTDIALOG_IDX                                         388
#define SBK_QABSTRACTPAGESETUPDIALOG_IDX                             14
#define SBK_QPAGESETUPDIALOG_IDX                                     350
#define SBK_QPAGESETUPDIALOG_PAGESETUPDIALOGOPTION_IDX               351
#define SBK_QFLAGS_QPAGESETUPDIALOG_PAGESETUPDIALOGOPTION__IDX       135
#define SBK_QSTYLE_IDX                                               453
#define SBK_QSTYLE_PIXELMETRIC_IDX                                   457
#define SBK_QSTYLE_SUBCONTROL_IDX                                    463
#define SBK_QFLAGS_QSTYLE_SUBCONTROL__IDX                            143
#define SBK_QSTYLE_STANDARDPIXMAP_IDX                                460
#define SBK_QSTYLE_STYLEHINT_IDX                                     462
#define SBK_QSTYLE_PRIMITIVEELEMENT_IDX                              458
#define SBK_QSTYLE_CONTROLELEMENT_IDX                                456
#define SBK_QSTYLE_CONTENTSTYPE_IDX                                  455
#define SBK_QSTYLE_STATEFLAG_IDX                                     461
#define SBK_QFLAGS_QSTYLE_STATEFLAG__IDX                             142
#define SBK_QSTYLE_COMPLEXCONTROL_IDX                                454
#define SBK_QSTYLE_REQUESTSOFTWAREINPUTPANEL_IDX                     459
#define SBK_QSTYLE_SUBELEMENT_IDX                                    464
#define SBK_QCOMMONSTYLE_IDX                                         66
#define SBK_QWINDOWSSTYLE_IDX                                        713
#define SBK_QPLASTIQUESTYLE_IDX                                      385
#define SBK_QCLEANLOOKSSTYLE_IDX                                     52
#define SBK_QMOTIFSTYLE_IDX                                          343
#define SBK_QCDESTYLE_IDX                                            46
#define SBK_QTEXTOBJECT_IDX                                          664
#define SBK_QTEXTFRAME_IDX                                           644
#define SBK_QTEXTTABLE_IDX                                           671
#define SBK_QTEXTFRAME_ITERATOR_IDX                                  645
#define SBK_QTEXTBLOCKGROUP_IDX                                      618
#define SBK_QTEXTLIST_IDX                                            661
#define SBK_QABSTRACTTEXTDOCUMENTLAYOUT_IDX                          27
#define SBK_QABSTRACTTEXTDOCUMENTLAYOUT_SELECTION_IDX                29
#define SBK_QABSTRACTTEXTDOCUMENTLAYOUT_PAINTCONTEXT_IDX             28
#define SBK_QPLAINTEXTDOCUMENTLAYOUT_IDX                             382
#define SBK_QBUTTONGROUP_IDX                                         45
#define SBK_QGRAPHICSSCENE_IDX                                       228
#define SBK_QGRAPHICSSCENE_SCENELAYER_IDX                            230
#define SBK_QFLAGS_QGRAPHICSSCENE_SCENELAYER__IDX                    127
#define SBK_QGRAPHICSSCENE_ITEMINDEXMETHOD_IDX                       229
#define SBK_QGRAPHICSVIEW_IDX                                        244
#define SBK_QGRAPHICSVIEW_OPTIMIZATIONFLAG_IDX                       247
#define SBK_QFLAGS_QGRAPHICSVIEW_OPTIMIZATIONFLAG__IDX               129
#define SBK_QGRAPHICSVIEW_VIEWPORTANCHOR_IDX                         248
#define SBK_QGRAPHICSVIEW_VIEWPORTUPDATEMODE_IDX                     249
#define SBK_QGRAPHICSVIEW_CACHEMODEFLAG_IDX                          245
#define SBK_QFLAGS_QGRAPHICSVIEW_CACHEMODEFLAG__IDX                  128
#define SBK_QGRAPHICSVIEW_DRAGMODE_IDX                               246
#define SBK_QSOUND_IDX                                               438
#define SBK_QSHORTCUT_IDX                                            427
#define SBK_QSESSIONMANAGER_IDX                                      425
#define SBK_QSESSIONMANAGER_RESTARTHINT_IDX                          426
#define SBK_QGRAPHICSITEMANIMATION_IDX                               212
#define SBK_QTEXTDOCUMENT_IDX                                        628
#define SBK_QTEXTDOCUMENT_RESOURCETYPE_IDX                           631
#define SBK_QTEXTDOCUMENT_STACKS_IDX                                 632
#define SBK_QTEXTDOCUMENT_FINDFLAG_IDX                               629
#define SBK_QFLAGS_QTEXTDOCUMENT_FINDFLAG__IDX                       150
#define SBK_QTEXTDOCUMENT_METAINFORMATION_IDX                        630
#define SBK_QMOVIE_IDX                                               347
#define SBK_QMOVIE_CACHEMODE_IDX                                     348
#define SBK_QMOVIE_MOVIESTATE_IDX                                    349
#define SBK_QIMAGEWRITER_IDX                                         274
#define SBK_QIMAGEWRITER_IMAGEWRITERERROR_IDX                        275
#define SBK_QIMAGEREADER_IDX                                         272
#define SBK_QIMAGEREADER_IMAGEREADERERROR_IDX                        273
#define SBK_QtGui_IDX_COUNT                                          727

// This variable stores all python types exported by this module
extern PyTypeObject** SbkPySide_QtGuiTypes;

// Macros for type check

namespace Shiboken
{

// PyType functions, to get the PyObjectType for a type T
template<> inline PyTypeObject* SbkType< ::QMatrix4x3 >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QMATRIX4X3_IDX]); }
template<> inline PyTypeObject* SbkType< ::QMatrix3x4 >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QMATRIX3X4_IDX]); }
template<> inline PyTypeObject* SbkType< ::QMatrix4x2 >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QMATRIX4X2_IDX]); }
template<> inline PyTypeObject* SbkType< ::QMatrix3x3 >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QMATRIX3X3_IDX]); }
template<> inline PyTypeObject* SbkType< ::QMatrix2x4 >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QMATRIX2X4_IDX]); }
template<> inline PyTypeObject* SbkType< ::QMatrix3x2 >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QMATRIX3X2_IDX]); }
template<> inline PyTypeObject* SbkType< ::QMatrix2x3 >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QMATRIX2X3_IDX]); }
template<> inline PyTypeObject* SbkType< ::QMatrix2x2 >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QMATRIX2X2_IDX]); }
template<> inline PyTypeObject* SbkType< ::QX11Info >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QX11INFO_IDX]); }
template<> inline PyTypeObject* SbkType< ::QPixmapCache >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QPIXMAPCACHE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QPixmapCache::Key >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QPIXMAPCACHE_KEY_IDX]); }
template<> inline PyTypeObject* SbkType< ::QPictureIO >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QPICTUREIO_IDX]); }
template<> inline PyTypeObject* SbkType< ::QImageIOHandler::ImageOption >() { return SbkPySide_QtGuiTypes[SBK_QIMAGEIOHANDLER_IMAGEOPTION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QImageIOHandler >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QIMAGEIOHANDLER_IDX]); }
template<> inline PyTypeObject* SbkType< ::QIconEngine >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QICONENGINE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QVector2D >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QVECTOR2D_IDX]); }
template<> inline PyTypeObject* SbkType< ::QInputContextFactory >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QINPUTCONTEXTFACTORY_IDX]); }
template<> inline PyTypeObject* SbkType< ::QMatrix4x4 >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QMATRIX4X4_IDX]); }
template<> inline PyTypeObject* SbkType< ::QQuaternion >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QQUATERNION_IDX]); }
template<> inline PyTypeObject* SbkType< ::QVector4D >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QVECTOR4D_IDX]); }
template<> inline PyTypeObject* SbkType< ::QVector3D >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QVECTOR3D_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTextTableCell >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTEXTTABLECELL_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTextDocumentFragment >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTEXTDOCUMENTFRAGMENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTextFragment >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTEXTFRAGMENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTextBlock >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTEXTBLOCK_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTextBlock::iterator >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTEXTBLOCK_ITERATOR_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTextBlockUserData >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTEXTBLOCKUSERDATA_IDX]); }
template<> inline PyTypeObject* SbkType< ::QFontDatabase::WritingSystem >() { return SbkPySide_QtGuiTypes[SBK_QFONTDATABASE_WRITINGSYSTEM_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFontDatabase >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QFONTDATABASE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTextObjectInterface >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTEXTOBJECTINTERFACE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTextCursor::MoveMode >() { return SbkPySide_QtGuiTypes[SBK_QTEXTCURSOR_MOVEMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QTextCursor::MoveOperation >() { return SbkPySide_QtGuiTypes[SBK_QTEXTCURSOR_MOVEOPERATION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QTextCursor::SelectionType >() { return SbkPySide_QtGuiTypes[SBK_QTEXTCURSOR_SELECTIONTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QTextCursor >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTEXTCURSOR_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTextLine::Edge >() { return SbkPySide_QtGuiTypes[SBK_QTEXTLINE_EDGE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QTextLine::CursorPosition >() { return SbkPySide_QtGuiTypes[SBK_QTEXTLINE_CURSORPOSITION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QTextLine >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTEXTLINE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTextInlineObject >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTEXTINLINEOBJECT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTextFormat::Property >() { return SbkPySide_QtGuiTypes[SBK_QTEXTFORMAT_PROPERTY_IDX]; }
template<> inline PyTypeObject* SbkType< ::QTextFormat::FormatType >() { return SbkPySide_QtGuiTypes[SBK_QTEXTFORMAT_FORMATTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QTextFormat::ObjectTypes >() { return SbkPySide_QtGuiTypes[SBK_QTEXTFORMAT_OBJECTTYPES_IDX]; }
template<> inline PyTypeObject* SbkType< ::QTextFormat::PageBreakFlag >() { return SbkPySide_QtGuiTypes[SBK_QTEXTFORMAT_PAGEBREAKFLAG_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QTextFormat::PageBreakFlag> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QTEXTFORMAT_PAGEBREAKFLAG__IDX]; }
template<> inline PyTypeObject* SbkType< ::QTextFormat >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTEXTFORMAT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTextFrameFormat::Position >() { return SbkPySide_QtGuiTypes[SBK_QTEXTFRAMEFORMAT_POSITION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QTextFrameFormat::BorderStyle >() { return SbkPySide_QtGuiTypes[SBK_QTEXTFRAMEFORMAT_BORDERSTYLE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QTextFrameFormat >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTEXTFRAMEFORMAT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTextTableFormat >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTEXTTABLEFORMAT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTextListFormat::Style >() { return SbkPySide_QtGuiTypes[SBK_QTEXTLISTFORMAT_STYLE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QTextListFormat >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTEXTLISTFORMAT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTextBlockFormat >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTEXTBLOCKFORMAT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTextLength::Type >() { return SbkPySide_QtGuiTypes[SBK_QTEXTLENGTH_TYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QTextLength >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTEXTLENGTH_IDX]); }
template<> inline PyTypeObject* SbkType< ::QUndoCommand >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QUNDOCOMMAND_IDX]); }
template<> inline PyTypeObject* SbkType< ::QDesktopServices::StandardLocation >() { return SbkPySide_QtGuiTypes[SBK_QDESKTOPSERVICES_STANDARDLOCATION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QDesktopServices >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QDESKTOPSERVICES_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleFactory >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEFACTORY_IDX]); }
template<> inline PyTypeObject* SbkType< ::QWhatsThis >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QWHATSTHIS_IDX]); }
template<> inline PyTypeObject* SbkType< ::QToolTip >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTOOLTIP_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGestureRecognizer::ResultFlag >() { return SbkPySide_QtGuiTypes[SBK_QGESTURERECOGNIZER_RESULTFLAG_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QGestureRecognizer::ResultFlag> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QGESTURERECOGNIZER_RESULTFLAG__IDX]; }
template<> inline PyTypeObject* SbkType< ::QGestureRecognizer >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGESTURERECOGNIZER_IDX]); }
template<> inline PyTypeObject* SbkType< ::QLayoutItem >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QLAYOUTITEM_IDX]); }
template<> inline PyTypeObject* SbkType< ::QWidgetItem >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QWIDGETITEM_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTreeWidgetItem::ItemType >() { return SbkPySide_QtGuiTypes[SBK_QTREEWIDGETITEM_ITEMTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QTreeWidgetItem::ChildIndicatorPolicy >() { return SbkPySide_QtGuiTypes[SBK_QTREEWIDGETITEM_CHILDINDICATORPOLICY_IDX]; }
template<> inline PyTypeObject* SbkType< ::QTreeWidgetItem >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTREEWIDGETITEM_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTreeWidgetItemIterator::IteratorFlag >() { return SbkPySide_QtGuiTypes[SBK_QTREEWIDGETITEMITERATOR_ITERATORFLAG_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QTreeWidgetItemIterator::IteratorFlag> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QTREEWIDGETITEMITERATOR_ITERATORFLAG__IDX]; }
template<> inline PyTypeObject* SbkType< ::QTreeWidgetItemIterator >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTREEWIDGETITEMITERATOR_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTableWidgetItem::ItemType >() { return SbkPySide_QtGuiTypes[SBK_QTABLEWIDGETITEM_ITEMTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QTableWidgetItem >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTABLEWIDGETITEM_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTableWidgetSelectionRange >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTABLEWIDGETSELECTIONRANGE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStandardItem::ItemType >() { return SbkPySide_QtGuiTypes[SBK_QSTANDARDITEM_ITEMTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStandardItem >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTANDARDITEM_IDX]); }
template<> inline PyTypeObject* SbkType< ::QListWidgetItem::ItemType >() { return SbkPySide_QtGuiTypes[SBK_QLISTWIDGETITEM_ITEMTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QListWidgetItem >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QLISTWIDGETITEM_IDX]); }
template<> inline PyTypeObject* SbkType< ::QItemEditorFactory >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QITEMEDITORFACTORY_IDX]); }
template<> inline PyTypeObject* SbkType< ::QItemEditorCreatorBase >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QITEMEDITORCREATORBASE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QFileIconProvider::IconType >() { return SbkPySide_QtGuiTypes[SBK_QFILEICONPROVIDER_ICONTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFileIconProvider >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QFILEICONPROVIDER_IDX]); }
template<> inline PyTypeObject* SbkType< ::QItemSelection >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QITEMSELECTION_IDX]); }
template<> inline PyTypeObject* SbkType< ::QItemSelectionRange >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QITEMSELECTIONRANGE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleOption::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTION_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOption::StyleOptionType >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTION_STYLEOPTIONTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOption::OptionType >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTION_OPTIONTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOption >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEOPTION_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleOptionToolBar::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTOOLBAR_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionToolBar::StyleOptionType >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTOOLBAR_STYLEOPTIONTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionToolBar::ToolBarPosition >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTOOLBAR_TOOLBARPOSITION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionToolBar::ToolBarFeature >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTOOLBAR_TOOLBARFEATURE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QStyleOptionToolBar::ToolBarFeature> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QSTYLEOPTIONTOOLBAR_TOOLBARFEATURE__IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionToolBar >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTOOLBAR_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleOptionButton::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONBUTTON_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionButton::ButtonFeature >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONBUTTON_BUTTONFEATURE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QStyleOptionButton::ButtonFeature> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QSTYLEOPTIONBUTTON_BUTTONFEATURE__IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionButton::StyleOptionType >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONBUTTON_STYLEOPTIONTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionButton >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONBUTTON_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleOptionComplex::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONCOMPLEX_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionComplex::StyleOptionType >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONCOMPLEX_STYLEOPTIONTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionComplex >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONCOMPLEX_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleOptionComboBox::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONCOMBOBOX_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionComboBox::StyleOptionType >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONCOMBOBOX_STYLEOPTIONTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionComboBox >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONCOMBOBOX_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleOptionToolButton::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTOOLBUTTON_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionToolButton::ToolButtonFeature >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTOOLBUTTON_TOOLBUTTONFEATURE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QStyleOptionToolButton::ToolButtonFeature> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QSTYLEOPTIONTOOLBUTTON_TOOLBUTTONFEATURE__IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionToolButton::StyleOptionType >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTOOLBUTTON_STYLEOPTIONTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionToolButton >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTOOLBUTTON_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleOptionSpinBox::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONSPINBOX_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionSpinBox::StyleOptionType >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONSPINBOX_STYLEOPTIONTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionSpinBox >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONSPINBOX_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleOptionSlider::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONSLIDER_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionSlider::StyleOptionType >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONSLIDER_STYLEOPTIONTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionSlider >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONSLIDER_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleOptionSizeGrip::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONSIZEGRIP_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionSizeGrip::StyleOptionType >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONSIZEGRIP_STYLEOPTIONTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionSizeGrip >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONSIZEGRIP_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleOptionGroupBox::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONGROUPBOX_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionGroupBox::StyleOptionType >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONGROUPBOX_STYLEOPTIONTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionGroupBox >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONGROUPBOX_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleOptionTitleBar::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTITLEBAR_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionTitleBar::StyleOptionType >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTITLEBAR_STYLEOPTIONTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionTitleBar >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTITLEBAR_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleOptionHeader::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONHEADER_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionHeader::SectionPosition >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONHEADER_SECTIONPOSITION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionHeader::SelectedPosition >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONHEADER_SELECTEDPOSITION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionHeader::StyleOptionType >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONHEADER_STYLEOPTIONTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionHeader::SortIndicator >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONHEADER_SORTINDICATOR_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionHeader >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONHEADER_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleOptionRubberBand::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONRUBBERBAND_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionRubberBand::StyleOptionType >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONRUBBERBAND_STYLEOPTIONTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionRubberBand >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONRUBBERBAND_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleOptionTabBarBase::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTABBARBASE_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionTabBarBase::StyleOptionType >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTABBARBASE_STYLEOPTIONTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionTabBarBase >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTABBARBASE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleOptionTabBarBaseV2::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTABBARBASEV2_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionTabBarBaseV2 >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTABBARBASEV2_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleOptionToolBox::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTOOLBOX_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionToolBox::StyleOptionType >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTOOLBOX_STYLEOPTIONTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionToolBox >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTOOLBOX_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleOptionToolBoxV2::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTOOLBOXV2_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionToolBoxV2::TabPosition >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTOOLBOXV2_TABPOSITION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionToolBoxV2::SelectedPosition >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTOOLBOXV2_SELECTEDPOSITION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionToolBoxV2 >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTOOLBOXV2_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleOptionTabWidgetFrame::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTABWIDGETFRAME_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionTabWidgetFrame::StyleOptionType >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTABWIDGETFRAME_STYLEOPTIONTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionTabWidgetFrame >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTABWIDGETFRAME_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleOptionViewItem::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONVIEWITEM_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionViewItem::StyleOptionType >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONVIEWITEM_STYLEOPTIONTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionViewItem::Position >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONVIEWITEM_POSITION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionViewItem >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONVIEWITEM_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleOptionViewItemV2::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONVIEWITEMV2_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionViewItemV2::ViewItemFeature >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONVIEWITEMV2_VIEWITEMFEATURE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QStyleOptionViewItemV2::ViewItemFeature> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QSTYLEOPTIONVIEWITEMV2_VIEWITEMFEATURE__IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionViewItemV2 >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONVIEWITEMV2_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleOptionViewItemV3::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONVIEWITEMV3_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionViewItemV3 >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONVIEWITEMV3_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleOptionViewItemV4::ViewItemPosition >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONVIEWITEMV4_VIEWITEMPOSITION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionViewItemV4::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONVIEWITEMV4_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionViewItemV4 >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONVIEWITEMV4_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleOptionFrame::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONFRAME_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionFrame::StyleOptionType >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONFRAME_STYLEOPTIONTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionFrame >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONFRAME_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleOptionFrameV2::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONFRAMEV2_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionFrameV2::FrameFeature >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONFRAMEV2_FRAMEFEATURE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QStyleOptionFrameV2::FrameFeature> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QSTYLEOPTIONFRAMEV2_FRAMEFEATURE__IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionFrameV2 >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONFRAMEV2_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleOptionFrameV3::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONFRAMEV3_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionFrameV3 >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONFRAMEV3_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleOptionFocusRect::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONFOCUSRECT_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionFocusRect::StyleOptionType >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONFOCUSRECT_STYLEOPTIONTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionFocusRect >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONFOCUSRECT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleHintReturn::HintReturnType >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEHINTRETURN_HINTRETURNTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleHintReturn::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEHINTRETURN_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleHintReturn::StyleOptionType >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEHINTRETURN_STYLEOPTIONTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleHintReturn >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEHINTRETURN_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleHintReturnVariant::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEHINTRETURNVARIANT_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleHintReturnVariant::StyleOptionType >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEHINTRETURNVARIANT_STYLEOPTIONTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleHintReturnVariant >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEHINTRETURNVARIANT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleHintReturnMask::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEHINTRETURNMASK_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleHintReturnMask::StyleOptionType >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEHINTRETURNMASK_STYLEOPTIONTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleHintReturnMask >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEHINTRETURNMASK_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleOptionDockWidget::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONDOCKWIDGET_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionDockWidget::StyleOptionType >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONDOCKWIDGET_STYLEOPTIONTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionDockWidget >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONDOCKWIDGET_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleOptionDockWidgetV2::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONDOCKWIDGETV2_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionDockWidgetV2 >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONDOCKWIDGETV2_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleOptionGraphicsItem::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONGRAPHICSITEM_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionGraphicsItem::StyleOptionType >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONGRAPHICSITEM_STYLEOPTIONTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionGraphicsItem >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONGRAPHICSITEM_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleOptionMenuItem::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONMENUITEM_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionMenuItem::StyleOptionType >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONMENUITEM_STYLEOPTIONTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionMenuItem::CheckType >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONMENUITEM_CHECKTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionMenuItem::MenuItemType >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONMENUITEM_MENUITEMTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionMenuItem >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONMENUITEM_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleOptionProgressBar::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONPROGRESSBAR_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionProgressBar::StyleOptionType >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONPROGRESSBAR_STYLEOPTIONTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionProgressBar >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONPROGRESSBAR_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleOptionProgressBarV2::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONPROGRESSBARV2_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionProgressBarV2::StyleOptionType >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONPROGRESSBARV2_STYLEOPTIONTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionProgressBarV2 >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONPROGRESSBARV2_IDX]); }
template<> inline PyTypeObject* SbkType< ::QKeySequence::SequenceFormat >() { return SbkPySide_QtGuiTypes[SBK_QKEYSEQUENCE_SEQUENCEFORMAT_IDX]; }
template<> inline PyTypeObject* SbkType< ::QKeySequence::StandardKey >() { return SbkPySide_QtGuiTypes[SBK_QKEYSEQUENCE_STANDARDKEY_IDX]; }
template<> inline PyTypeObject* SbkType< ::QKeySequence::SequenceMatch >() { return SbkPySide_QtGuiTypes[SBK_QKEYSEQUENCE_SEQUENCEMATCH_IDX]; }
template<> inline PyTypeObject* SbkType< ::QKeySequence >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QKEYSEQUENCE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QCursor >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QCURSOR_IDX]); }
template<> inline PyTypeObject* SbkType< ::QSizePolicy::ControlType >() { return SbkPySide_QtGuiTypes[SBK_QSIZEPOLICY_CONTROLTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QSizePolicy::ControlType> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QSIZEPOLICY_CONTROLTYPE__IDX]; }
template<> inline PyTypeObject* SbkType< ::QSizePolicy::PolicyFlag >() { return SbkPySide_QtGuiTypes[SBK_QSIZEPOLICY_POLICYFLAG_IDX]; }
template<> inline PyTypeObject* SbkType< ::QSizePolicy::Policy >() { return SbkPySide_QtGuiTypes[SBK_QSIZEPOLICY_POLICY_IDX]; }
template<> inline PyTypeObject* SbkType< ::QSizePolicy >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSIZEPOLICY_IDX]); }
template<> inline PyTypeObject* SbkType< ::QSpacerItem >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSPACERITEM_IDX]); }
template<> inline PyTypeObject* SbkType< ::QPalette::ColorGroup >() { return SbkPySide_QtGuiTypes[SBK_QPALETTE_COLORGROUP_IDX]; }
template<> inline PyTypeObject* SbkType< ::QPalette::ColorRole >() { return SbkPySide_QtGuiTypes[SBK_QPALETTE_COLORROLE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QPalette >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QPALETTE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QPrinterInfo >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QPRINTERINFO_IDX]); }
template<> inline PyTypeObject* SbkType< ::QPrintEngine::PrintEnginePropertyKey >() { return SbkPySide_QtGuiTypes[SBK_QPRINTENGINE_PRINTENGINEPROPERTYKEY_IDX]; }
template<> inline PyTypeObject* SbkType< ::QPrintEngine >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QPRINTENGINE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QPaintEngineState >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QPAINTENGINESTATE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QPaintEngine::PolygonDrawMode >() { return SbkPySide_QtGuiTypes[SBK_QPAINTENGINE_POLYGONDRAWMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QPaintEngine::Type >() { return SbkPySide_QtGuiTypes[SBK_QPAINTENGINE_TYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QPaintEngine::PaintEngineFeature >() { return SbkPySide_QtGuiTypes[SBK_QPAINTENGINE_PAINTENGINEFEATURE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QPaintEngine::PaintEngineFeature> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QPAINTENGINE_PAINTENGINEFEATURE__IDX]; }
template<> inline PyTypeObject* SbkType< ::QPaintEngine::DirtyFlag >() { return SbkPySide_QtGuiTypes[SBK_QPAINTENGINE_DIRTYFLAG_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QPaintEngine::DirtyFlag> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QPAINTENGINE_DIRTYFLAG__IDX]; }
template<> inline PyTypeObject* SbkType< ::QPaintEngine >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QPAINTENGINE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTextItem::RenderFlag >() { return SbkPySide_QtGuiTypes[SBK_QTEXTITEM_RENDERFLAG_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QTextItem::RenderFlag> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QTEXTITEM_RENDERFLAG__IDX]; }
template<> inline PyTypeObject* SbkType< ::QTextItem >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTEXTITEM_IDX]); }
template<> inline PyTypeObject* SbkType< ::QFontMetricsF >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QFONTMETRICSF_IDX]); }
template<> inline PyTypeObject* SbkType< ::QFontMetrics >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QFONTMETRICS_IDX]); }
template<> inline PyTypeObject* SbkType< ::QFontInfo >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QFONTINFO_IDX]); }
template<> inline PyTypeObject* SbkType< ::QFont::StyleStrategy >() { return SbkPySide_QtGuiTypes[SBK_QFONT_STYLESTRATEGY_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFont::SpacingType >() { return SbkPySide_QtGuiTypes[SBK_QFONT_SPACINGTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFont::StyleHint >() { return SbkPySide_QtGuiTypes[SBK_QFONT_STYLEHINT_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFont::Weight >() { return SbkPySide_QtGuiTypes[SBK_QFONT_WEIGHT_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFont::Capitalization >() { return SbkPySide_QtGuiTypes[SBK_QFONT_CAPITALIZATION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFont::Stretch >() { return SbkPySide_QtGuiTypes[SBK_QFONT_STRETCH_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFont::Style >() { return SbkPySide_QtGuiTypes[SBK_QFONT_STYLE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFont >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QFONT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTextCharFormat::VerticalAlignment >() { return SbkPySide_QtGuiTypes[SBK_QTEXTCHARFORMAT_VERTICALALIGNMENT_IDX]; }
template<> inline PyTypeObject* SbkType< ::QTextCharFormat::UnderlineStyle >() { return SbkPySide_QtGuiTypes[SBK_QTEXTCHARFORMAT_UNDERLINESTYLE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QTextCharFormat >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTEXTCHARFORMAT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTextTableCellFormat >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTEXTTABLECELLFORMAT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTextImageFormat >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTEXTIMAGEFORMAT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QPen >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QPEN_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTextOption::TabType >() { return SbkPySide_QtGuiTypes[SBK_QTEXTOPTION_TABTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QTextOption::Flag >() { return SbkPySide_QtGuiTypes[SBK_QTEXTOPTION_FLAG_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QTextOption::Flag> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QTEXTOPTION_FLAG__IDX]; }
template<> inline PyTypeObject* SbkType< ::QTextOption::WrapMode >() { return SbkPySide_QtGuiTypes[SBK_QTEXTOPTION_WRAPMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QTextOption >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTEXTOPTION_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTextOption::Tab >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTEXTOPTION_TAB_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTileRules >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTILERULES_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGradient::CoordinateMode >() { return SbkPySide_QtGuiTypes[SBK_QGRADIENT_COORDINATEMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QGradient::Spread >() { return SbkPySide_QtGuiTypes[SBK_QGRADIENT_SPREAD_IDX]; }
template<> inline PyTypeObject* SbkType< ::QGradient::Type >() { return SbkPySide_QtGuiTypes[SBK_QGRADIENT_TYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QGradient::InterpolationMode >() { return SbkPySide_QtGuiTypes[SBK_QGRADIENT_INTERPOLATIONMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QGradient >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRADIENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QConicalGradient >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QCONICALGRADIENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QRadialGradient >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QRADIALGRADIENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QLinearGradient >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QLINEARGRADIENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QBrush >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QBRUSH_IDX]); }
template<> inline PyTypeObject* SbkType< ::QPaintDevice::PaintDeviceMetric >() { return SbkPySide_QtGuiTypes[SBK_QPAINTDEVICE_PAINTDEVICEMETRIC_IDX]; }
template<> inline PyTypeObject* SbkType< ::QPaintDevice >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QPAINTDEVICE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QPrinter::OutputFormat >() { return SbkPySide_QtGuiTypes[SBK_QPRINTER_OUTPUTFORMAT_IDX]; }
template<> inline PyTypeObject* SbkType< ::QPrinter::DuplexMode >() { return SbkPySide_QtGuiTypes[SBK_QPRINTER_DUPLEXMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QPrinter::PrintRange >() { return SbkPySide_QtGuiTypes[SBK_QPRINTER_PRINTRANGE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QPrinter::Unit >() { return SbkPySide_QtGuiTypes[SBK_QPRINTER_UNIT_IDX]; }
template<> inline PyTypeObject* SbkType< ::QPrinter::PrinterMode >() { return SbkPySide_QtGuiTypes[SBK_QPRINTER_PRINTERMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QPrinter::Orientation >() { return SbkPySide_QtGuiTypes[SBK_QPRINTER_ORIENTATION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QPrinter::PrinterState >() { return SbkPySide_QtGuiTypes[SBK_QPRINTER_PRINTERSTATE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QPrinter::ColorMode >() { return SbkPySide_QtGuiTypes[SBK_QPRINTER_COLORMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QPrinter::PaperSource >() { return SbkPySide_QtGuiTypes[SBK_QPRINTER_PAPERSOURCE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QPrinter::PageOrder >() { return SbkPySide_QtGuiTypes[SBK_QPRINTER_PAGEORDER_IDX]; }
template<> inline PyTypeObject* SbkType< ::QPrinter::PageSize >() { return SbkPySide_QtGuiTypes[SBK_QPRINTER_PAGESIZE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QPrinter >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QPRINTER_IDX]); }
template<> inline PyTypeObject* SbkType< ::QPicture >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QPICTURE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTransform::TransformationType >() { return SbkPySide_QtGuiTypes[SBK_QTRANSFORM_TRANSFORMATIONTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QTransform >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTRANSFORM_IDX]); }
template<> inline PyTypeObject* SbkType< ::QPainterPathStroker >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QPAINTERPATHSTROKER_IDX]); }
template<> inline PyTypeObject* SbkType< ::QMatrix >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QMATRIX_IDX]); }
template<> inline PyTypeObject* SbkType< ::QPainterPath::ElementType >() { return SbkPySide_QtGuiTypes[SBK_QPAINTERPATH_ELEMENTTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QPainterPath >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QPAINTERPATH_IDX]); }
template<> inline PyTypeObject* SbkType< ::QPainterPath::Element >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QPAINTERPATH_ELEMENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QPolygonF >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QPOLYGONF_IDX]); }
template<> inline PyTypeObject* SbkType< ::QPolygon >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QPOLYGON_IDX]); }
template<> inline PyTypeObject* SbkType< ::QColor::Spec >() { return SbkPySide_QtGuiTypes[SBK_QCOLOR_SPEC_IDX]; }
template<> inline PyTypeObject* SbkType< ::QColor >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QCOLOR_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTextLayout::CursorMode >() { return SbkPySide_QtGuiTypes[SBK_QTEXTLAYOUT_CURSORMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QTextLayout >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTEXTLAYOUT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTextLayout::FormatRange >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTEXTLAYOUT_FORMATRANGE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QPixmap::ShareMode >() { return SbkPySide_QtGuiTypes[SBK_QPIXMAP_SHAREMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QPixmap >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QPIXMAP_IDX]); }
template<> inline PyTypeObject* SbkType< ::QImage::InvertMode >() { return SbkPySide_QtGuiTypes[SBK_QIMAGE_INVERTMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QImage::Format >() { return SbkPySide_QtGuiTypes[SBK_QIMAGE_FORMAT_IDX]; }
template<> inline PyTypeObject* SbkType< ::QImage >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QIMAGE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QBitmap >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QBITMAP_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsLayoutItem >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSLAYOUTITEM_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsLayout >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSLAYOUT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsLinearLayout >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSLINEARLAYOUT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsGridLayout >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSGRIDLAYOUT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsAnchorLayout >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSANCHORLAYOUT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsItem::CacheMode >() { return SbkPySide_QtGuiTypes[SBK_QGRAPHICSITEM_CACHEMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QGraphicsItem::PanelModality >() { return SbkPySide_QtGuiTypes[SBK_QGRAPHICSITEM_PANELMODALITY_IDX]; }
template<> inline PyTypeObject* SbkType< ::QGraphicsItem::GraphicsItemFlag >() { return SbkPySide_QtGuiTypes[SBK_QGRAPHICSITEM_GRAPHICSITEMFLAG_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QGraphicsItem::GraphicsItemFlag> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QGRAPHICSITEM_GRAPHICSITEMFLAG__IDX]; }
template<> inline PyTypeObject* SbkType< ::QGraphicsItem::GraphicsItemChange >() { return SbkPySide_QtGuiTypes[SBK_QGRAPHICSITEM_GRAPHICSITEMCHANGE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QGraphicsItem::Extension >() { return SbkPySide_QtGuiTypes[SBK_QGRAPHICSITEM_EXTENSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QGraphicsItem >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSITEM_IDX]); }
template<> inline PyTypeObject* SbkType< ::QAbstractGraphicsShapeItem >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QABSTRACTGRAPHICSSHAPEITEM_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsItemGroup >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSITEMGROUP_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsSimpleTextItem >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSSIMPLETEXTITEM_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsPixmapItem::ShapeMode >() { return SbkPySide_QtGuiTypes[SBK_QGRAPHICSPIXMAPITEM_SHAPEMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QGraphicsPixmapItem >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSPIXMAPITEM_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsLineItem >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSLINEITEM_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsPolygonItem >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSPOLYGONITEM_IDX]); }
template<> inline PyTypeObject* SbkType< ::QIcon::Mode >() { return SbkPySide_QtGuiTypes[SBK_QICON_MODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QIcon::State >() { return SbkPySide_QtGuiTypes[SBK_QICON_STATE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QIcon >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QICON_IDX]); }
template<> inline PyTypeObject* SbkType< ::QIconEngineV2::IconEngineHook >() { return SbkPySide_QtGuiTypes[SBK_QICONENGINEV2_ICONENGINEHOOK_IDX]; }
template<> inline PyTypeObject* SbkType< ::QIconEngineV2 >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QICONENGINEV2_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsRectItem >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSRECTITEM_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsPathItem >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSPATHITEM_IDX]); }
template<> inline PyTypeObject* SbkType< ::QPainter::CompositionMode >() { return SbkPySide_QtGuiTypes[SBK_QPAINTER_COMPOSITIONMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QPainter::RenderHint >() { return SbkPySide_QtGuiTypes[SBK_QPAINTER_RENDERHINT_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QPainter::RenderHint> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QPAINTER_RENDERHINT__IDX]; }
template<> inline PyTypeObject* SbkType< ::QPainter::PixmapFragmentHint >() { return SbkPySide_QtGuiTypes[SBK_QPAINTER_PIXMAPFRAGMENTHINT_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QPainter::PixmapFragmentHint> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QPAINTER_PIXMAPFRAGMENTHINT__IDX]; }
template<> inline PyTypeObject* SbkType< ::QPainter >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QPAINTER_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStylePainter >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEPAINTER_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsEllipseItem >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSELLIPSEITEM_IDX]); }
template<> inline PyTypeObject* SbkType< ::QAbstractProxyModel >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QABSTRACTPROXYMODEL_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStringListModel >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTRINGLISTMODEL_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStandardItemModel >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTANDARDITEMMODEL_IDX]); }
template<> inline PyTypeObject* SbkType< ::QSortFilterProxyModel >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSORTFILTERPROXYMODEL_IDX]); }
template<> inline PyTypeObject* SbkType< ::QFileSystemModel::Roles >() { return SbkPySide_QtGuiTypes[SBK_QFILESYSTEMMODEL_ROLES_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFileSystemModel >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QFILESYSTEMMODEL_IDX]); }
template<> inline PyTypeObject* SbkType< ::QProxyModel >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QPROXYMODEL_IDX]); }
template<> inline PyTypeObject* SbkType< ::QDirModel::Roles >() { return SbkPySide_QtGuiTypes[SBK_QDIRMODEL_ROLES_IDX]; }
template<> inline PyTypeObject* SbkType< ::QDirModel >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QDIRMODEL_IDX]); }
template<> inline PyTypeObject* SbkType< ::QApplication::Type >() { return SbkPySide_QtGuiTypes[SBK_QAPPLICATION_TYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QApplication::ColorSpec >() { return SbkPySide_QtGuiTypes[SBK_QAPPLICATION_COLORSPEC_IDX]; }
template<> inline PyTypeObject* SbkType< ::QApplication >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QAPPLICATION_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleOptionTab::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTAB_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionTab::CornerWidget >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTAB_CORNERWIDGET_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QStyleOptionTab::CornerWidget> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QSTYLEOPTIONTAB_CORNERWIDGET__IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionTab::TabPosition >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTAB_TABPOSITION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionTab::SelectedPosition >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTAB_SELECTEDPOSITION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionTab::StyleOptionType >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTAB_STYLEOPTIONTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionTab >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTAB_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleOptionTabV2::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTABV2_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionTabV2 >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTABV2_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyleOptionTabV3::StyleOptionVersion >() { return SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTABV3_STYLEOPTIONVERSION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyleOptionTabV3 >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEOPTIONTABV3_IDX]); }
template<> inline PyTypeObject* SbkType< ::QRegion::RegionType >() { return SbkPySide_QtGuiTypes[SBK_QREGION_REGIONTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QRegion >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QREGION_IDX]); }
template<> inline PyTypeObject* SbkType< ::QMouseEventTransition >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QMOUSEEVENTTRANSITION_IDX]); }
template<> inline PyTypeObject* SbkType< ::QKeyEventTransition >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QKEYEVENTTRANSITION_IDX]); }
template<> inline PyTypeObject* SbkType< ::QInputEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QINPUTEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTouchEvent::DeviceType >() { return SbkPySide_QtGuiTypes[SBK_QTOUCHEVENT_DEVICETYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QTouchEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTOUCHEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTouchEvent::TouchPoint >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTOUCHEVENT_TOUCHPOINT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QContextMenuEvent::Reason >() { return SbkPySide_QtGuiTypes[SBK_QCONTEXTMENUEVENT_REASON_IDX]; }
template<> inline PyTypeObject* SbkType< ::QContextMenuEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QCONTEXTMENUEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QKeyEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QKEYEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTabletEvent::TabletDevice >() { return SbkPySide_QtGuiTypes[SBK_QTABLETEVENT_TABLETDEVICE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QTabletEvent::PointerType >() { return SbkPySide_QtGuiTypes[SBK_QTABLETEVENT_POINTERTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QTabletEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTABLETEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QWheelEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QWHEELEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QMouseEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QMOUSEEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGestureEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGESTUREEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QWindowStateChangeEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QWINDOWSTATECHANGEEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QClipboardEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QCLIPBOARDEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QShortcutEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSHORTCUTEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QToolBarChangeEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTOOLBARCHANGEEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QFileOpenEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QFILEOPENEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QActionEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QACTIONEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QWhatsThisClickedEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QWHATSTHISCLICKEDEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStatusTipEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTATUSTIPEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QHelpEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QHELPEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QDragLeaveEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QDRAGLEAVEEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QDropEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QDROPEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QDragMoveEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QDRAGMOVEEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QDragEnterEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QDRAGENTEREVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QInputMethodEvent::AttributeType >() { return SbkPySide_QtGuiTypes[SBK_QINPUTMETHODEVENT_ATTRIBUTETYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QInputMethodEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QINPUTMETHODEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QInputMethodEvent::Attribute >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QINPUTMETHODEVENT_ATTRIBUTE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QHideEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QHIDEEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QAccessibleEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QACCESSIBLEEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QShowEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSHOWEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QIconDragEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QICONDRAGEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QCloseEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QCLOSEEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QResizeEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QRESIZEEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QMoveEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QMOVEEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsSceneEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSSCENEEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsSceneMoveEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSSCENEMOVEEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsSceneResizeEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSSCENERESIZEEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsSceneDragDropEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSSCENEDRAGDROPEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsSceneHelpEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSSCENEHELPEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsSceneHoverEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSSCENEHOVEREVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsSceneContextMenuEvent::Reason >() { return SbkPySide_QtGuiTypes[SBK_QGRAPHICSSCENECONTEXTMENUEVENT_REASON_IDX]; }
template<> inline PyTypeObject* SbkType< ::QGraphicsSceneContextMenuEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSSCENECONTEXTMENUEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsSceneWheelEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSSCENEWHEELEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsSceneMouseEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSSCENEMOUSEEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QPaintEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QPAINTEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QFocusEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QFOCUSEVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QHoverEvent >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QHOVEREVENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsAnchor >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSANCHOR_IDX]); }
template<> inline PyTypeObject* SbkType< ::QDataWidgetMapper::SubmitPolicy >() { return SbkPySide_QtGuiTypes[SBK_QDATAWIDGETMAPPER_SUBMITPOLICY_IDX]; }
template<> inline PyTypeObject* SbkType< ::QDataWidgetMapper >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QDATAWIDGETMAPPER_IDX]); }
template<> inline PyTypeObject* SbkType< ::QDrag >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QDRAG_IDX]); }
template<> inline PyTypeObject* SbkType< ::QClipboard::Mode >() { return SbkPySide_QtGuiTypes[SBK_QCLIPBOARD_MODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QClipboard >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QCLIPBOARD_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGesture::GestureCancelPolicy >() { return SbkPySide_QtGuiTypes[SBK_QGESTURE_GESTURECANCELPOLICY_IDX]; }
template<> inline PyTypeObject* SbkType< ::QGesture >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGESTURE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTapGesture >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTAPGESTURE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTapAndHoldGesture >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTAPANDHOLDGESTURE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QSwipeGesture::SwipeDirection >() { return SbkPySide_QtGuiTypes[SBK_QSWIPEGESTURE_SWIPEDIRECTION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QSwipeGesture >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSWIPEGESTURE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QPinchGesture::ChangeFlag >() { return SbkPySide_QtGuiTypes[SBK_QPINCHGESTURE_CHANGEFLAG_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QPinchGesture::ChangeFlag> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QPINCHGESTURE_CHANGEFLAG__IDX]; }
template<> inline PyTypeObject* SbkType< ::QPinchGesture >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QPINCHGESTURE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QPanGesture >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QPANGESTURE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QItemSelectionModel::SelectionFlag >() { return SbkPySide_QtGuiTypes[SBK_QITEMSELECTIONMODEL_SELECTIONFLAG_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QItemSelectionModel::SelectionFlag> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QITEMSELECTIONMODEL_SELECTIONFLAG__IDX]; }
template<> inline PyTypeObject* SbkType< ::QItemSelectionModel >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QITEMSELECTIONMODEL_IDX]); }
template<> inline PyTypeObject* SbkType< ::QLayout::SizeConstraint >() { return SbkPySide_QtGuiTypes[SBK_QLAYOUT_SIZECONSTRAINT_IDX]; }
template<> inline PyTypeObject* SbkType< ::QLayout >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QLAYOUT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QBoxLayout::Direction >() { return SbkPySide_QtGuiTypes[SBK_QBOXLAYOUT_DIRECTION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QBoxLayout >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QBOXLAYOUT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QVBoxLayout >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QVBOXLAYOUT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QHBoxLayout >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QHBOXLAYOUT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStackedLayout::StackingMode >() { return SbkPySide_QtGuiTypes[SBK_QSTACKEDLAYOUT_STACKINGMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStackedLayout >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTACKEDLAYOUT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGridLayout >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRIDLAYOUT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QFormLayout::FieldGrowthPolicy >() { return SbkPySide_QtGuiTypes[SBK_QFORMLAYOUT_FIELDGROWTHPOLICY_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFormLayout::RowWrapPolicy >() { return SbkPySide_QtGuiTypes[SBK_QFORMLAYOUT_ROWWRAPPOLICY_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFormLayout::ItemRole >() { return SbkPySide_QtGuiTypes[SBK_QFORMLAYOUT_ITEMROLE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFormLayout >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QFORMLAYOUT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QAbstractItemDelegate::EndEditHint >() { return SbkPySide_QtGuiTypes[SBK_QABSTRACTITEMDELEGATE_ENDEDITHINT_IDX]; }
template<> inline PyTypeObject* SbkType< ::QAbstractItemDelegate >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QABSTRACTITEMDELEGATE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyledItemDelegate >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLEDITEMDELEGATE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QItemDelegate >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QITEMDELEGATE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsEffect::PixmapPadMode >() { return SbkPySide_QtGuiTypes[SBK_QGRAPHICSEFFECT_PIXMAPPADMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QGraphicsEffect::ChangeFlag >() { return SbkPySide_QtGuiTypes[SBK_QGRAPHICSEFFECT_CHANGEFLAG_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QGraphicsEffect::ChangeFlag> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QGRAPHICSEFFECT_CHANGEFLAG__IDX]; }
template<> inline PyTypeObject* SbkType< ::QGraphicsEffect >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSEFFECT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsOpacityEffect >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSOPACITYEFFECT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsDropShadowEffect >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSDROPSHADOWEFFECT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsBlurEffect::BlurHint >() { return SbkPySide_QtGuiTypes[SBK_QGRAPHICSBLUREFFECT_BLURHINT_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QGraphicsBlurEffect::BlurHint> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QGRAPHICSBLUREFFECT_BLURHINT__IDX]; }
template<> inline PyTypeObject* SbkType< ::QGraphicsBlurEffect >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSBLUREFFECT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsColorizeEffect >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSCOLORIZEEFFECT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QPyTextObject >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QPYTEXTOBJECT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QInputContext::StandardFormat >() { return SbkPySide_QtGuiTypes[SBK_QINPUTCONTEXT_STANDARDFORMAT_IDX]; }
template<> inline PyTypeObject* SbkType< ::QInputContext >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QINPUTCONTEXT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QUndoStack >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QUNDOSTACK_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsObject >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSOBJECT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsWidget >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSWIDGET_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsProxyWidget >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSPROXYWIDGET_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsTextItem >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSTEXTITEM_IDX]); }
template<> inline PyTypeObject* SbkType< ::QActionGroup >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QACTIONGROUP_IDX]); }
template<> inline PyTypeObject* SbkType< ::QUndoGroup >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QUNDOGROUP_IDX]); }
template<> inline PyTypeObject* SbkType< ::QAction::Priority >() { return SbkPySide_QtGuiTypes[SBK_QACTION_PRIORITY_IDX]; }
template<> inline PyTypeObject* SbkType< ::QAction::ActionEvent >() { return SbkPySide_QtGuiTypes[SBK_QACTION_ACTIONEVENT_IDX]; }
template<> inline PyTypeObject* SbkType< ::QAction::SoftKeyRole >() { return SbkPySide_QtGuiTypes[SBK_QACTION_SOFTKEYROLE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QAction::MenuRole >() { return SbkPySide_QtGuiTypes[SBK_QACTION_MENUROLE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QAction >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QACTION_IDX]); }
template<> inline PyTypeObject* SbkType< ::QWidgetAction >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QWIDGETACTION_IDX]); }
template<> inline PyTypeObject* SbkType< ::QSystemTrayIcon::MessageIcon >() { return SbkPySide_QtGuiTypes[SBK_QSYSTEMTRAYICON_MESSAGEICON_IDX]; }
template<> inline PyTypeObject* SbkType< ::QSystemTrayIcon::ActivationReason >() { return SbkPySide_QtGuiTypes[SBK_QSYSTEMTRAYICON_ACTIVATIONREASON_IDX]; }
template<> inline PyTypeObject* SbkType< ::QSystemTrayIcon >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSYSTEMTRAYICON_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsTransform >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSTRANSFORM_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsRotation >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSROTATION_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsScale >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSSCALE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QCompleter::ModelSorting >() { return SbkPySide_QtGuiTypes[SBK_QCOMPLETER_MODELSORTING_IDX]; }
template<> inline PyTypeObject* SbkType< ::QCompleter::CompletionMode >() { return SbkPySide_QtGuiTypes[SBK_QCOMPLETER_COMPLETIONMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QCompleter >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QCOMPLETER_IDX]); }
template<> inline PyTypeObject* SbkType< ::QSyntaxHighlighter >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSYNTAXHIGHLIGHTER_IDX]); }
template<> inline PyTypeObject* SbkType< ::QValidator::State >() { return SbkPySide_QtGuiTypes[SBK_QVALIDATOR_STATE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QValidator >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QVALIDATOR_IDX]); }
template<> inline PyTypeObject* SbkType< ::QRegExpValidator >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QREGEXPVALIDATOR_IDX]); }
template<> inline PyTypeObject* SbkType< ::QDoubleValidator::Notation >() { return SbkPySide_QtGuiTypes[SBK_QDOUBLEVALIDATOR_NOTATION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QDoubleValidator >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QDOUBLEVALIDATOR_IDX]); }
template<> inline PyTypeObject* SbkType< ::QIntValidator >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QINTVALIDATOR_IDX]); }
template<> inline PyTypeObject* SbkType< ::QWidget::RenderFlag >() { return SbkPySide_QtGuiTypes[SBK_QWIDGET_RENDERFLAG_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QWidget::RenderFlag> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QWIDGET_RENDERFLAG__IDX]; }
template<> inline PyTypeObject* SbkType< ::QWidget >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QWIDGET_IDX]); }
template<> inline PyTypeObject* SbkType< ::QDesktopWidget >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QDESKTOPWIDGET_IDX]); }
template<> inline PyTypeObject* SbkType< ::QX11EmbedContainer::Error >() { return SbkPySide_QtGuiTypes[SBK_QX11EMBEDCONTAINER_ERROR_IDX]; }
template<> inline PyTypeObject* SbkType< ::QX11EmbedContainer >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QX11EMBEDCONTAINER_IDX]); }
template<> inline PyTypeObject* SbkType< ::QX11EmbedWidget::Error >() { return SbkPySide_QtGuiTypes[SBK_QX11EMBEDWIDGET_ERROR_IDX]; }
template<> inline PyTypeObject* SbkType< ::QX11EmbedWidget >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QX11EMBEDWIDGET_IDX]); }
template<> inline PyTypeObject* SbkType< ::QWorkspace::WindowOrder >() { return SbkPySide_QtGuiTypes[SBK_QWORKSPACE_WINDOWORDER_IDX]; }
template<> inline PyTypeObject* SbkType< ::QWorkspace >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QWORKSPACE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QToolBar >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTOOLBAR_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStatusBar >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTATUSBAR_IDX]); }
template<> inline PyTypeObject* SbkType< ::QSplitterHandle >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSPLITTERHANDLE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QSplashScreen >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSPLASHSCREEN_IDX]); }
template<> inline PyTypeObject* SbkType< ::QDialog::DialogCode >() { return SbkPySide_QtGuiTypes[SBK_QDIALOG_DIALOGCODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QDialog >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QDIALOG_IDX]); }
template<> inline PyTypeObject* SbkType< ::QFileDialog::FileMode >() { return SbkPySide_QtGuiTypes[SBK_QFILEDIALOG_FILEMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFileDialog::Option >() { return SbkPySide_QtGuiTypes[SBK_QFILEDIALOG_OPTION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QFileDialog::Option> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QFILEDIALOG_OPTION__IDX]; }
template<> inline PyTypeObject* SbkType< ::QFileDialog::DialogLabel >() { return SbkPySide_QtGuiTypes[SBK_QFILEDIALOG_DIALOGLABEL_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFileDialog::ViewMode >() { return SbkPySide_QtGuiTypes[SBK_QFILEDIALOG_VIEWMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFileDialog::AcceptMode >() { return SbkPySide_QtGuiTypes[SBK_QFILEDIALOG_ACCEPTMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFileDialog >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QFILEDIALOG_IDX]); }
template<> inline PyTypeObject* SbkType< ::QSizeGrip >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSIZEGRIP_IDX]); }
template<> inline PyTypeObject* SbkType< ::QProgressBar::Direction >() { return SbkPySide_QtGuiTypes[SBK_QPROGRESSBAR_DIRECTION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QProgressBar >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QPROGRESSBAR_IDX]); }
template<> inline PyTypeObject* SbkType< ::QPrintPreviewWidget::ZoomMode >() { return SbkPySide_QtGuiTypes[SBK_QPRINTPREVIEWWIDGET_ZOOMMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QPrintPreviewWidget::ViewMode >() { return SbkPySide_QtGuiTypes[SBK_QPRINTPREVIEWWIDGET_VIEWMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QPrintPreviewWidget >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QPRINTPREVIEWWIDGET_IDX]); }
template<> inline PyTypeObject* SbkType< ::QFrame::StyleMask >() { return SbkPySide_QtGuiTypes[SBK_QFRAME_STYLEMASK_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFrame::Shape >() { return SbkPySide_QtGuiTypes[SBK_QFRAME_SHAPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFrame::Shadow >() { return SbkPySide_QtGuiTypes[SBK_QFRAME_SHADOW_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFrame >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QFRAME_IDX]); }
template<> inline PyTypeObject* SbkType< ::QToolBox >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTOOLBOX_IDX]); }
template<> inline PyTypeObject* SbkType< ::QAbstractScrollArea >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QABSTRACTSCROLLAREA_IDX]); }
template<> inline PyTypeObject* SbkType< ::QAbstractItemView::DragDropMode >() { return SbkPySide_QtGuiTypes[SBK_QABSTRACTITEMVIEW_DRAGDROPMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QAbstractItemView::SelectionBehavior >() { return SbkPySide_QtGuiTypes[SBK_QABSTRACTITEMVIEW_SELECTIONBEHAVIOR_IDX]; }
template<> inline PyTypeObject* SbkType< ::QAbstractItemView::EditTrigger >() { return SbkPySide_QtGuiTypes[SBK_QABSTRACTITEMVIEW_EDITTRIGGER_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QAbstractItemView::EditTrigger> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QABSTRACTITEMVIEW_EDITTRIGGER__IDX]; }
template<> inline PyTypeObject* SbkType< ::QAbstractItemView::ScrollMode >() { return SbkPySide_QtGuiTypes[SBK_QABSTRACTITEMVIEW_SCROLLMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QAbstractItemView::CursorAction >() { return SbkPySide_QtGuiTypes[SBK_QABSTRACTITEMVIEW_CURSORACTION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QAbstractItemView::DropIndicatorPosition >() { return SbkPySide_QtGuiTypes[SBK_QABSTRACTITEMVIEW_DROPINDICATORPOSITION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QAbstractItemView::ScrollHint >() { return SbkPySide_QtGuiTypes[SBK_QABSTRACTITEMVIEW_SCROLLHINT_IDX]; }
template<> inline PyTypeObject* SbkType< ::QAbstractItemView::SelectionMode >() { return SbkPySide_QtGuiTypes[SBK_QABSTRACTITEMVIEW_SELECTIONMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QAbstractItemView::State >() { return SbkPySide_QtGuiTypes[SBK_QABSTRACTITEMVIEW_STATE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QAbstractItemView >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QABSTRACTITEMVIEW_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTableView >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTABLEVIEW_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTableWidget >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTABLEWIDGET_IDX]); }
template<> inline PyTypeObject* SbkType< ::QColumnView >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QCOLUMNVIEW_IDX]); }
template<> inline PyTypeObject* SbkType< ::QListView::ResizeMode >() { return SbkPySide_QtGuiTypes[SBK_QLISTVIEW_RESIZEMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QListView::LayoutMode >() { return SbkPySide_QtGuiTypes[SBK_QLISTVIEW_LAYOUTMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QListView::ViewMode >() { return SbkPySide_QtGuiTypes[SBK_QLISTVIEW_VIEWMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QListView::Flow >() { return SbkPySide_QtGuiTypes[SBK_QLISTVIEW_FLOW_IDX]; }
template<> inline PyTypeObject* SbkType< ::QListView::Movement >() { return SbkPySide_QtGuiTypes[SBK_QLISTVIEW_MOVEMENT_IDX]; }
template<> inline PyTypeObject* SbkType< ::QListView >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QLISTVIEW_IDX]); }
template<> inline PyTypeObject* SbkType< ::QUndoView >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QUNDOVIEW_IDX]); }
template<> inline PyTypeObject* SbkType< ::QListWidget >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QLISTWIDGET_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTreeView >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTREEVIEW_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTreeWidget >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTREEWIDGET_IDX]); }
template<> inline PyTypeObject* SbkType< ::QHeaderView::ResizeMode >() { return SbkPySide_QtGuiTypes[SBK_QHEADERVIEW_RESIZEMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QHeaderView >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QHEADERVIEW_IDX]); }
template<> inline PyTypeObject* SbkType< ::QScrollArea >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSCROLLAREA_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStackedWidget >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTACKEDWIDGET_IDX]); }
template<> inline PyTypeObject* SbkType< ::QSplitter >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSPLITTER_IDX]); }
template<> inline PyTypeObject* SbkType< ::QPlainTextEdit::LineWrapMode >() { return SbkPySide_QtGuiTypes[SBK_QPLAINTEXTEDIT_LINEWRAPMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QPlainTextEdit >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QPLAINTEXTEDIT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QRubberBand::Shape >() { return SbkPySide_QtGuiTypes[SBK_QRUBBERBAND_SHAPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QRubberBand >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QRUBBERBAND_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTextEdit::AutoFormattingFlag >() { return SbkPySide_QtGuiTypes[SBK_QTEXTEDIT_AUTOFORMATTINGFLAG_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QTextEdit::AutoFormattingFlag> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QTEXTEDIT_AUTOFORMATTINGFLAG__IDX]; }
template<> inline PyTypeObject* SbkType< ::QTextEdit::LineWrapMode >() { return SbkPySide_QtGuiTypes[SBK_QTEXTEDIT_LINEWRAPMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QTextEdit >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTEXTEDIT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTextEdit::ExtraSelection >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTEXTEDIT_EXTRASELECTION_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTextBrowser >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTEXTBROWSER_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTabWidget::TabShape >() { return SbkPySide_QtGuiTypes[SBK_QTABWIDGET_TABSHAPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QTabWidget::TabPosition >() { return SbkPySide_QtGuiTypes[SBK_QTABWIDGET_TABPOSITION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QTabWidget >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTABWIDGET_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTabBar::SelectionBehavior >() { return SbkPySide_QtGuiTypes[SBK_QTABBAR_SELECTIONBEHAVIOR_IDX]; }
template<> inline PyTypeObject* SbkType< ::QTabBar::ButtonPosition >() { return SbkPySide_QtGuiTypes[SBK_QTABBAR_BUTTONPOSITION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QTabBar::Shape >() { return SbkPySide_QtGuiTypes[SBK_QTABBAR_SHAPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QTabBar >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTABBAR_IDX]); }
template<> inline PyTypeObject* SbkType< ::QMenuBar >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QMENUBAR_IDX]); }
template<> inline PyTypeObject* SbkType< ::QMenu >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QMENU_IDX]); }
template<> inline PyTypeObject* SbkType< ::QAbstractSlider::SliderAction >() { return SbkPySide_QtGuiTypes[SBK_QABSTRACTSLIDER_SLIDERACTION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QAbstractSlider::SliderChange >() { return SbkPySide_QtGuiTypes[SBK_QABSTRACTSLIDER_SLIDERCHANGE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QAbstractSlider >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QABSTRACTSLIDER_IDX]); }
template<> inline PyTypeObject* SbkType< ::QSlider::TickPosition >() { return SbkPySide_QtGuiTypes[SBK_QSLIDER_TICKPOSITION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QSlider >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSLIDER_IDX]); }
template<> inline PyTypeObject* SbkType< ::QScrollBar >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSCROLLBAR_IDX]); }
template<> inline PyTypeObject* SbkType< ::QMdiSubWindow::SubWindowOption >() { return SbkPySide_QtGuiTypes[SBK_QMDISUBWINDOW_SUBWINDOWOPTION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QMdiSubWindow::SubWindowOption> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QMDISUBWINDOW_SUBWINDOWOPTION__IDX]; }
template<> inline PyTypeObject* SbkType< ::QMdiSubWindow >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QMDISUBWINDOW_IDX]); }
template<> inline PyTypeObject* SbkType< ::QAbstractSpinBox::StepEnabledFlag >() { return SbkPySide_QtGuiTypes[SBK_QABSTRACTSPINBOX_STEPENABLEDFLAG_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QAbstractSpinBox::StepEnabledFlag> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QABSTRACTSPINBOX_STEPENABLEDFLAG__IDX]; }
template<> inline PyTypeObject* SbkType< ::QAbstractSpinBox::CorrectionMode >() { return SbkPySide_QtGuiTypes[SBK_QABSTRACTSPINBOX_CORRECTIONMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QAbstractSpinBox::ButtonSymbols >() { return SbkPySide_QtGuiTypes[SBK_QABSTRACTSPINBOX_BUTTONSYMBOLS_IDX]; }
template<> inline PyTypeObject* SbkType< ::QAbstractSpinBox >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QABSTRACTSPINBOX_IDX]); }
template<> inline PyTypeObject* SbkType< ::QDoubleSpinBox >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QDOUBLESPINBOX_IDX]); }
template<> inline PyTypeObject* SbkType< ::QSpinBox >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSPINBOX_IDX]); }
template<> inline PyTypeObject* SbkType< ::QMdiArea::WindowOrder >() { return SbkPySide_QtGuiTypes[SBK_QMDIAREA_WINDOWORDER_IDX]; }
template<> inline PyTypeObject* SbkType< ::QMdiArea::ViewMode >() { return SbkPySide_QtGuiTypes[SBK_QMDIAREA_VIEWMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QMdiArea::AreaOption >() { return SbkPySide_QtGuiTypes[SBK_QMDIAREA_AREAOPTION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QMdiArea::AreaOption> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QMDIAREA_AREAOPTION__IDX]; }
template<> inline PyTypeObject* SbkType< ::QMdiArea >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QMDIAREA_IDX]); }
template<> inline PyTypeObject* SbkType< ::QMainWindow::DockOption >() { return SbkPySide_QtGuiTypes[SBK_QMAINWINDOW_DOCKOPTION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QMainWindow::DockOption> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QMAINWINDOW_DOCKOPTION__IDX]; }
template<> inline PyTypeObject* SbkType< ::QMainWindow >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QMAINWINDOW_IDX]); }
template<> inline PyTypeObject* SbkType< ::QLCDNumber::Mode >() { return SbkPySide_QtGuiTypes[SBK_QLCDNUMBER_MODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QLCDNumber::SegmentStyle >() { return SbkPySide_QtGuiTypes[SBK_QLCDNUMBER_SEGMENTSTYLE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QLCDNumber >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QLCDNUMBER_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGroupBox >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGROUPBOX_IDX]); }
template<> inline PyTypeObject* SbkType< ::QLabel >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QLABEL_IDX]); }
template<> inline PyTypeObject* SbkType< ::QFocusFrame >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QFOCUSFRAME_IDX]); }
template<> inline PyTypeObject* SbkType< ::QDockWidget::DockWidgetFeature >() { return SbkPySide_QtGuiTypes[SBK_QDOCKWIDGET_DOCKWIDGETFEATURE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QDockWidget::DockWidgetFeature> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QDOCKWIDGET_DOCKWIDGETFEATURE__IDX]; }
template<> inline PyTypeObject* SbkType< ::QDockWidget >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QDOCKWIDGET_IDX]); }
template<> inline PyTypeObject* SbkType< ::QDialogButtonBox::ButtonLayout >() { return SbkPySide_QtGuiTypes[SBK_QDIALOGBUTTONBOX_BUTTONLAYOUT_IDX]; }
template<> inline PyTypeObject* SbkType< ::QDialogButtonBox::ButtonRole >() { return SbkPySide_QtGuiTypes[SBK_QDIALOGBUTTONBOX_BUTTONROLE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QDialogButtonBox::StandardButton >() { return SbkPySide_QtGuiTypes[SBK_QDIALOGBUTTONBOX_STANDARDBUTTON_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QDialogButtonBox::StandardButton> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QDIALOGBUTTONBOX_STANDARDBUTTON__IDX]; }
template<> inline PyTypeObject* SbkType< ::QDialogButtonBox >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QDIALOGBUTTONBOX_IDX]); }
template<> inline PyTypeObject* SbkType< ::QDial >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QDIAL_IDX]); }
template<> inline PyTypeObject* SbkType< ::QDateTimeEdit::Section >() { return SbkPySide_QtGuiTypes[SBK_QDATETIMEEDIT_SECTION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QDateTimeEdit::Section> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QDATETIMEEDIT_SECTION__IDX]; }
template<> inline PyTypeObject* SbkType< ::QDateTimeEdit >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QDATETIMEEDIT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QDateEdit >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QDATEEDIT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTimeEdit >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTIMEEDIT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QComboBox::InsertPolicy >() { return SbkPySide_QtGuiTypes[SBK_QCOMBOBOX_INSERTPOLICY_IDX]; }
template<> inline PyTypeObject* SbkType< ::QComboBox::SizeAdjustPolicy >() { return SbkPySide_QtGuiTypes[SBK_QCOMBOBOX_SIZEADJUSTPOLICY_IDX]; }
template<> inline PyTypeObject* SbkType< ::QComboBox >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QCOMBOBOX_IDX]); }
template<> inline PyTypeObject* SbkType< ::QFontComboBox::FontFilter >() { return SbkPySide_QtGuiTypes[SBK_QFONTCOMBOBOX_FONTFILTER_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QFontComboBox::FontFilter> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QFONTCOMBOBOX_FONTFILTER__IDX]; }
template<> inline PyTypeObject* SbkType< ::QFontComboBox >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QFONTCOMBOBOX_IDX]); }
template<> inline PyTypeObject* SbkType< ::QCalendarWidget::HorizontalHeaderFormat >() { return SbkPySide_QtGuiTypes[SBK_QCALENDARWIDGET_HORIZONTALHEADERFORMAT_IDX]; }
template<> inline PyTypeObject* SbkType< ::QCalendarWidget::VerticalHeaderFormat >() { return SbkPySide_QtGuiTypes[SBK_QCALENDARWIDGET_VERTICALHEADERFORMAT_IDX]; }
template<> inline PyTypeObject* SbkType< ::QCalendarWidget::SelectionMode >() { return SbkPySide_QtGuiTypes[SBK_QCALENDARWIDGET_SELECTIONMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QCalendarWidget >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QCALENDARWIDGET_IDX]); }
template<> inline PyTypeObject* SbkType< ::QAbstractButton >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QABSTRACTBUTTON_IDX]); }
template<> inline PyTypeObject* SbkType< ::QRadioButton >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QRADIOBUTTON_IDX]); }
template<> inline PyTypeObject* SbkType< ::QToolButton::ToolButtonPopupMode >() { return SbkPySide_QtGuiTypes[SBK_QTOOLBUTTON_TOOLBUTTONPOPUPMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QToolButton >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTOOLBUTTON_IDX]); }
template<> inline PyTypeObject* SbkType< ::QPushButton >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QPUSHBUTTON_IDX]); }
template<> inline PyTypeObject* SbkType< ::QCommandLinkButton >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QCOMMANDLINKBUTTON_IDX]); }
template<> inline PyTypeObject* SbkType< ::QCheckBox >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QCHECKBOX_IDX]); }
template<> inline PyTypeObject* SbkType< ::QWizardPage >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QWIZARDPAGE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QWizard::WizardButton >() { return SbkPySide_QtGuiTypes[SBK_QWIZARD_WIZARDBUTTON_IDX]; }
template<> inline PyTypeObject* SbkType< ::QWizard::WizardStyle >() { return SbkPySide_QtGuiTypes[SBK_QWIZARD_WIZARDSTYLE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QWizard::WizardPixmap >() { return SbkPySide_QtGuiTypes[SBK_QWIZARD_WIZARDPIXMAP_IDX]; }
template<> inline PyTypeObject* SbkType< ::QWizard::WizardOption >() { return SbkPySide_QtGuiTypes[SBK_QWIZARD_WIZARDOPTION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QWizard::WizardOption> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QWIZARD_WIZARDOPTION__IDX]; }
template<> inline PyTypeObject* SbkType< ::QWizard >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QWIZARD_IDX]); }
template<> inline PyTypeObject* SbkType< ::QProgressDialog >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QPROGRESSDIALOG_IDX]); }
template<> inline PyTypeObject* SbkType< ::QPrintPreviewDialog >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QPRINTPREVIEWDIALOG_IDX]); }
template<> inline PyTypeObject* SbkType< ::QMessageBox::ButtonRole >() { return SbkPySide_QtGuiTypes[SBK_QMESSAGEBOX_BUTTONROLE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QMessageBox::StandardButton >() { return SbkPySide_QtGuiTypes[SBK_QMESSAGEBOX_STANDARDBUTTON_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QMessageBox::StandardButton> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QMESSAGEBOX_STANDARDBUTTON__IDX]; }
template<> inline PyTypeObject* SbkType< ::QMessageBox::Icon >() { return SbkPySide_QtGuiTypes[SBK_QMESSAGEBOX_ICON_IDX]; }
template<> inline PyTypeObject* SbkType< ::QMessageBox >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QMESSAGEBOX_IDX]); }
template<> inline PyTypeObject* SbkType< ::QLineEdit::EchoMode >() { return SbkPySide_QtGuiTypes[SBK_QLINEEDIT_ECHOMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QLineEdit >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QLINEEDIT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QInputDialog::InputMode >() { return SbkPySide_QtGuiTypes[SBK_QINPUTDIALOG_INPUTMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QInputDialog::InputDialogOption >() { return SbkPySide_QtGuiTypes[SBK_QINPUTDIALOG_INPUTDIALOGOPTION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QInputDialog >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QINPUTDIALOG_IDX]); }
template<> inline PyTypeObject* SbkType< ::QFontDialog::FontDialogOption >() { return SbkPySide_QtGuiTypes[SBK_QFONTDIALOG_FONTDIALOGOPTION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QFontDialog::FontDialogOption> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QFONTDIALOG_FONTDIALOGOPTION__IDX]; }
template<> inline PyTypeObject* SbkType< ::QFontDialog >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QFONTDIALOG_IDX]); }
template<> inline PyTypeObject* SbkType< ::QErrorMessage >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QERRORMESSAGE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QColorDialog::ColorDialogOption >() { return SbkPySide_QtGuiTypes[SBK_QCOLORDIALOG_COLORDIALOGOPTION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QColorDialog::ColorDialogOption> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QCOLORDIALOG_COLORDIALOGOPTION__IDX]; }
template<> inline PyTypeObject* SbkType< ::QColorDialog >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QCOLORDIALOG_IDX]); }
template<> inline PyTypeObject* SbkType< ::QAbstractPrintDialog::PrintRange >() { return SbkPySide_QtGuiTypes[SBK_QABSTRACTPRINTDIALOG_PRINTRANGE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QAbstractPrintDialog::PrintDialogOption >() { return SbkPySide_QtGuiTypes[SBK_QABSTRACTPRINTDIALOG_PRINTDIALOGOPTION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QAbstractPrintDialog::PrintDialogOption> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QABSTRACTPRINTDIALOG_PRINTDIALOGOPTION__IDX]; }
template<> inline PyTypeObject* SbkType< ::QAbstractPrintDialog >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QABSTRACTPRINTDIALOG_IDX]); }
template<> inline PyTypeObject* SbkType< ::QPrintDialog >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QPRINTDIALOG_IDX]); }
template<> inline PyTypeObject* SbkType< ::QAbstractPageSetupDialog >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QABSTRACTPAGESETUPDIALOG_IDX]); }
template<> inline PyTypeObject* SbkType< ::QPageSetupDialog::PageSetupDialogOption >() { return SbkPySide_QtGuiTypes[SBK_QPAGESETUPDIALOG_PAGESETUPDIALOGOPTION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QPageSetupDialog::PageSetupDialogOption> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QPAGESETUPDIALOG_PAGESETUPDIALOGOPTION__IDX]; }
template<> inline PyTypeObject* SbkType< ::QPageSetupDialog >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QPAGESETUPDIALOG_IDX]); }
template<> inline PyTypeObject* SbkType< ::QStyle::PixelMetric >() { return SbkPySide_QtGuiTypes[SBK_QSTYLE_PIXELMETRIC_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyle::SubControl >() { return SbkPySide_QtGuiTypes[SBK_QSTYLE_SUBCONTROL_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QStyle::SubControl> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QSTYLE_SUBCONTROL__IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyle::StandardPixmap >() { return SbkPySide_QtGuiTypes[SBK_QSTYLE_STANDARDPIXMAP_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyle::StyleHint >() { return SbkPySide_QtGuiTypes[SBK_QSTYLE_STYLEHINT_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyle::PrimitiveElement >() { return SbkPySide_QtGuiTypes[SBK_QSTYLE_PRIMITIVEELEMENT_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyle::ControlElement >() { return SbkPySide_QtGuiTypes[SBK_QSTYLE_CONTROLELEMENT_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyle::ContentsType >() { return SbkPySide_QtGuiTypes[SBK_QSTYLE_CONTENTSTYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyle::StateFlag >() { return SbkPySide_QtGuiTypes[SBK_QSTYLE_STATEFLAG_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QStyle::StateFlag> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QSTYLE_STATEFLAG__IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyle::ComplexControl >() { return SbkPySide_QtGuiTypes[SBK_QSTYLE_COMPLEXCONTROL_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyle::RequestSoftwareInputPanel >() { return SbkPySide_QtGuiTypes[SBK_QSTYLE_REQUESTSOFTWAREINPUTPANEL_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyle::SubElement >() { return SbkPySide_QtGuiTypes[SBK_QSTYLE_SUBELEMENT_IDX]; }
template<> inline PyTypeObject* SbkType< ::QStyle >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSTYLE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QCommonStyle >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QCOMMONSTYLE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QWindowsStyle >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QWINDOWSSTYLE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QPlastiqueStyle >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QPLASTIQUESTYLE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QCleanlooksStyle >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QCLEANLOOKSSTYLE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QMotifStyle >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QMOTIFSTYLE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QCDEStyle >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QCDESTYLE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTextObject >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTEXTOBJECT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTextFrame >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTEXTFRAME_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTextTable >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTEXTTABLE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTextFrame::iterator >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTEXTFRAME_ITERATOR_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTextBlockGroup >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTEXTBLOCKGROUP_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTextList >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTEXTLIST_IDX]); }
template<> inline PyTypeObject* SbkType< ::QAbstractTextDocumentLayout >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QABSTRACTTEXTDOCUMENTLAYOUT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QAbstractTextDocumentLayout::Selection >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QABSTRACTTEXTDOCUMENTLAYOUT_SELECTION_IDX]); }
template<> inline PyTypeObject* SbkType< ::QAbstractTextDocumentLayout::PaintContext >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QABSTRACTTEXTDOCUMENTLAYOUT_PAINTCONTEXT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QPlainTextDocumentLayout >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QPLAINTEXTDOCUMENTLAYOUT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QButtonGroup >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QBUTTONGROUP_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsScene::SceneLayer >() { return SbkPySide_QtGuiTypes[SBK_QGRAPHICSSCENE_SCENELAYER_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QGraphicsScene::SceneLayer> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QGRAPHICSSCENE_SCENELAYER__IDX]; }
template<> inline PyTypeObject* SbkType< ::QGraphicsScene::ItemIndexMethod >() { return SbkPySide_QtGuiTypes[SBK_QGRAPHICSSCENE_ITEMINDEXMETHOD_IDX]; }
template<> inline PyTypeObject* SbkType< ::QGraphicsScene >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSSCENE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsView::OptimizationFlag >() { return SbkPySide_QtGuiTypes[SBK_QGRAPHICSVIEW_OPTIMIZATIONFLAG_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QGraphicsView::OptimizationFlag> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QGRAPHICSVIEW_OPTIMIZATIONFLAG__IDX]; }
template<> inline PyTypeObject* SbkType< ::QGraphicsView::ViewportAnchor >() { return SbkPySide_QtGuiTypes[SBK_QGRAPHICSVIEW_VIEWPORTANCHOR_IDX]; }
template<> inline PyTypeObject* SbkType< ::QGraphicsView::ViewportUpdateMode >() { return SbkPySide_QtGuiTypes[SBK_QGRAPHICSVIEW_VIEWPORTUPDATEMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QGraphicsView::CacheModeFlag >() { return SbkPySide_QtGuiTypes[SBK_QGRAPHICSVIEW_CACHEMODEFLAG_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QGraphicsView::CacheModeFlag> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QGRAPHICSVIEW_CACHEMODEFLAG__IDX]; }
template<> inline PyTypeObject* SbkType< ::QGraphicsView::DragMode >() { return SbkPySide_QtGuiTypes[SBK_QGRAPHICSVIEW_DRAGMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QGraphicsView >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSVIEW_IDX]); }
template<> inline PyTypeObject* SbkType< ::QSound >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSOUND_IDX]); }
template<> inline PyTypeObject* SbkType< ::QShortcut >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSHORTCUT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QSessionManager::RestartHint >() { return SbkPySide_QtGuiTypes[SBK_QSESSIONMANAGER_RESTARTHINT_IDX]; }
template<> inline PyTypeObject* SbkType< ::QSessionManager >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QSESSIONMANAGER_IDX]); }
template<> inline PyTypeObject* SbkType< ::QGraphicsItemAnimation >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QGRAPHICSITEMANIMATION_IDX]); }
template<> inline PyTypeObject* SbkType< ::QTextDocument::ResourceType >() { return SbkPySide_QtGuiTypes[SBK_QTEXTDOCUMENT_RESOURCETYPE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QTextDocument::Stacks >() { return SbkPySide_QtGuiTypes[SBK_QTEXTDOCUMENT_STACKS_IDX]; }
template<> inline PyTypeObject* SbkType< ::QTextDocument::FindFlag >() { return SbkPySide_QtGuiTypes[SBK_QTEXTDOCUMENT_FINDFLAG_IDX]; }
template<> inline PyTypeObject* SbkType< ::QFlags<QTextDocument::FindFlag> >() { return SbkPySide_QtGuiTypes[SBK_QFLAGS_QTEXTDOCUMENT_FINDFLAG__IDX]; }
template<> inline PyTypeObject* SbkType< ::QTextDocument::MetaInformation >() { return SbkPySide_QtGuiTypes[SBK_QTEXTDOCUMENT_METAINFORMATION_IDX]; }
template<> inline PyTypeObject* SbkType< ::QTextDocument >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QTEXTDOCUMENT_IDX]); }
template<> inline PyTypeObject* SbkType< ::QMovie::CacheMode >() { return SbkPySide_QtGuiTypes[SBK_QMOVIE_CACHEMODE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QMovie::MovieState >() { return SbkPySide_QtGuiTypes[SBK_QMOVIE_MOVIESTATE_IDX]; }
template<> inline PyTypeObject* SbkType< ::QMovie >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QMOVIE_IDX]); }
template<> inline PyTypeObject* SbkType< ::QImageWriter::ImageWriterError >() { return SbkPySide_QtGuiTypes[SBK_QIMAGEWRITER_IMAGEWRITERERROR_IDX]; }
template<> inline PyTypeObject* SbkType< ::QImageWriter >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QIMAGEWRITER_IDX]); }
template<> inline PyTypeObject* SbkType< ::QImageReader::ImageReaderError >() { return SbkPySide_QtGuiTypes[SBK_QIMAGEREADER_IMAGEREADERERROR_IDX]; }
template<> inline PyTypeObject* SbkType< ::QImageReader >() { return reinterpret_cast<PyTypeObject*>(SbkPySide_QtGuiTypes[SBK_QIMAGEREADER_IDX]); }

template<>
inline PyObject* createWrapper<QAbstractProxyModel >(const QAbstractProxyModel* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QAbstractProxyModel* value = const_cast<QAbstractProxyModel* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QAbstractProxyModel >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QStringListModel >(const QStringListModel* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QStringListModel* value = const_cast<QStringListModel* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QStringListModel >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QStandardItemModel >(const QStandardItemModel* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QStandardItemModel* value = const_cast<QStandardItemModel* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QStandardItemModel >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QSortFilterProxyModel >(const QSortFilterProxyModel* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QSortFilterProxyModel* value = const_cast<QSortFilterProxyModel* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QSortFilterProxyModel >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QFileSystemModel >(const QFileSystemModel* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QFileSystemModel* value = const_cast<QFileSystemModel* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QFileSystemModel >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QProxyModel >(const QProxyModel* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QProxyModel* value = const_cast<QProxyModel* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QProxyModel >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QDirModel >(const QDirModel* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QDirModel* value = const_cast<QDirModel* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QDirModel >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QApplication >(const QApplication* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QApplication* value = const_cast<QApplication* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QApplication >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QMouseEventTransition >(const QMouseEventTransition* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QMouseEventTransition* value = const_cast<QMouseEventTransition* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QMouseEventTransition >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QKeyEventTransition >(const QKeyEventTransition* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QKeyEventTransition* value = const_cast<QKeyEventTransition* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QKeyEventTransition >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QGraphicsAnchor >(const QGraphicsAnchor* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QGraphicsAnchor* value = const_cast<QGraphicsAnchor* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QGraphicsAnchor >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QDataWidgetMapper >(const QDataWidgetMapper* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QDataWidgetMapper* value = const_cast<QDataWidgetMapper* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QDataWidgetMapper >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QDrag >(const QDrag* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QDrag* value = const_cast<QDrag* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QDrag >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QClipboard >(const QClipboard* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QClipboard* value = const_cast<QClipboard* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QClipboard >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QGesture >(const QGesture* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QGesture* value = const_cast<QGesture* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QGesture >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QTapGesture >(const QTapGesture* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QTapGesture* value = const_cast<QTapGesture* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QTapGesture >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QTapAndHoldGesture >(const QTapAndHoldGesture* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QTapAndHoldGesture* value = const_cast<QTapAndHoldGesture* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QTapAndHoldGesture >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QSwipeGesture >(const QSwipeGesture* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QSwipeGesture* value = const_cast<QSwipeGesture* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QSwipeGesture >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QPinchGesture >(const QPinchGesture* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QPinchGesture* value = const_cast<QPinchGesture* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QPinchGesture >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QPanGesture >(const QPanGesture* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QPanGesture* value = const_cast<QPanGesture* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QPanGesture >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QItemSelectionModel >(const QItemSelectionModel* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QItemSelectionModel* value = const_cast<QItemSelectionModel* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QItemSelectionModel >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QLayout >(const QLayout* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QLayout* value = const_cast<QLayout* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QLayout >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QBoxLayout >(const QBoxLayout* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QBoxLayout* value = const_cast<QBoxLayout* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QBoxLayout >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QVBoxLayout >(const QVBoxLayout* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QVBoxLayout* value = const_cast<QVBoxLayout* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QVBoxLayout >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QHBoxLayout >(const QHBoxLayout* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QHBoxLayout* value = const_cast<QHBoxLayout* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QHBoxLayout >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QStackedLayout >(const QStackedLayout* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QStackedLayout* value = const_cast<QStackedLayout* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QStackedLayout >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QGridLayout >(const QGridLayout* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QGridLayout* value = const_cast<QGridLayout* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QGridLayout >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QFormLayout >(const QFormLayout* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QFormLayout* value = const_cast<QFormLayout* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QFormLayout >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QAbstractItemDelegate >(const QAbstractItemDelegate* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QAbstractItemDelegate* value = const_cast<QAbstractItemDelegate* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QAbstractItemDelegate >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QStyledItemDelegate >(const QStyledItemDelegate* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QStyledItemDelegate* value = const_cast<QStyledItemDelegate* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QStyledItemDelegate >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QItemDelegate >(const QItemDelegate* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QItemDelegate* value = const_cast<QItemDelegate* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QItemDelegate >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QGraphicsEffect >(const QGraphicsEffect* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QGraphicsEffect* value = const_cast<QGraphicsEffect* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QGraphicsEffect >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QGraphicsOpacityEffect >(const QGraphicsOpacityEffect* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QGraphicsOpacityEffect* value = const_cast<QGraphicsOpacityEffect* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QGraphicsOpacityEffect >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QGraphicsDropShadowEffect >(const QGraphicsDropShadowEffect* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QGraphicsDropShadowEffect* value = const_cast<QGraphicsDropShadowEffect* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QGraphicsDropShadowEffect >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QGraphicsBlurEffect >(const QGraphicsBlurEffect* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QGraphicsBlurEffect* value = const_cast<QGraphicsBlurEffect* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QGraphicsBlurEffect >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QGraphicsColorizeEffect >(const QGraphicsColorizeEffect* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QGraphicsColorizeEffect* value = const_cast<QGraphicsColorizeEffect* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QGraphicsColorizeEffect >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QPyTextObject >(const QPyTextObject* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QPyTextObject* value = const_cast<QPyTextObject* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QPyTextObject >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QInputContext >(const QInputContext* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QInputContext* value = const_cast<QInputContext* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QInputContext >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QUndoStack >(const QUndoStack* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QUndoStack* value = const_cast<QUndoStack* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QUndoStack >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QGraphicsObject >(const QGraphicsObject* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QGraphicsObject* value = const_cast<QGraphicsObject* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QGraphicsObject >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QGraphicsWidget >(const QGraphicsWidget* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QGraphicsWidget* value = const_cast<QGraphicsWidget* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QGraphicsWidget >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QGraphicsProxyWidget >(const QGraphicsProxyWidget* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QGraphicsProxyWidget* value = const_cast<QGraphicsProxyWidget* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QGraphicsProxyWidget >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QGraphicsTextItem >(const QGraphicsTextItem* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QGraphicsTextItem* value = const_cast<QGraphicsTextItem* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QGraphicsTextItem >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QActionGroup >(const QActionGroup* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QActionGroup* value = const_cast<QActionGroup* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QActionGroup >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QUndoGroup >(const QUndoGroup* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QUndoGroup* value = const_cast<QUndoGroup* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QUndoGroup >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QAction >(const QAction* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QAction* value = const_cast<QAction* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QAction >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QWidgetAction >(const QWidgetAction* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QWidgetAction* value = const_cast<QWidgetAction* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QWidgetAction >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QSystemTrayIcon >(const QSystemTrayIcon* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QSystemTrayIcon* value = const_cast<QSystemTrayIcon* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QSystemTrayIcon >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QGraphicsTransform >(const QGraphicsTransform* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QGraphicsTransform* value = const_cast<QGraphicsTransform* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QGraphicsTransform >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QGraphicsRotation >(const QGraphicsRotation* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QGraphicsRotation* value = const_cast<QGraphicsRotation* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QGraphicsRotation >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QGraphicsScale >(const QGraphicsScale* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QGraphicsScale* value = const_cast<QGraphicsScale* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QGraphicsScale >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QCompleter >(const QCompleter* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QCompleter* value = const_cast<QCompleter* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QCompleter >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QSyntaxHighlighter >(const QSyntaxHighlighter* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QSyntaxHighlighter* value = const_cast<QSyntaxHighlighter* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QSyntaxHighlighter >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QValidator >(const QValidator* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QValidator* value = const_cast<QValidator* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QValidator >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QRegExpValidator >(const QRegExpValidator* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QRegExpValidator* value = const_cast<QRegExpValidator* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QRegExpValidator >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QDoubleValidator >(const QDoubleValidator* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QDoubleValidator* value = const_cast<QDoubleValidator* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QDoubleValidator >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QIntValidator >(const QIntValidator* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QIntValidator* value = const_cast<QIntValidator* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QIntValidator >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QWidget >(const QWidget* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QWidget* value = const_cast<QWidget* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QWidget >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QDesktopWidget >(const QDesktopWidget* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QDesktopWidget* value = const_cast<QDesktopWidget* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QDesktopWidget >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QX11EmbedContainer >(const QX11EmbedContainer* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QX11EmbedContainer* value = const_cast<QX11EmbedContainer* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QX11EmbedContainer >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QX11EmbedWidget >(const QX11EmbedWidget* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QX11EmbedWidget* value = const_cast<QX11EmbedWidget* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QX11EmbedWidget >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QWorkspace >(const QWorkspace* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QWorkspace* value = const_cast<QWorkspace* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QWorkspace >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QToolBar >(const QToolBar* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QToolBar* value = const_cast<QToolBar* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QToolBar >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QStatusBar >(const QStatusBar* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QStatusBar* value = const_cast<QStatusBar* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QStatusBar >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QSplitterHandle >(const QSplitterHandle* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QSplitterHandle* value = const_cast<QSplitterHandle* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QSplitterHandle >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QSplashScreen >(const QSplashScreen* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QSplashScreen* value = const_cast<QSplashScreen* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QSplashScreen >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QDialog >(const QDialog* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QDialog* value = const_cast<QDialog* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QDialog >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QFileDialog >(const QFileDialog* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QFileDialog* value = const_cast<QFileDialog* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QFileDialog >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QSizeGrip >(const QSizeGrip* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QSizeGrip* value = const_cast<QSizeGrip* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QSizeGrip >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QProgressBar >(const QProgressBar* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QProgressBar* value = const_cast<QProgressBar* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QProgressBar >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QPrintPreviewWidget >(const QPrintPreviewWidget* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QPrintPreviewWidget* value = const_cast<QPrintPreviewWidget* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QPrintPreviewWidget >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QFrame >(const QFrame* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QFrame* value = const_cast<QFrame* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QFrame >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QToolBox >(const QToolBox* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QToolBox* value = const_cast<QToolBox* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QToolBox >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QAbstractScrollArea >(const QAbstractScrollArea* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QAbstractScrollArea* value = const_cast<QAbstractScrollArea* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QAbstractScrollArea >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QAbstractItemView >(const QAbstractItemView* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QAbstractItemView* value = const_cast<QAbstractItemView* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QAbstractItemView >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QTableView >(const QTableView* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QTableView* value = const_cast<QTableView* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QTableView >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QTableWidget >(const QTableWidget* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QTableWidget* value = const_cast<QTableWidget* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QTableWidget >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QColumnView >(const QColumnView* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QColumnView* value = const_cast<QColumnView* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QColumnView >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QListView >(const QListView* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QListView* value = const_cast<QListView* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QListView >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QUndoView >(const QUndoView* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QUndoView* value = const_cast<QUndoView* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QUndoView >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QListWidget >(const QListWidget* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QListWidget* value = const_cast<QListWidget* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QListWidget >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QTreeView >(const QTreeView* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QTreeView* value = const_cast<QTreeView* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QTreeView >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QTreeWidget >(const QTreeWidget* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QTreeWidget* value = const_cast<QTreeWidget* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QTreeWidget >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QHeaderView >(const QHeaderView* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QHeaderView* value = const_cast<QHeaderView* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QHeaderView >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QScrollArea >(const QScrollArea* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QScrollArea* value = const_cast<QScrollArea* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QScrollArea >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QStackedWidget >(const QStackedWidget* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QStackedWidget* value = const_cast<QStackedWidget* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QStackedWidget >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QSplitter >(const QSplitter* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QSplitter* value = const_cast<QSplitter* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QSplitter >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QPlainTextEdit >(const QPlainTextEdit* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QPlainTextEdit* value = const_cast<QPlainTextEdit* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QPlainTextEdit >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QRubberBand >(const QRubberBand* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QRubberBand* value = const_cast<QRubberBand* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QRubberBand >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QTextEdit >(const QTextEdit* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QTextEdit* value = const_cast<QTextEdit* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QTextEdit >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QTextBrowser >(const QTextBrowser* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QTextBrowser* value = const_cast<QTextBrowser* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QTextBrowser >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QTabWidget >(const QTabWidget* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QTabWidget* value = const_cast<QTabWidget* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QTabWidget >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QTabBar >(const QTabBar* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QTabBar* value = const_cast<QTabBar* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QTabBar >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QMenuBar >(const QMenuBar* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QMenuBar* value = const_cast<QMenuBar* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QMenuBar >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QMenu >(const QMenu* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QMenu* value = const_cast<QMenu* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QMenu >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QAbstractSlider >(const QAbstractSlider* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QAbstractSlider* value = const_cast<QAbstractSlider* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QAbstractSlider >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QSlider >(const QSlider* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QSlider* value = const_cast<QSlider* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QSlider >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QScrollBar >(const QScrollBar* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QScrollBar* value = const_cast<QScrollBar* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QScrollBar >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QMdiSubWindow >(const QMdiSubWindow* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QMdiSubWindow* value = const_cast<QMdiSubWindow* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QMdiSubWindow >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QAbstractSpinBox >(const QAbstractSpinBox* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QAbstractSpinBox* value = const_cast<QAbstractSpinBox* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QAbstractSpinBox >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QDoubleSpinBox >(const QDoubleSpinBox* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QDoubleSpinBox* value = const_cast<QDoubleSpinBox* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QDoubleSpinBox >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QSpinBox >(const QSpinBox* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QSpinBox* value = const_cast<QSpinBox* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QSpinBox >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QMdiArea >(const QMdiArea* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QMdiArea* value = const_cast<QMdiArea* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QMdiArea >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QMainWindow >(const QMainWindow* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QMainWindow* value = const_cast<QMainWindow* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QMainWindow >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QLCDNumber >(const QLCDNumber* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QLCDNumber* value = const_cast<QLCDNumber* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QLCDNumber >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QGroupBox >(const QGroupBox* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QGroupBox* value = const_cast<QGroupBox* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QGroupBox >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QLabel >(const QLabel* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QLabel* value = const_cast<QLabel* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QLabel >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QFocusFrame >(const QFocusFrame* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QFocusFrame* value = const_cast<QFocusFrame* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QFocusFrame >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QDockWidget >(const QDockWidget* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QDockWidget* value = const_cast<QDockWidget* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QDockWidget >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QDialogButtonBox >(const QDialogButtonBox* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QDialogButtonBox* value = const_cast<QDialogButtonBox* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QDialogButtonBox >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QDial >(const QDial* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QDial* value = const_cast<QDial* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QDial >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QDateTimeEdit >(const QDateTimeEdit* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QDateTimeEdit* value = const_cast<QDateTimeEdit* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QDateTimeEdit >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QDateEdit >(const QDateEdit* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QDateEdit* value = const_cast<QDateEdit* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QDateEdit >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QTimeEdit >(const QTimeEdit* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QTimeEdit* value = const_cast<QTimeEdit* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QTimeEdit >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QComboBox >(const QComboBox* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QComboBox* value = const_cast<QComboBox* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QComboBox >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QFontComboBox >(const QFontComboBox* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QFontComboBox* value = const_cast<QFontComboBox* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QFontComboBox >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QCalendarWidget >(const QCalendarWidget* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QCalendarWidget* value = const_cast<QCalendarWidget* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QCalendarWidget >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QAbstractButton >(const QAbstractButton* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QAbstractButton* value = const_cast<QAbstractButton* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QAbstractButton >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QRadioButton >(const QRadioButton* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QRadioButton* value = const_cast<QRadioButton* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QRadioButton >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QToolButton >(const QToolButton* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QToolButton* value = const_cast<QToolButton* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QToolButton >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QPushButton >(const QPushButton* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QPushButton* value = const_cast<QPushButton* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QPushButton >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QCommandLinkButton >(const QCommandLinkButton* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QCommandLinkButton* value = const_cast<QCommandLinkButton* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QCommandLinkButton >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QCheckBox >(const QCheckBox* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QCheckBox* value = const_cast<QCheckBox* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QCheckBox >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QWizardPage >(const QWizardPage* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QWizardPage* value = const_cast<QWizardPage* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QWizardPage >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QWizard >(const QWizard* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QWizard* value = const_cast<QWizard* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QWizard >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QProgressDialog >(const QProgressDialog* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QProgressDialog* value = const_cast<QProgressDialog* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QProgressDialog >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QPrintPreviewDialog >(const QPrintPreviewDialog* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QPrintPreviewDialog* value = const_cast<QPrintPreviewDialog* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QPrintPreviewDialog >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QMessageBox >(const QMessageBox* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QMessageBox* value = const_cast<QMessageBox* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QMessageBox >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QLineEdit >(const QLineEdit* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QLineEdit* value = const_cast<QLineEdit* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QLineEdit >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QInputDialog >(const QInputDialog* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QInputDialog* value = const_cast<QInputDialog* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QInputDialog >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QFontDialog >(const QFontDialog* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QFontDialog* value = const_cast<QFontDialog* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QFontDialog >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QErrorMessage >(const QErrorMessage* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QErrorMessage* value = const_cast<QErrorMessage* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QErrorMessage >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QColorDialog >(const QColorDialog* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QColorDialog* value = const_cast<QColorDialog* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QColorDialog >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QAbstractPrintDialog >(const QAbstractPrintDialog* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QAbstractPrintDialog* value = const_cast<QAbstractPrintDialog* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QAbstractPrintDialog >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QPrintDialog >(const QPrintDialog* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QPrintDialog* value = const_cast<QPrintDialog* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QPrintDialog >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QAbstractPageSetupDialog >(const QAbstractPageSetupDialog* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QAbstractPageSetupDialog* value = const_cast<QAbstractPageSetupDialog* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QAbstractPageSetupDialog >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QPageSetupDialog >(const QPageSetupDialog* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QPageSetupDialog* value = const_cast<QPageSetupDialog* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QPageSetupDialog >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QStyle >(const QStyle* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QStyle* value = const_cast<QStyle* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QStyle >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QCommonStyle >(const QCommonStyle* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QCommonStyle* value = const_cast<QCommonStyle* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QCommonStyle >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QWindowsStyle >(const QWindowsStyle* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QWindowsStyle* value = const_cast<QWindowsStyle* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QWindowsStyle >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QPlastiqueStyle >(const QPlastiqueStyle* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QPlastiqueStyle* value = const_cast<QPlastiqueStyle* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QPlastiqueStyle >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QCleanlooksStyle >(const QCleanlooksStyle* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QCleanlooksStyle* value = const_cast<QCleanlooksStyle* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QCleanlooksStyle >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QMotifStyle >(const QMotifStyle* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QMotifStyle* value = const_cast<QMotifStyle* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QMotifStyle >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QCDEStyle >(const QCDEStyle* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QCDEStyle* value = const_cast<QCDEStyle* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QCDEStyle >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QTextObject >(const QTextObject* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QTextObject* value = const_cast<QTextObject* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QTextObject >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QTextFrame >(const QTextFrame* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QTextFrame* value = const_cast<QTextFrame* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QTextFrame >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QTextTable >(const QTextTable* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QTextTable* value = const_cast<QTextTable* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QTextTable >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QTextBlockGroup >(const QTextBlockGroup* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QTextBlockGroup* value = const_cast<QTextBlockGroup* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QTextBlockGroup >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QTextList >(const QTextList* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QTextList* value = const_cast<QTextList* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QTextList >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QAbstractTextDocumentLayout >(const QAbstractTextDocumentLayout* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QAbstractTextDocumentLayout* value = const_cast<QAbstractTextDocumentLayout* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QAbstractTextDocumentLayout >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QPlainTextDocumentLayout >(const QPlainTextDocumentLayout* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QPlainTextDocumentLayout* value = const_cast<QPlainTextDocumentLayout* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QPlainTextDocumentLayout >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QButtonGroup >(const QButtonGroup* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QButtonGroup* value = const_cast<QButtonGroup* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QButtonGroup >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QGraphicsScene >(const QGraphicsScene* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QGraphicsScene* value = const_cast<QGraphicsScene* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QGraphicsScene >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QGraphicsView >(const QGraphicsView* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QGraphicsView* value = const_cast<QGraphicsView* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QGraphicsView >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QSound >(const QSound* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QSound* value = const_cast<QSound* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QSound >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QShortcut >(const QShortcut* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QShortcut* value = const_cast<QShortcut* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QShortcut >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QSessionManager >(const QSessionManager* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QSessionManager* value = const_cast<QSessionManager* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QSessionManager >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QGraphicsItemAnimation >(const QGraphicsItemAnimation* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QGraphicsItemAnimation* value = const_cast<QGraphicsItemAnimation* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QGraphicsItemAnimation >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QTextDocument >(const QTextDocument* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QTextDocument* value = const_cast<QTextDocument* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QTextDocument >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
template<>
inline PyObject* createWrapper<QMovie >(const QMovie* cppobj, bool hasOwnership, bool isExactType)
{
    const char* typeName = 0;
    QMovie* value = const_cast<QMovie* >(cppobj);
    if (!isExactType)
        typeName = typeid(*value).name();
    PyObject* pyObj = Shiboken::Object::newObject(reinterpret_cast<SbkObjectType*>(SbkType< ::QMovie >()),value, hasOwnership, isExactType, typeName);
    PySide::Signal::updateSourceObject(pyObj);
    return pyObj;
}
// Generated converters declarations ----------------------------------

template<>
struct Converter< ::QMatrix4x3 > : ValueTypeConverter< ::QMatrix4x3 >
{
};

template<>
struct Converter< ::QMatrix3x4 > : ValueTypeConverter< ::QMatrix3x4 >
{
};

template<>
struct Converter< ::QMatrix4x2 > : ValueTypeConverter< ::QMatrix4x2 >
{
};

template<>
struct Converter< ::QMatrix3x3 > : ValueTypeConverter< ::QMatrix3x3 >
{
};

template<>
struct Converter< ::QMatrix2x4 > : ValueTypeConverter< ::QMatrix2x4 >
{
};

template<>
struct Converter< ::QMatrix3x2 > : ValueTypeConverter< ::QMatrix3x2 >
{
};

template<>
struct Converter< ::QMatrix2x3 > : ValueTypeConverter< ::QMatrix2x3 >
{
};

template<>
struct Converter< ::QMatrix2x2 > : ValueTypeConverter< ::QMatrix2x2 >
{
};

template<>
struct Converter< ::QX11Info > : ValueTypeConverter< ::QX11Info >
{
};

template<>
struct Converter< ::QPixmapCache* > : ObjectTypeConverter< ::QPixmapCache >
{
};

template<>
struct Converter< ::QPixmapCache > : ObjectTypeReferenceConverter< ::QPixmapCache >
{
};

template<>
struct Converter< ::QPixmapCache::Key > : ValueTypeConverter< ::QPixmapCache::Key >
{
};

template<>
struct Converter< ::QPictureIO* > : ObjectTypeConverter< ::QPictureIO >
{
};

template<>
struct Converter< ::QPictureIO > : ObjectTypeReferenceConverter< ::QPictureIO >
{
};

template<>
struct Converter< ::QImageIOHandler::ImageOption > : EnumConverter< ::QImageIOHandler::ImageOption >
{
};

template<>
struct Converter< ::QImageIOHandler* > : ObjectTypeConverter< ::QImageIOHandler >
{
};

template<>
struct Converter< ::QImageIOHandler > : ObjectTypeReferenceConverter< ::QImageIOHandler >
{
};

template<>
struct Converter< ::QIconEngine* > : ObjectTypeConverter< ::QIconEngine >
{
};

template<>
struct Converter< ::QIconEngine > : ObjectTypeReferenceConverter< ::QIconEngine >
{
};

template<>
struct Converter< ::QVector2D > : ValueTypeConverter< ::QVector2D >
{
};

template<>
struct Converter< ::QInputContextFactory* > : ObjectTypeConverter< ::QInputContextFactory >
{
};

template<>
struct Converter< ::QInputContextFactory > : ObjectTypeReferenceConverter< ::QInputContextFactory >
{
};

template<>
struct Converter< ::QMatrix4x4 > : ValueTypeConverter< ::QMatrix4x4 >
{
    static ::QMatrix4x4 toCpp(PyObject* pyobj);
    static bool isConvertible(PyObject* pyobj);
};

template<>
struct Converter< ::QQuaternion > : ValueTypeConverter< ::QQuaternion >
{
};

template<>
struct Converter< ::QVector4D > : ValueTypeConverter< ::QVector4D >
{
    static ::QVector4D toCpp(PyObject* pyobj);
    static bool isConvertible(PyObject* pyobj);
};

template<>
struct Converter< ::QVector3D > : ValueTypeConverter< ::QVector3D >
{
    static ::QVector3D toCpp(PyObject* pyobj);
    static bool isConvertible(PyObject* pyobj);
};

template<>
struct Converter< ::QTextTableCell > : ValueTypeConverter< ::QTextTableCell >
{
};

template<>
struct Converter< ::QTextDocumentFragment > : ValueTypeConverter< ::QTextDocumentFragment >
{
};

template<>
struct Converter< ::QTextFragment > : ValueTypeConverter< ::QTextFragment >
{
};

template<>
struct Converter< ::QTextBlock > : ValueTypeConverter< ::QTextBlock >
{
};

template<>
struct Converter< ::QTextBlock::iterator > : ValueTypeConverter< ::QTextBlock::iterator >
{
};

template<>
struct Converter< ::QTextBlockUserData* > : ObjectTypeConverter< ::QTextBlockUserData >
{
};

template<>
struct Converter< ::QTextBlockUserData > : ObjectTypeReferenceConverter< ::QTextBlockUserData >
{
};

template<>
struct Converter< ::QFontDatabase::WritingSystem > : EnumConverter< ::QFontDatabase::WritingSystem >
{
};

template<>
struct Converter< ::QFontDatabase > : ValueTypeConverter< ::QFontDatabase >
{
};

template<>
struct Converter< ::QTextObjectInterface* > : ObjectTypeConverter< ::QTextObjectInterface >
{
};

template<>
struct Converter< ::QTextObjectInterface > : ObjectTypeReferenceConverter< ::QTextObjectInterface >
{
};

template<>
struct Converter< ::QTextCursor::MoveMode > : EnumConverter< ::QTextCursor::MoveMode >
{
};

template<>
struct Converter< ::QTextCursor::MoveOperation > : EnumConverter< ::QTextCursor::MoveOperation >
{
};

template<>
struct Converter< ::QTextCursor::SelectionType > : EnumConverter< ::QTextCursor::SelectionType >
{
};

template<>
struct Converter< ::QTextCursor > : ValueTypeConverter< ::QTextCursor >
{
};

template<>
struct Converter< ::QTextLine::Edge > : EnumConverter< ::QTextLine::Edge >
{
};

template<>
struct Converter< ::QTextLine::CursorPosition > : EnumConverter< ::QTextLine::CursorPosition >
{
};

template<>
struct Converter< ::QTextLine > : ValueTypeConverter< ::QTextLine >
{
};

template<>
struct Converter< ::QTextInlineObject > : ValueTypeConverter< ::QTextInlineObject >
{
};

template<>
struct Converter< ::QTextFormat::Property > : EnumConverter< ::QTextFormat::Property >
{
};

template<>
struct Converter< ::QTextFormat::FormatType > : EnumConverter< ::QTextFormat::FormatType >
{
};

template<>
struct Converter< ::QTextFormat::ObjectTypes > : EnumConverter< ::QTextFormat::ObjectTypes >
{
};

template<>
struct Converter< ::QTextFormat::PageBreakFlag > : EnumConverter< ::QTextFormat::PageBreakFlag >
{
};
template<>
struct Converter< ::QFlags<QTextFormat::PageBreakFlag> > : QFlagsConverter< ::QFlags<QTextFormat::PageBreakFlag> >
{
};

template<>
struct Converter< ::QTextFormat > : ValueTypeConverter< ::QTextFormat >
{
};

template<>
struct Converter< ::QTextFrameFormat::Position > : EnumConverter< ::QTextFrameFormat::Position >
{
};

template<>
struct Converter< ::QTextFrameFormat::BorderStyle > : EnumConverter< ::QTextFrameFormat::BorderStyle >
{
};

template<>
struct Converter< ::QTextFrameFormat > : ValueTypeConverter< ::QTextFrameFormat >
{
};

template<>
struct Converter< ::QTextTableFormat > : ValueTypeConverter< ::QTextTableFormat >
{
};

template<>
struct Converter< ::QTextListFormat::Style > : EnumConverter< ::QTextListFormat::Style >
{
};

template<>
struct Converter< ::QTextListFormat > : ValueTypeConverter< ::QTextListFormat >
{
};

template<>
struct Converter< ::QTextBlockFormat > : ValueTypeConverter< ::QTextBlockFormat >
{
};

template<>
struct Converter< ::QTextLength::Type > : EnumConverter< ::QTextLength::Type >
{
};

template<>
struct Converter< ::QTextLength > : ValueTypeConverter< ::QTextLength >
{
};

template<>
struct Converter< ::QUndoCommand* > : ObjectTypeConverter< ::QUndoCommand >
{
};

template<>
struct Converter< ::QUndoCommand > : ObjectTypeReferenceConverter< ::QUndoCommand >
{
};

template<>
struct Converter< ::QDesktopServices::StandardLocation > : EnumConverter< ::QDesktopServices::StandardLocation >
{
};

template<>
struct Converter< ::QDesktopServices* > : ObjectTypeConverter< ::QDesktopServices >
{
};

template<>
struct Converter< ::QDesktopServices > : ObjectTypeReferenceConverter< ::QDesktopServices >
{
};

template<>
struct Converter< ::QStyleFactory* > : ObjectTypeConverter< ::QStyleFactory >
{
};

template<>
struct Converter< ::QStyleFactory > : ObjectTypeReferenceConverter< ::QStyleFactory >
{
};

template<>
struct Converter< ::QWhatsThis* > : ObjectTypeConverter< ::QWhatsThis >
{
};

template<>
struct Converter< ::QWhatsThis > : ObjectTypeReferenceConverter< ::QWhatsThis >
{
};

template<>
struct Converter< ::QToolTip* > : ObjectTypeConverter< ::QToolTip >
{
};

template<>
struct Converter< ::QToolTip > : ObjectTypeReferenceConverter< ::QToolTip >
{
};

template<>
struct Converter< ::QGestureRecognizer::ResultFlag > : EnumConverter< ::QGestureRecognizer::ResultFlag >
{
};
template<>
struct Converter< ::QFlags<QGestureRecognizer::ResultFlag> > : QFlagsConverter< ::QFlags<QGestureRecognizer::ResultFlag> >
{
};

template<>
struct Converter< ::QGestureRecognizer* > : ObjectTypeConverter< ::QGestureRecognizer >
{
};

template<>
struct Converter< ::QGestureRecognizer > : ObjectTypeReferenceConverter< ::QGestureRecognizer >
{
};

template<>
struct Converter< ::QLayoutItem* > : ObjectTypeConverter< ::QLayoutItem >
{
};

template<>
struct Converter< ::QLayoutItem > : ObjectTypeReferenceConverter< ::QLayoutItem >
{
};

template<>
struct Converter< ::QWidgetItem* > : ObjectTypeConverter< ::QWidgetItem >
{
};

template<>
struct Converter< ::QWidgetItem > : ObjectTypeReferenceConverter< ::QWidgetItem >
{
};

template<>
struct Converter< ::QTreeWidgetItem::ItemType > : EnumConverter< ::QTreeWidgetItem::ItemType >
{
};

template<>
struct Converter< ::QTreeWidgetItem::ChildIndicatorPolicy > : EnumConverter< ::QTreeWidgetItem::ChildIndicatorPolicy >
{
};

template<>
struct Converter< ::QTreeWidgetItem* > : ObjectTypeConverter< ::QTreeWidgetItem >
{
};

template<>
struct Converter< ::QTreeWidgetItem > : ObjectTypeReferenceConverter< ::QTreeWidgetItem >
{
};

template<>
struct Converter< ::QTreeWidgetItemIterator::IteratorFlag > : EnumConverter< ::QTreeWidgetItemIterator::IteratorFlag >
{
};
template<>
struct Converter< ::QFlags<QTreeWidgetItemIterator::IteratorFlag> > : QFlagsConverter< ::QFlags<QTreeWidgetItemIterator::IteratorFlag> >
{
};

template<>
struct Converter< ::QTreeWidgetItemIterator > : ValueTypeConverter< ::QTreeWidgetItemIterator >
{
};

template<>
struct Converter< ::QTableWidgetItem::ItemType > : EnumConverter< ::QTableWidgetItem::ItemType >
{
};

template<>
struct Converter< ::QTableWidgetItem* > : ObjectTypeConverter< ::QTableWidgetItem >
{
};

template<>
struct Converter< ::QTableWidgetItem > : ObjectTypeReferenceConverter< ::QTableWidgetItem >
{
};

template<>
struct Converter< ::QTableWidgetSelectionRange > : ValueTypeConverter< ::QTableWidgetSelectionRange >
{
};

template<>
struct Converter< ::QStandardItem::ItemType > : EnumConverter< ::QStandardItem::ItemType >
{
};

template<>
struct Converter< ::QStandardItem* > : ObjectTypeConverter< ::QStandardItem >
{
};

template<>
struct Converter< ::QStandardItem > : ObjectTypeReferenceConverter< ::QStandardItem >
{
};

template<>
struct Converter< ::QListWidgetItem::ItemType > : EnumConverter< ::QListWidgetItem::ItemType >
{
};

template<>
struct Converter< ::QListWidgetItem* > : ObjectTypeConverter< ::QListWidgetItem >
{
};

template<>
struct Converter< ::QListWidgetItem > : ObjectTypeReferenceConverter< ::QListWidgetItem >
{
};

template<>
struct Converter< ::QItemEditorFactory* > : ObjectTypeConverter< ::QItemEditorFactory >
{
};

template<>
struct Converter< ::QItemEditorFactory > : ObjectTypeReferenceConverter< ::QItemEditorFactory >
{
};

template<>
struct Converter< ::QItemEditorCreatorBase* > : ObjectTypeConverter< ::QItemEditorCreatorBase >
{
};

template<>
struct Converter< ::QItemEditorCreatorBase > : ObjectTypeReferenceConverter< ::QItemEditorCreatorBase >
{
};

template<>
struct Converter< ::QFileIconProvider::IconType > : EnumConverter< ::QFileIconProvider::IconType >
{
};

template<>
struct Converter< ::QFileIconProvider* > : ObjectTypeConverter< ::QFileIconProvider >
{
};

template<>
struct Converter< ::QFileIconProvider > : ObjectTypeReferenceConverter< ::QFileIconProvider >
{
};

template<>
struct Converter< ::QItemSelection > : ValueTypeConverter< ::QItemSelection >
{
};

template<>
struct Converter< ::QItemSelectionRange > : ValueTypeConverter< ::QItemSelectionRange >
{
};

template<>
struct Converter< ::QStyleOption::StyleOptionVersion > : EnumConverter< ::QStyleOption::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleOption::StyleOptionType > : EnumConverter< ::QStyleOption::StyleOptionType >
{
};

template<>
struct Converter< ::QStyleOption::OptionType > : EnumConverter< ::QStyleOption::OptionType >
{
};

template<>
struct Converter< ::QStyleOption* > : ObjectTypeConverter< ::QStyleOption >
{
};

template<>
struct Converter< ::QStyleOption > : ObjectTypeReferenceConverter< ::QStyleOption >
{
};

template<>
struct Converter< ::QStyleOptionToolBar::StyleOptionVersion > : EnumConverter< ::QStyleOptionToolBar::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleOptionToolBar::StyleOptionType > : EnumConverter< ::QStyleOptionToolBar::StyleOptionType >
{
};

template<>
struct Converter< ::QStyleOptionToolBar::ToolBarPosition > : EnumConverter< ::QStyleOptionToolBar::ToolBarPosition >
{
};

template<>
struct Converter< ::QStyleOptionToolBar::ToolBarFeature > : EnumConverter< ::QStyleOptionToolBar::ToolBarFeature >
{
};
template<>
struct Converter< ::QFlags<QStyleOptionToolBar::ToolBarFeature> > : QFlagsConverter< ::QFlags<QStyleOptionToolBar::ToolBarFeature> >
{
};

template<>
struct Converter< ::QStyleOptionToolBar* > : ObjectTypeConverter< ::QStyleOptionToolBar >
{
};

template<>
struct Converter< ::QStyleOptionToolBar > : ObjectTypeReferenceConverter< ::QStyleOptionToolBar >
{
};

template<>
struct Converter< ::QStyleOptionButton::StyleOptionVersion > : EnumConverter< ::QStyleOptionButton::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleOptionButton::ButtonFeature > : EnumConverter< ::QStyleOptionButton::ButtonFeature >
{
};
template<>
struct Converter< ::QFlags<QStyleOptionButton::ButtonFeature> > : QFlagsConverter< ::QFlags<QStyleOptionButton::ButtonFeature> >
{
};

template<>
struct Converter< ::QStyleOptionButton::StyleOptionType > : EnumConverter< ::QStyleOptionButton::StyleOptionType >
{
};

template<>
struct Converter< ::QStyleOptionButton* > : ObjectTypeConverter< ::QStyleOptionButton >
{
};

template<>
struct Converter< ::QStyleOptionButton > : ObjectTypeReferenceConverter< ::QStyleOptionButton >
{
};

template<>
struct Converter< ::QStyleOptionComplex::StyleOptionVersion > : EnumConverter< ::QStyleOptionComplex::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleOptionComplex::StyleOptionType > : EnumConverter< ::QStyleOptionComplex::StyleOptionType >
{
};

template<>
struct Converter< ::QStyleOptionComplex* > : ObjectTypeConverter< ::QStyleOptionComplex >
{
};

template<>
struct Converter< ::QStyleOptionComplex > : ObjectTypeReferenceConverter< ::QStyleOptionComplex >
{
};

template<>
struct Converter< ::QStyleOptionComboBox::StyleOptionVersion > : EnumConverter< ::QStyleOptionComboBox::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleOptionComboBox::StyleOptionType > : EnumConverter< ::QStyleOptionComboBox::StyleOptionType >
{
};

template<>
struct Converter< ::QStyleOptionComboBox* > : ObjectTypeConverter< ::QStyleOptionComboBox >
{
};

template<>
struct Converter< ::QStyleOptionComboBox > : ObjectTypeReferenceConverter< ::QStyleOptionComboBox >
{
};

template<>
struct Converter< ::QStyleOptionToolButton::StyleOptionVersion > : EnumConverter< ::QStyleOptionToolButton::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleOptionToolButton::ToolButtonFeature > : EnumConverter< ::QStyleOptionToolButton::ToolButtonFeature >
{
};
template<>
struct Converter< ::QFlags<QStyleOptionToolButton::ToolButtonFeature> > : QFlagsConverter< ::QFlags<QStyleOptionToolButton::ToolButtonFeature> >
{
};

template<>
struct Converter< ::QStyleOptionToolButton::StyleOptionType > : EnumConverter< ::QStyleOptionToolButton::StyleOptionType >
{
};

template<>
struct Converter< ::QStyleOptionToolButton* > : ObjectTypeConverter< ::QStyleOptionToolButton >
{
};

template<>
struct Converter< ::QStyleOptionToolButton > : ObjectTypeReferenceConverter< ::QStyleOptionToolButton >
{
};

template<>
struct Converter< ::QStyleOptionSpinBox::StyleOptionVersion > : EnumConverter< ::QStyleOptionSpinBox::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleOptionSpinBox::StyleOptionType > : EnumConverter< ::QStyleOptionSpinBox::StyleOptionType >
{
};

template<>
struct Converter< ::QStyleOptionSpinBox* > : ObjectTypeConverter< ::QStyleOptionSpinBox >
{
};

template<>
struct Converter< ::QStyleOptionSpinBox > : ObjectTypeReferenceConverter< ::QStyleOptionSpinBox >
{
};

template<>
struct Converter< ::QStyleOptionSlider::StyleOptionVersion > : EnumConverter< ::QStyleOptionSlider::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleOptionSlider::StyleOptionType > : EnumConverter< ::QStyleOptionSlider::StyleOptionType >
{
};

template<>
struct Converter< ::QStyleOptionSlider* > : ObjectTypeConverter< ::QStyleOptionSlider >
{
};

template<>
struct Converter< ::QStyleOptionSlider > : ObjectTypeReferenceConverter< ::QStyleOptionSlider >
{
};

template<>
struct Converter< ::QStyleOptionSizeGrip::StyleOptionVersion > : EnumConverter< ::QStyleOptionSizeGrip::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleOptionSizeGrip::StyleOptionType > : EnumConverter< ::QStyleOptionSizeGrip::StyleOptionType >
{
};

template<>
struct Converter< ::QStyleOptionSizeGrip* > : ObjectTypeConverter< ::QStyleOptionSizeGrip >
{
};

template<>
struct Converter< ::QStyleOptionSizeGrip > : ObjectTypeReferenceConverter< ::QStyleOptionSizeGrip >
{
};

template<>
struct Converter< ::QStyleOptionGroupBox::StyleOptionVersion > : EnumConverter< ::QStyleOptionGroupBox::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleOptionGroupBox::StyleOptionType > : EnumConverter< ::QStyleOptionGroupBox::StyleOptionType >
{
};

template<>
struct Converter< ::QStyleOptionGroupBox* > : ObjectTypeConverter< ::QStyleOptionGroupBox >
{
};

template<>
struct Converter< ::QStyleOptionGroupBox > : ObjectTypeReferenceConverter< ::QStyleOptionGroupBox >
{
};

template<>
struct Converter< ::QStyleOptionTitleBar::StyleOptionVersion > : EnumConverter< ::QStyleOptionTitleBar::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleOptionTitleBar::StyleOptionType > : EnumConverter< ::QStyleOptionTitleBar::StyleOptionType >
{
};

template<>
struct Converter< ::QStyleOptionTitleBar* > : ObjectTypeConverter< ::QStyleOptionTitleBar >
{
};

template<>
struct Converter< ::QStyleOptionTitleBar > : ObjectTypeReferenceConverter< ::QStyleOptionTitleBar >
{
};

template<>
struct Converter< ::QStyleOptionHeader::StyleOptionVersion > : EnumConverter< ::QStyleOptionHeader::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleOptionHeader::SectionPosition > : EnumConverter< ::QStyleOptionHeader::SectionPosition >
{
};

template<>
struct Converter< ::QStyleOptionHeader::SelectedPosition > : EnumConverter< ::QStyleOptionHeader::SelectedPosition >
{
};

template<>
struct Converter< ::QStyleOptionHeader::StyleOptionType > : EnumConverter< ::QStyleOptionHeader::StyleOptionType >
{
};

template<>
struct Converter< ::QStyleOptionHeader::SortIndicator > : EnumConverter< ::QStyleOptionHeader::SortIndicator >
{
};

template<>
struct Converter< ::QStyleOptionHeader* > : ObjectTypeConverter< ::QStyleOptionHeader >
{
};

template<>
struct Converter< ::QStyleOptionHeader > : ObjectTypeReferenceConverter< ::QStyleOptionHeader >
{
};

template<>
struct Converter< ::QStyleOptionRubberBand::StyleOptionVersion > : EnumConverter< ::QStyleOptionRubberBand::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleOptionRubberBand::StyleOptionType > : EnumConverter< ::QStyleOptionRubberBand::StyleOptionType >
{
};

template<>
struct Converter< ::QStyleOptionRubberBand* > : ObjectTypeConverter< ::QStyleOptionRubberBand >
{
};

template<>
struct Converter< ::QStyleOptionRubberBand > : ObjectTypeReferenceConverter< ::QStyleOptionRubberBand >
{
};

template<>
struct Converter< ::QStyleOptionTabBarBase::StyleOptionVersion > : EnumConverter< ::QStyleOptionTabBarBase::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleOptionTabBarBase::StyleOptionType > : EnumConverter< ::QStyleOptionTabBarBase::StyleOptionType >
{
};

template<>
struct Converter< ::QStyleOptionTabBarBase* > : ObjectTypeConverter< ::QStyleOptionTabBarBase >
{
};

template<>
struct Converter< ::QStyleOptionTabBarBase > : ObjectTypeReferenceConverter< ::QStyleOptionTabBarBase >
{
};

template<>
struct Converter< ::QStyleOptionTabBarBaseV2::StyleOptionVersion > : EnumConverter< ::QStyleOptionTabBarBaseV2::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleOptionTabBarBaseV2* > : ObjectTypeConverter< ::QStyleOptionTabBarBaseV2 >
{
};

template<>
struct Converter< ::QStyleOptionTabBarBaseV2 > : ObjectTypeReferenceConverter< ::QStyleOptionTabBarBaseV2 >
{
};

template<>
struct Converter< ::QStyleOptionToolBox::StyleOptionVersion > : EnumConverter< ::QStyleOptionToolBox::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleOptionToolBox::StyleOptionType > : EnumConverter< ::QStyleOptionToolBox::StyleOptionType >
{
};

template<>
struct Converter< ::QStyleOptionToolBox* > : ObjectTypeConverter< ::QStyleOptionToolBox >
{
};

template<>
struct Converter< ::QStyleOptionToolBox > : ObjectTypeReferenceConverter< ::QStyleOptionToolBox >
{
};

template<>
struct Converter< ::QStyleOptionToolBoxV2::StyleOptionVersion > : EnumConverter< ::QStyleOptionToolBoxV2::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleOptionToolBoxV2::TabPosition > : EnumConverter< ::QStyleOptionToolBoxV2::TabPosition >
{
};

template<>
struct Converter< ::QStyleOptionToolBoxV2::SelectedPosition > : EnumConverter< ::QStyleOptionToolBoxV2::SelectedPosition >
{
};

template<>
struct Converter< ::QStyleOptionToolBoxV2* > : ObjectTypeConverter< ::QStyleOptionToolBoxV2 >
{
};

template<>
struct Converter< ::QStyleOptionToolBoxV2 > : ObjectTypeReferenceConverter< ::QStyleOptionToolBoxV2 >
{
};

template<>
struct Converter< ::QStyleOptionTabWidgetFrame::StyleOptionVersion > : EnumConverter< ::QStyleOptionTabWidgetFrame::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleOptionTabWidgetFrame::StyleOptionType > : EnumConverter< ::QStyleOptionTabWidgetFrame::StyleOptionType >
{
};

template<>
struct Converter< ::QStyleOptionTabWidgetFrame* > : ObjectTypeConverter< ::QStyleOptionTabWidgetFrame >
{
};

template<>
struct Converter< ::QStyleOptionTabWidgetFrame > : ObjectTypeReferenceConverter< ::QStyleOptionTabWidgetFrame >
{
};

template<>
struct Converter< ::QStyleOptionViewItem::StyleOptionVersion > : EnumConverter< ::QStyleOptionViewItem::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleOptionViewItem::StyleOptionType > : EnumConverter< ::QStyleOptionViewItem::StyleOptionType >
{
};

template<>
struct Converter< ::QStyleOptionViewItem::Position > : EnumConverter< ::QStyleOptionViewItem::Position >
{
};

template<>
struct Converter< ::QStyleOptionViewItem* > : ObjectTypeConverter< ::QStyleOptionViewItem >
{
};

template<>
struct Converter< ::QStyleOptionViewItem > : ObjectTypeReferenceConverter< ::QStyleOptionViewItem >
{
};

template<>
struct Converter< ::QStyleOptionViewItemV2::StyleOptionVersion > : EnumConverter< ::QStyleOptionViewItemV2::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleOptionViewItemV2::ViewItemFeature > : EnumConverter< ::QStyleOptionViewItemV2::ViewItemFeature >
{
};
template<>
struct Converter< ::QFlags<QStyleOptionViewItemV2::ViewItemFeature> > : QFlagsConverter< ::QFlags<QStyleOptionViewItemV2::ViewItemFeature> >
{
};

template<>
struct Converter< ::QStyleOptionViewItemV2* > : ObjectTypeConverter< ::QStyleOptionViewItemV2 >
{
};

template<>
struct Converter< ::QStyleOptionViewItemV2 > : ObjectTypeReferenceConverter< ::QStyleOptionViewItemV2 >
{
};

template<>
struct Converter< ::QStyleOptionViewItemV3::StyleOptionVersion > : EnumConverter< ::QStyleOptionViewItemV3::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleOptionViewItemV3* > : ObjectTypeConverter< ::QStyleOptionViewItemV3 >
{
};

template<>
struct Converter< ::QStyleOptionViewItemV3 > : ObjectTypeReferenceConverter< ::QStyleOptionViewItemV3 >
{
};

template<>
struct Converter< ::QStyleOptionViewItemV4::ViewItemPosition > : EnumConverter< ::QStyleOptionViewItemV4::ViewItemPosition >
{
};

template<>
struct Converter< ::QStyleOptionViewItemV4::StyleOptionVersion > : EnumConverter< ::QStyleOptionViewItemV4::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleOptionViewItemV4* > : ObjectTypeConverter< ::QStyleOptionViewItemV4 >
{
};

template<>
struct Converter< ::QStyleOptionViewItemV4 > : ObjectTypeReferenceConverter< ::QStyleOptionViewItemV4 >
{
};

template<>
struct Converter< ::QStyleOptionFrame::StyleOptionVersion > : EnumConverter< ::QStyleOptionFrame::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleOptionFrame::StyleOptionType > : EnumConverter< ::QStyleOptionFrame::StyleOptionType >
{
};

template<>
struct Converter< ::QStyleOptionFrame* > : ObjectTypeConverter< ::QStyleOptionFrame >
{
};

template<>
struct Converter< ::QStyleOptionFrame > : ObjectTypeReferenceConverter< ::QStyleOptionFrame >
{
};

template<>
struct Converter< ::QStyleOptionFrameV2::StyleOptionVersion > : EnumConverter< ::QStyleOptionFrameV2::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleOptionFrameV2::FrameFeature > : EnumConverter< ::QStyleOptionFrameV2::FrameFeature >
{
};
template<>
struct Converter< ::QFlags<QStyleOptionFrameV2::FrameFeature> > : QFlagsConverter< ::QFlags<QStyleOptionFrameV2::FrameFeature> >
{
};

template<>
struct Converter< ::QStyleOptionFrameV2* > : ObjectTypeConverter< ::QStyleOptionFrameV2 >
{
};

template<>
struct Converter< ::QStyleOptionFrameV2 > : ObjectTypeReferenceConverter< ::QStyleOptionFrameV2 >
{
};

template<>
struct Converter< ::QStyleOptionFrameV3::StyleOptionVersion > : EnumConverter< ::QStyleOptionFrameV3::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleOptionFrameV3* > : ObjectTypeConverter< ::QStyleOptionFrameV3 >
{
};

template<>
struct Converter< ::QStyleOptionFrameV3 > : ObjectTypeReferenceConverter< ::QStyleOptionFrameV3 >
{
};

template<>
struct Converter< ::QStyleOptionFocusRect::StyleOptionVersion > : EnumConverter< ::QStyleOptionFocusRect::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleOptionFocusRect::StyleOptionType > : EnumConverter< ::QStyleOptionFocusRect::StyleOptionType >
{
};

template<>
struct Converter< ::QStyleOptionFocusRect* > : ObjectTypeConverter< ::QStyleOptionFocusRect >
{
};

template<>
struct Converter< ::QStyleOptionFocusRect > : ObjectTypeReferenceConverter< ::QStyleOptionFocusRect >
{
};

template<>
struct Converter< ::QStyleHintReturn::HintReturnType > : EnumConverter< ::QStyleHintReturn::HintReturnType >
{
};

template<>
struct Converter< ::QStyleHintReturn::StyleOptionVersion > : EnumConverter< ::QStyleHintReturn::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleHintReturn::StyleOptionType > : EnumConverter< ::QStyleHintReturn::StyleOptionType >
{
};

template<>
struct Converter< ::QStyleHintReturn* > : ObjectTypeConverter< ::QStyleHintReturn >
{
};

template<>
struct Converter< ::QStyleHintReturn > : ObjectTypeReferenceConverter< ::QStyleHintReturn >
{
};

template<>
struct Converter< ::QStyleHintReturnVariant::StyleOptionVersion > : EnumConverter< ::QStyleHintReturnVariant::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleHintReturnVariant::StyleOptionType > : EnumConverter< ::QStyleHintReturnVariant::StyleOptionType >
{
};

template<>
struct Converter< ::QStyleHintReturnVariant* > : ObjectTypeConverter< ::QStyleHintReturnVariant >
{
};

template<>
struct Converter< ::QStyleHintReturnVariant > : ObjectTypeReferenceConverter< ::QStyleHintReturnVariant >
{
};

template<>
struct Converter< ::QStyleHintReturnMask::StyleOptionVersion > : EnumConverter< ::QStyleHintReturnMask::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleHintReturnMask::StyleOptionType > : EnumConverter< ::QStyleHintReturnMask::StyleOptionType >
{
};

template<>
struct Converter< ::QStyleHintReturnMask* > : ObjectTypeConverter< ::QStyleHintReturnMask >
{
};

template<>
struct Converter< ::QStyleHintReturnMask > : ObjectTypeReferenceConverter< ::QStyleHintReturnMask >
{
};

template<>
struct Converter< ::QStyleOptionDockWidget::StyleOptionVersion > : EnumConverter< ::QStyleOptionDockWidget::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleOptionDockWidget::StyleOptionType > : EnumConverter< ::QStyleOptionDockWidget::StyleOptionType >
{
};

template<>
struct Converter< ::QStyleOptionDockWidget* > : ObjectTypeConverter< ::QStyleOptionDockWidget >
{
};

template<>
struct Converter< ::QStyleOptionDockWidget > : ObjectTypeReferenceConverter< ::QStyleOptionDockWidget >
{
};

template<>
struct Converter< ::QStyleOptionDockWidgetV2::StyleOptionVersion > : EnumConverter< ::QStyleOptionDockWidgetV2::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleOptionDockWidgetV2* > : ObjectTypeConverter< ::QStyleOptionDockWidgetV2 >
{
};

template<>
struct Converter< ::QStyleOptionDockWidgetV2 > : ObjectTypeReferenceConverter< ::QStyleOptionDockWidgetV2 >
{
};

template<>
struct Converter< ::QStyleOptionGraphicsItem::StyleOptionVersion > : EnumConverter< ::QStyleOptionGraphicsItem::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleOptionGraphicsItem::StyleOptionType > : EnumConverter< ::QStyleOptionGraphicsItem::StyleOptionType >
{
};

template<>
struct Converter< ::QStyleOptionGraphicsItem* > : ObjectTypeConverter< ::QStyleOptionGraphicsItem >
{
};

template<>
struct Converter< ::QStyleOptionGraphicsItem > : ObjectTypeReferenceConverter< ::QStyleOptionGraphicsItem >
{
};

template<>
struct Converter< ::QStyleOptionMenuItem::StyleOptionVersion > : EnumConverter< ::QStyleOptionMenuItem::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleOptionMenuItem::StyleOptionType > : EnumConverter< ::QStyleOptionMenuItem::StyleOptionType >
{
};

template<>
struct Converter< ::QStyleOptionMenuItem::CheckType > : EnumConverter< ::QStyleOptionMenuItem::CheckType >
{
};

template<>
struct Converter< ::QStyleOptionMenuItem::MenuItemType > : EnumConverter< ::QStyleOptionMenuItem::MenuItemType >
{
};

template<>
struct Converter< ::QStyleOptionMenuItem* > : ObjectTypeConverter< ::QStyleOptionMenuItem >
{
};

template<>
struct Converter< ::QStyleOptionMenuItem > : ObjectTypeReferenceConverter< ::QStyleOptionMenuItem >
{
};

template<>
struct Converter< ::QStyleOptionProgressBar::StyleOptionVersion > : EnumConverter< ::QStyleOptionProgressBar::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleOptionProgressBar::StyleOptionType > : EnumConverter< ::QStyleOptionProgressBar::StyleOptionType >
{
};

template<>
struct Converter< ::QStyleOptionProgressBar* > : ObjectTypeConverter< ::QStyleOptionProgressBar >
{
};

template<>
struct Converter< ::QStyleOptionProgressBar > : ObjectTypeReferenceConverter< ::QStyleOptionProgressBar >
{
};

template<>
struct Converter< ::QStyleOptionProgressBarV2::StyleOptionVersion > : EnumConverter< ::QStyleOptionProgressBarV2::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleOptionProgressBarV2::StyleOptionType > : EnumConverter< ::QStyleOptionProgressBarV2::StyleOptionType >
{
};

template<>
struct Converter< ::QStyleOptionProgressBarV2* > : ObjectTypeConverter< ::QStyleOptionProgressBarV2 >
{
};

template<>
struct Converter< ::QStyleOptionProgressBarV2 > : ObjectTypeReferenceConverter< ::QStyleOptionProgressBarV2 >
{
};

template<>
struct Converter< ::QKeySequence::SequenceFormat > : EnumConverter< ::QKeySequence::SequenceFormat >
{
};

template<>
struct Converter< ::QKeySequence::StandardKey > : EnumConverter< ::QKeySequence::StandardKey >
{
};

template<>
struct Converter< ::QKeySequence::SequenceMatch > : EnumConverter< ::QKeySequence::SequenceMatch >
{
};

template<>
struct Converter< ::QKeySequence > : ValueTypeConverter< ::QKeySequence >
{
    static ::QKeySequence toCpp(PyObject* pyobj);
    static bool isConvertible(PyObject* pyobj);
};

template<>
struct Converter< ::QCursor > : ValueTypeConverter< ::QCursor >
{
    static ::QCursor toCpp(PyObject* pyobj);
    static bool isConvertible(PyObject* pyobj);
};

template<>
struct Converter< ::QSizePolicy::ControlType > : EnumConverter< ::QSizePolicy::ControlType >
{
};
template<>
struct Converter< ::QFlags<QSizePolicy::ControlType> > : QFlagsConverter< ::QFlags<QSizePolicy::ControlType> >
{
};

template<>
struct Converter< ::QSizePolicy::PolicyFlag > : EnumConverter< ::QSizePolicy::PolicyFlag >
{
};

template<>
struct Converter< ::QSizePolicy::Policy > : EnumConverter< ::QSizePolicy::Policy >
{
};

template<>
struct Converter< ::QSizePolicy > : ValueTypeConverter< ::QSizePolicy >
{
};

template<>
struct Converter< ::QSpacerItem* > : ObjectTypeConverter< ::QSpacerItem >
{
};

template<>
struct Converter< ::QSpacerItem > : ObjectTypeReferenceConverter< ::QSpacerItem >
{
};

template<>
struct Converter< ::QPalette::ColorGroup > : EnumConverter< ::QPalette::ColorGroup >
{
};

template<>
struct Converter< ::QPalette::ColorRole > : EnumConverter< ::QPalette::ColorRole >
{
};

template<>
struct Converter< ::QPalette > : ValueTypeConverter< ::QPalette >
{
    static ::QPalette toCpp(PyObject* pyobj);
    static bool isConvertible(PyObject* pyobj);
};

template<>
struct Converter< ::QPrinterInfo > : ValueTypeConverter< ::QPrinterInfo >
{
    static ::QPrinterInfo toCpp(PyObject* pyobj);
    static bool isConvertible(PyObject* pyobj);
};

template<>
struct Converter< ::QPrintEngine::PrintEnginePropertyKey > : EnumConverter< ::QPrintEngine::PrintEnginePropertyKey >
{
};

template<>
struct Converter< ::QPrintEngine* > : ObjectTypeConverter< ::QPrintEngine >
{
};

template<>
struct Converter< ::QPrintEngine > : ObjectTypeReferenceConverter< ::QPrintEngine >
{
};

template<>
struct Converter< ::QPaintEngineState* > : ObjectTypeConverter< ::QPaintEngineState >
{
};

template<>
struct Converter< ::QPaintEngineState > : ObjectTypeReferenceConverter< ::QPaintEngineState >
{
};

template<>
struct Converter< ::QPaintEngine::PolygonDrawMode > : EnumConverter< ::QPaintEngine::PolygonDrawMode >
{
};

template<>
struct Converter< ::QPaintEngine::Type > : EnumConverter< ::QPaintEngine::Type >
{
};

template<>
struct Converter< ::QPaintEngine::PaintEngineFeature > : EnumConverter< ::QPaintEngine::PaintEngineFeature >
{
};
template<>
struct Converter< ::QFlags<QPaintEngine::PaintEngineFeature> > : QFlagsConverter< ::QFlags<QPaintEngine::PaintEngineFeature> >
{
};

template<>
struct Converter< ::QPaintEngine::DirtyFlag > : EnumConverter< ::QPaintEngine::DirtyFlag >
{
};
template<>
struct Converter< ::QFlags<QPaintEngine::DirtyFlag> > : QFlagsConverter< ::QFlags<QPaintEngine::DirtyFlag> >
{
};

template<>
struct Converter< ::QPaintEngine* > : ObjectTypeConverter< ::QPaintEngine >
{
};

template<>
struct Converter< ::QPaintEngine > : ObjectTypeReferenceConverter< ::QPaintEngine >
{
};

template<>
struct Converter< ::QTextItem::RenderFlag > : EnumConverter< ::QTextItem::RenderFlag >
{
};
template<>
struct Converter< ::QFlags<QTextItem::RenderFlag> > : QFlagsConverter< ::QFlags<QTextItem::RenderFlag> >
{
};

template<>
struct Converter< ::QTextItem* > : ObjectTypeConverter< ::QTextItem >
{
};

template<>
struct Converter< ::QTextItem > : ObjectTypeReferenceConverter< ::QTextItem >
{
};

template<>
struct Converter< ::QFontMetricsF > : ValueTypeConverter< ::QFontMetricsF >
{
    static ::QFontMetricsF toCpp(PyObject* pyobj);
    static bool isConvertible(PyObject* pyobj);
};

template<>
struct Converter< ::QFontMetrics > : ValueTypeConverter< ::QFontMetrics >
{
    static ::QFontMetrics toCpp(PyObject* pyobj);
    static bool isConvertible(PyObject* pyobj);
};

template<>
struct Converter< ::QFontInfo > : ValueTypeConverter< ::QFontInfo >
{
    static ::QFontInfo toCpp(PyObject* pyobj);
    static bool isConvertible(PyObject* pyobj);
};

template<>
struct Converter< ::QFont::StyleStrategy > : EnumConverter< ::QFont::StyleStrategy >
{
};

template<>
struct Converter< ::QFont::SpacingType > : EnumConverter< ::QFont::SpacingType >
{
};

template<>
struct Converter< ::QFont::StyleHint > : EnumConverter< ::QFont::StyleHint >
{
};

template<>
struct Converter< ::QFont::Weight > : EnumConverter< ::QFont::Weight >
{
};

template<>
struct Converter< ::QFont::Capitalization > : EnumConverter< ::QFont::Capitalization >
{
};

template<>
struct Converter< ::QFont::Stretch > : EnumConverter< ::QFont::Stretch >
{
};

template<>
struct Converter< ::QFont::Style > : EnumConverter< ::QFont::Style >
{
};

template<>
struct Converter< ::QFont > : ValueTypeConverter< ::QFont >
{
    static ::QFont toCpp(PyObject* pyobj);
    static bool isConvertible(PyObject* pyobj);
};

template<>
struct Converter< ::QTextCharFormat::VerticalAlignment > : EnumConverter< ::QTextCharFormat::VerticalAlignment >
{
};

template<>
struct Converter< ::QTextCharFormat::UnderlineStyle > : EnumConverter< ::QTextCharFormat::UnderlineStyle >
{
};

template<>
struct Converter< ::QTextCharFormat > : ValueTypeConverter< ::QTextCharFormat >
{
};

template<>
struct Converter< ::QTextTableCellFormat > : ValueTypeConverter< ::QTextTableCellFormat >
{
};

template<>
struct Converter< ::QTextImageFormat > : ValueTypeConverter< ::QTextImageFormat >
{
};

template<>
struct Converter< ::QPen > : ValueTypeConverter< ::QPen >
{
    static ::QPen toCpp(PyObject* pyobj);
    static bool isConvertible(PyObject* pyobj);
};

template<>
struct Converter< ::QTextOption::TabType > : EnumConverter< ::QTextOption::TabType >
{
};

template<>
struct Converter< ::QTextOption::Flag > : EnumConverter< ::QTextOption::Flag >
{
};
template<>
struct Converter< ::QFlags<QTextOption::Flag> > : QFlagsConverter< ::QFlags<QTextOption::Flag> >
{
};

template<>
struct Converter< ::QTextOption::WrapMode > : EnumConverter< ::QTextOption::WrapMode >
{
};

template<>
struct Converter< ::QTextOption > : ValueTypeConverter< ::QTextOption >
{
    static ::QTextOption toCpp(PyObject* pyobj);
    static bool isConvertible(PyObject* pyobj);
};

template<>
struct Converter< ::QTextOption::Tab > : ValueTypeConverter< ::QTextOption::Tab >
{
};

template<>
struct Converter< ::QTileRules > : ValueTypeConverter< ::QTileRules >
{
    static ::QTileRules toCpp(PyObject* pyobj);
    static bool isConvertible(PyObject* pyobj);
};

template<>
struct Converter< ::QGradient::CoordinateMode > : EnumConverter< ::QGradient::CoordinateMode >
{
};

template<>
struct Converter< ::QGradient::Spread > : EnumConverter< ::QGradient::Spread >
{
};

template<>
struct Converter< ::QGradient::Type > : EnumConverter< ::QGradient::Type >
{
};

template<>
struct Converter< ::QGradient::InterpolationMode > : EnumConverter< ::QGradient::InterpolationMode >
{
};

template<>
struct Converter< ::QGradient > : ValueTypeConverter< ::QGradient >
{
};

template<>
struct Converter< ::QConicalGradient > : ValueTypeConverter< ::QConicalGradient >
{
};

template<>
struct Converter< ::QRadialGradient > : ValueTypeConverter< ::QRadialGradient >
{
};

template<>
struct Converter< ::QLinearGradient > : ValueTypeConverter< ::QLinearGradient >
{
};

template<>
struct Converter< ::QBrush > : ValueTypeConverter< ::QBrush >
{
    static ::QBrush toCpp(PyObject* pyobj);
    static bool isConvertible(PyObject* pyobj);
};

template<>
struct Converter< ::QPaintDevice::PaintDeviceMetric > : EnumConverter< ::QPaintDevice::PaintDeviceMetric >
{
};

template<>
struct Converter< ::QPaintDevice* > : ObjectTypeConverter< ::QPaintDevice >
{
};

template<>
struct Converter< ::QPaintDevice > : ObjectTypeReferenceConverter< ::QPaintDevice >
{
};

template<>
struct Converter< ::QPrinter::OutputFormat > : EnumConverter< ::QPrinter::OutputFormat >
{
};

template<>
struct Converter< ::QPrinter::DuplexMode > : EnumConverter< ::QPrinter::DuplexMode >
{
};

template<>
struct Converter< ::QPrinter::PrintRange > : EnumConverter< ::QPrinter::PrintRange >
{
};

template<>
struct Converter< ::QPrinter::Unit > : EnumConverter< ::QPrinter::Unit >
{
};

template<>
struct Converter< ::QPrinter::PrinterMode > : EnumConverter< ::QPrinter::PrinterMode >
{
};

template<>
struct Converter< ::QPrinter::Orientation > : EnumConverter< ::QPrinter::Orientation >
{
};

template<>
struct Converter< ::QPrinter::PrinterState > : EnumConverter< ::QPrinter::PrinterState >
{
};

template<>
struct Converter< ::QPrinter::ColorMode > : EnumConverter< ::QPrinter::ColorMode >
{
};

template<>
struct Converter< ::QPrinter::PaperSource > : EnumConverter< ::QPrinter::PaperSource >
{
};

template<>
struct Converter< ::QPrinter::PageOrder > : EnumConverter< ::QPrinter::PageOrder >
{
};

template<>
struct Converter< ::QPrinter::PageSize > : EnumConverter< ::QPrinter::PageSize >
{
};

template<>
struct Converter< ::QPrinter* > : ObjectTypeConverter< ::QPrinter >
{
};

template<>
struct Converter< ::QPrinter > : ObjectTypeReferenceConverter< ::QPrinter >
{
};

template<>
struct Converter< ::QPicture > : ValueTypeConverter< ::QPicture >
{
};

template<>
struct Converter< ::QTransform::TransformationType > : EnumConverter< ::QTransform::TransformationType >
{
};

template<>
struct Converter< ::QTransform > : ValueTypeConverter< ::QTransform >
{
};

template<>
struct Converter< ::QPainterPathStroker* > : ObjectTypeConverter< ::QPainterPathStroker >
{
};

template<>
struct Converter< ::QPainterPathStroker > : ObjectTypeReferenceConverter< ::QPainterPathStroker >
{
};

template<>
struct Converter< ::QMatrix > : ValueTypeConverter< ::QMatrix >
{
};

template<>
struct Converter< ::QPainterPath::ElementType > : EnumConverter< ::QPainterPath::ElementType >
{
};

template<>
struct Converter< ::QPainterPath > : ValueTypeConverter< ::QPainterPath >
{
};

template<>
struct Converter< ::QPainterPath::Element > : ValueTypeConverter< ::QPainterPath::Element >
{
};

template<>
struct Converter< ::QPolygonF > : ValueTypeConverter< ::QPolygonF >
{
    static ::QPolygonF toCpp(PyObject* pyobj);
    static bool isConvertible(PyObject* pyobj);
};

template<>
struct Converter< ::QPolygon > : ValueTypeConverter< ::QPolygon >
{
    static ::QPolygon toCpp(PyObject* pyobj);
    static bool isConvertible(PyObject* pyobj);
};

template<>
struct Converter< ::QColor::Spec > : EnumConverter< ::QColor::Spec >
{
};

template<>
struct Converter< ::QColor > : ValueTypeConverter< ::QColor >
{
    static ::QColor toCpp(PyObject* pyobj);
    static bool isConvertible(PyObject* pyobj);
};

template<>
struct Converter< ::QTextLayout::CursorMode > : EnumConverter< ::QTextLayout::CursorMode >
{
};

template<>
struct Converter< ::QTextLayout* > : ObjectTypeConverter< ::QTextLayout >
{
};

template<>
struct Converter< ::QTextLayout > : ObjectTypeReferenceConverter< ::QTextLayout >
{
};

template<>
struct Converter< ::QTextLayout::FormatRange > : ValueTypeConverter< ::QTextLayout::FormatRange >
{
};

template<>
struct Converter< ::QPixmap::ShareMode > : EnumConverter< ::QPixmap::ShareMode >
{
};

template<>
struct Converter< ::QPixmap >
{
    static ::QPixmap toCpp(PyObject* pyobj);
    static bool isConvertible(PyObject* pyobj);
    static bool checkType(PyObject* pyobj);
    static inline PyObject* toPython(void* cppObj) { return toPython(*reinterpret_cast< ::QPixmap* >(cppObj)); }
    static PyObject* toPython(const ::QPixmap& cppObj);
};

template<>
struct Converter< ::QImage::InvertMode > : EnumConverter< ::QImage::InvertMode >
{
};

template<>
struct Converter< ::QImage::Format > : EnumConverter< ::QImage::Format >
{
};

template<>
struct Converter< ::QImage > : ValueTypeConverter< ::QImage >
{
};

template<>
struct Converter< ::QBitmap > : ValueTypeConverter< ::QBitmap >
{
    static ::QBitmap toCpp(PyObject* pyobj);
    static bool isConvertible(PyObject* pyobj);
};

template<>
struct Converter< ::QGraphicsLayoutItem* > : ObjectTypeConverter< ::QGraphicsLayoutItem >
{
};

template<>
struct Converter< ::QGraphicsLayoutItem > : ObjectTypeReferenceConverter< ::QGraphicsLayoutItem >
{
};

template<>
struct Converter< ::QGraphicsLayout* > : ObjectTypeConverter< ::QGraphicsLayout >
{
};

template<>
struct Converter< ::QGraphicsLayout > : ObjectTypeReferenceConverter< ::QGraphicsLayout >
{
};

template<>
struct Converter< ::QGraphicsLinearLayout* > : ObjectTypeConverter< ::QGraphicsLinearLayout >
{
};

template<>
struct Converter< ::QGraphicsLinearLayout > : ObjectTypeReferenceConverter< ::QGraphicsLinearLayout >
{
};

template<>
struct Converter< ::QGraphicsGridLayout* > : ObjectTypeConverter< ::QGraphicsGridLayout >
{
};

template<>
struct Converter< ::QGraphicsGridLayout > : ObjectTypeReferenceConverter< ::QGraphicsGridLayout >
{
};

template<>
struct Converter< ::QGraphicsAnchorLayout* > : ObjectTypeConverter< ::QGraphicsAnchorLayout >
{
};

template<>
struct Converter< ::QGraphicsAnchorLayout > : ObjectTypeReferenceConverter< ::QGraphicsAnchorLayout >
{
};

template<>
struct Converter< ::QGraphicsItem::CacheMode > : EnumConverter< ::QGraphicsItem::CacheMode >
{
};

template<>
struct Converter< ::QGraphicsItem::PanelModality > : EnumConverter< ::QGraphicsItem::PanelModality >
{
};

template<>
struct Converter< ::QGraphicsItem::GraphicsItemFlag > : EnumConverter< ::QGraphicsItem::GraphicsItemFlag >
{
};
template<>
struct Converter< ::QFlags<QGraphicsItem::GraphicsItemFlag> > : QFlagsConverter< ::QFlags<QGraphicsItem::GraphicsItemFlag> >
{
};

template<>
struct Converter< ::QGraphicsItem::GraphicsItemChange > : EnumConverter< ::QGraphicsItem::GraphicsItemChange >
{
};

template<>
struct Converter< ::QGraphicsItem::Extension > : EnumConverter< ::QGraphicsItem::Extension >
{
};

template<>
struct Converter< ::QGraphicsItem* > : ObjectTypeConverter< ::QGraphicsItem >
{
};

template<>
struct Converter< ::QGraphicsItem > : ObjectTypeReferenceConverter< ::QGraphicsItem >
{
};

template<>
struct Converter< ::QAbstractGraphicsShapeItem* > : ObjectTypeConverter< ::QAbstractGraphicsShapeItem >
{
};

template<>
struct Converter< ::QAbstractGraphicsShapeItem > : ObjectTypeReferenceConverter< ::QAbstractGraphicsShapeItem >
{
};

template<>
struct Converter< ::QGraphicsItemGroup* > : ObjectTypeConverter< ::QGraphicsItemGroup >
{
};

template<>
struct Converter< ::QGraphicsItemGroup > : ObjectTypeReferenceConverter< ::QGraphicsItemGroup >
{
};

template<>
struct Converter< ::QGraphicsSimpleTextItem* > : ObjectTypeConverter< ::QGraphicsSimpleTextItem >
{
};

template<>
struct Converter< ::QGraphicsSimpleTextItem > : ObjectTypeReferenceConverter< ::QGraphicsSimpleTextItem >
{
};

template<>
struct Converter< ::QGraphicsPixmapItem::ShapeMode > : EnumConverter< ::QGraphicsPixmapItem::ShapeMode >
{
};

template<>
struct Converter< ::QGraphicsPixmapItem* > : ObjectTypeConverter< ::QGraphicsPixmapItem >
{
};

template<>
struct Converter< ::QGraphicsPixmapItem > : ObjectTypeReferenceConverter< ::QGraphicsPixmapItem >
{
};

template<>
struct Converter< ::QGraphicsLineItem* > : ObjectTypeConverter< ::QGraphicsLineItem >
{
};

template<>
struct Converter< ::QGraphicsLineItem > : ObjectTypeReferenceConverter< ::QGraphicsLineItem >
{
};

template<>
struct Converter< ::QGraphicsPolygonItem* > : ObjectTypeConverter< ::QGraphicsPolygonItem >
{
};

template<>
struct Converter< ::QGraphicsPolygonItem > : ObjectTypeReferenceConverter< ::QGraphicsPolygonItem >
{
};

template<>
struct Converter< ::QIcon::Mode > : EnumConverter< ::QIcon::Mode >
{
};

template<>
struct Converter< ::QIcon::State > : EnumConverter< ::QIcon::State >
{
};

template<>
struct Converter< ::QIcon > : ValueTypeConverter< ::QIcon >
{
    static ::QIcon toCpp(PyObject* pyobj);
    static bool isConvertible(PyObject* pyobj);
};

template<>
struct Converter< ::QIconEngineV2::IconEngineHook > : EnumConverter< ::QIconEngineV2::IconEngineHook >
{
};

template<>
struct Converter< ::QIconEngineV2* > : ObjectTypeConverter< ::QIconEngineV2 >
{
};

template<>
struct Converter< ::QIconEngineV2 > : ObjectTypeReferenceConverter< ::QIconEngineV2 >
{
};

template<>
struct Converter< ::QGraphicsRectItem* > : ObjectTypeConverter< ::QGraphicsRectItem >
{
};

template<>
struct Converter< ::QGraphicsRectItem > : ObjectTypeReferenceConverter< ::QGraphicsRectItem >
{
};

template<>
struct Converter< ::QGraphicsPathItem* > : ObjectTypeConverter< ::QGraphicsPathItem >
{
};

template<>
struct Converter< ::QGraphicsPathItem > : ObjectTypeReferenceConverter< ::QGraphicsPathItem >
{
};

template<>
struct Converter< ::QPainter::CompositionMode > : EnumConverter< ::QPainter::CompositionMode >
{
};

template<>
struct Converter< ::QPainter::RenderHint > : EnumConverter< ::QPainter::RenderHint >
{
};
template<>
struct Converter< ::QFlags<QPainter::RenderHint> > : QFlagsConverter< ::QFlags<QPainter::RenderHint> >
{
};

template<>
struct Converter< ::QPainter::PixmapFragmentHint > : EnumConverter< ::QPainter::PixmapFragmentHint >
{
};
template<>
struct Converter< ::QFlags<QPainter::PixmapFragmentHint> > : QFlagsConverter< ::QFlags<QPainter::PixmapFragmentHint> >
{
};

template<>
struct Converter< ::QPainter* > : ObjectTypeConverter< ::QPainter >
{
};

template<>
struct Converter< ::QPainter > : ObjectTypeReferenceConverter< ::QPainter >
{
};

template<>
struct Converter< ::QStylePainter* > : ObjectTypeConverter< ::QStylePainter >
{
};

template<>
struct Converter< ::QStylePainter > : ObjectTypeReferenceConverter< ::QStylePainter >
{
};

template<>
struct Converter< ::QGraphicsEllipseItem* > : ObjectTypeConverter< ::QGraphicsEllipseItem >
{
};

template<>
struct Converter< ::QGraphicsEllipseItem > : ObjectTypeReferenceConverter< ::QGraphicsEllipseItem >
{
};

template<>
struct Converter< ::QAbstractProxyModel* > : ObjectTypeConverter< ::QAbstractProxyModel >
{
};

template<>
struct Converter< ::QAbstractProxyModel > : ObjectTypeReferenceConverter< ::QAbstractProxyModel >
{
};

template<>
struct Converter< ::QStringListModel* > : ObjectTypeConverter< ::QStringListModel >
{
};

template<>
struct Converter< ::QStringListModel > : ObjectTypeReferenceConverter< ::QStringListModel >
{
};

template<>
struct Converter< ::QStandardItemModel* > : ObjectTypeConverter< ::QStandardItemModel >
{
};

template<>
struct Converter< ::QStandardItemModel > : ObjectTypeReferenceConverter< ::QStandardItemModel >
{
};

template<>
struct Converter< ::QSortFilterProxyModel* > : ObjectTypeConverter< ::QSortFilterProxyModel >
{
};

template<>
struct Converter< ::QSortFilterProxyModel > : ObjectTypeReferenceConverter< ::QSortFilterProxyModel >
{
};

template<>
struct Converter< ::QFileSystemModel::Roles > : EnumConverter< ::QFileSystemModel::Roles >
{
};

template<>
struct Converter< ::QFileSystemModel* > : ObjectTypeConverter< ::QFileSystemModel >
{
};

template<>
struct Converter< ::QFileSystemModel > : ObjectTypeReferenceConverter< ::QFileSystemModel >
{
};

template<>
struct Converter< ::QProxyModel* > : ObjectTypeConverter< ::QProxyModel >
{
};

template<>
struct Converter< ::QProxyModel > : ObjectTypeReferenceConverter< ::QProxyModel >
{
};

template<>
struct Converter< ::QDirModel::Roles > : EnumConverter< ::QDirModel::Roles >
{
};

template<>
struct Converter< ::QDirModel* > : ObjectTypeConverter< ::QDirModel >
{
};

template<>
struct Converter< ::QDirModel > : ObjectTypeReferenceConverter< ::QDirModel >
{
};

template<>
struct Converter< ::QApplication::Type > : EnumConverter< ::QApplication::Type >
{
};

template<>
struct Converter< ::QApplication::ColorSpec > : EnumConverter< ::QApplication::ColorSpec >
{
};

template<>
struct Converter< ::QApplication* > : ObjectTypeConverter< ::QApplication >
{
};

template<>
struct Converter< ::QApplication > : ObjectTypeReferenceConverter< ::QApplication >
{
};

template<>
struct Converter< ::QStyleOptionTab::StyleOptionVersion > : EnumConverter< ::QStyleOptionTab::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleOptionTab::CornerWidget > : EnumConverter< ::QStyleOptionTab::CornerWidget >
{
};
template<>
struct Converter< ::QFlags<QStyleOptionTab::CornerWidget> > : QFlagsConverter< ::QFlags<QStyleOptionTab::CornerWidget> >
{
};

template<>
struct Converter< ::QStyleOptionTab::TabPosition > : EnumConverter< ::QStyleOptionTab::TabPosition >
{
};

template<>
struct Converter< ::QStyleOptionTab::SelectedPosition > : EnumConverter< ::QStyleOptionTab::SelectedPosition >
{
};

template<>
struct Converter< ::QStyleOptionTab::StyleOptionType > : EnumConverter< ::QStyleOptionTab::StyleOptionType >
{
};

template<>
struct Converter< ::QStyleOptionTab* > : ObjectTypeConverter< ::QStyleOptionTab >
{
};

template<>
struct Converter< ::QStyleOptionTab > : ObjectTypeReferenceConverter< ::QStyleOptionTab >
{
};

template<>
struct Converter< ::QStyleOptionTabV2::StyleOptionVersion > : EnumConverter< ::QStyleOptionTabV2::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleOptionTabV2* > : ObjectTypeConverter< ::QStyleOptionTabV2 >
{
};

template<>
struct Converter< ::QStyleOptionTabV2 > : ObjectTypeReferenceConverter< ::QStyleOptionTabV2 >
{
};

template<>
struct Converter< ::QStyleOptionTabV3::StyleOptionVersion > : EnumConverter< ::QStyleOptionTabV3::StyleOptionVersion >
{
};

template<>
struct Converter< ::QStyleOptionTabV3* > : ObjectTypeConverter< ::QStyleOptionTabV3 >
{
};

template<>
struct Converter< ::QStyleOptionTabV3 > : ObjectTypeReferenceConverter< ::QStyleOptionTabV3 >
{
};

template<>
struct Converter< ::QRegion::RegionType > : EnumConverter< ::QRegion::RegionType >
{
};

template<>
struct Converter< ::QRegion > : ValueTypeConverter< ::QRegion >
{
    static ::QRegion toCpp(PyObject* pyobj);
    static bool isConvertible(PyObject* pyobj);
};

template<>
struct Converter< ::QMouseEventTransition* > : ObjectTypeConverter< ::QMouseEventTransition >
{
};

template<>
struct Converter< ::QMouseEventTransition > : ObjectTypeReferenceConverter< ::QMouseEventTransition >
{
};

template<>
struct Converter< ::QKeyEventTransition* > : ObjectTypeConverter< ::QKeyEventTransition >
{
};

template<>
struct Converter< ::QKeyEventTransition > : ObjectTypeReferenceConverter< ::QKeyEventTransition >
{
};

template<>
struct Converter< ::QInputEvent* > : ObjectTypeConverter< ::QInputEvent >
{
};

template<>
struct Converter< ::QInputEvent > : ObjectTypeReferenceConverter< ::QInputEvent >
{
};

template<>
struct Converter< ::QTouchEvent::DeviceType > : EnumConverter< ::QTouchEvent::DeviceType >
{
};

template<>
struct Converter< ::QTouchEvent* > : ObjectTypeConverter< ::QTouchEvent >
{
};

template<>
struct Converter< ::QTouchEvent > : ObjectTypeReferenceConverter< ::QTouchEvent >
{
};

template<>
struct Converter< ::QTouchEvent::TouchPoint > : ValueTypeConverter< ::QTouchEvent::TouchPoint >
{
    static ::QTouchEvent::TouchPoint toCpp(PyObject* pyobj);
    static bool isConvertible(PyObject* pyobj);
};

template<>
struct Converter< ::QContextMenuEvent::Reason > : EnumConverter< ::QContextMenuEvent::Reason >
{
};

template<>
struct Converter< ::QContextMenuEvent* > : ObjectTypeConverter< ::QContextMenuEvent >
{
};

template<>
struct Converter< ::QContextMenuEvent > : ObjectTypeReferenceConverter< ::QContextMenuEvent >
{
};

template<>
struct Converter< ::QKeyEvent* > : ObjectTypeConverter< ::QKeyEvent >
{
};

template<>
struct Converter< ::QKeyEvent > : ObjectTypeReferenceConverter< ::QKeyEvent >
{
};

template<>
struct Converter< ::QTabletEvent::TabletDevice > : EnumConverter< ::QTabletEvent::TabletDevice >
{
};

template<>
struct Converter< ::QTabletEvent::PointerType > : EnumConverter< ::QTabletEvent::PointerType >
{
};

template<>
struct Converter< ::QTabletEvent* > : ObjectTypeConverter< ::QTabletEvent >
{
};

template<>
struct Converter< ::QTabletEvent > : ObjectTypeReferenceConverter< ::QTabletEvent >
{
};

template<>
struct Converter< ::QWheelEvent* > : ObjectTypeConverter< ::QWheelEvent >
{
};

template<>
struct Converter< ::QWheelEvent > : ObjectTypeReferenceConverter< ::QWheelEvent >
{
};

template<>
struct Converter< ::QMouseEvent* > : ObjectTypeConverter< ::QMouseEvent >
{
};

template<>
struct Converter< ::QMouseEvent > : ObjectTypeReferenceConverter< ::QMouseEvent >
{
};

template<>
struct Converter< ::QGestureEvent* > : ObjectTypeConverter< ::QGestureEvent >
{
};

template<>
struct Converter< ::QGestureEvent > : ObjectTypeReferenceConverter< ::QGestureEvent >
{
};

template<>
struct Converter< ::QWindowStateChangeEvent* > : ObjectTypeConverter< ::QWindowStateChangeEvent >
{
};

template<>
struct Converter< ::QWindowStateChangeEvent > : ObjectTypeReferenceConverter< ::QWindowStateChangeEvent >
{
};

template<>
struct Converter< ::QClipboardEvent* > : ObjectTypeConverter< ::QClipboardEvent >
{
};

template<>
struct Converter< ::QClipboardEvent > : ObjectTypeReferenceConverter< ::QClipboardEvent >
{
};

template<>
struct Converter< ::QShortcutEvent* > : ObjectTypeConverter< ::QShortcutEvent >
{
};

template<>
struct Converter< ::QShortcutEvent > : ObjectTypeReferenceConverter< ::QShortcutEvent >
{
};

template<>
struct Converter< ::QToolBarChangeEvent* > : ObjectTypeConverter< ::QToolBarChangeEvent >
{
};

template<>
struct Converter< ::QToolBarChangeEvent > : ObjectTypeReferenceConverter< ::QToolBarChangeEvent >
{
};

template<>
struct Converter< ::QFileOpenEvent* > : ObjectTypeConverter< ::QFileOpenEvent >
{
};

template<>
struct Converter< ::QFileOpenEvent > : ObjectTypeReferenceConverter< ::QFileOpenEvent >
{
};

template<>
struct Converter< ::QActionEvent* > : ObjectTypeConverter< ::QActionEvent >
{
};

template<>
struct Converter< ::QActionEvent > : ObjectTypeReferenceConverter< ::QActionEvent >
{
};

template<>
struct Converter< ::QWhatsThisClickedEvent* > : ObjectTypeConverter< ::QWhatsThisClickedEvent >
{
};

template<>
struct Converter< ::QWhatsThisClickedEvent > : ObjectTypeReferenceConverter< ::QWhatsThisClickedEvent >
{
};

template<>
struct Converter< ::QStatusTipEvent* > : ObjectTypeConverter< ::QStatusTipEvent >
{
};

template<>
struct Converter< ::QStatusTipEvent > : ObjectTypeReferenceConverter< ::QStatusTipEvent >
{
};

template<>
struct Converter< ::QHelpEvent* > : ObjectTypeConverter< ::QHelpEvent >
{
};

template<>
struct Converter< ::QHelpEvent > : ObjectTypeReferenceConverter< ::QHelpEvent >
{
};

template<>
struct Converter< ::QDragLeaveEvent* > : ObjectTypeConverter< ::QDragLeaveEvent >
{
};

template<>
struct Converter< ::QDragLeaveEvent > : ObjectTypeReferenceConverter< ::QDragLeaveEvent >
{
};

template<>
struct Converter< ::QDropEvent* > : ObjectTypeConverter< ::QDropEvent >
{
};

template<>
struct Converter< ::QDropEvent > : ObjectTypeReferenceConverter< ::QDropEvent >
{
};

template<>
struct Converter< ::QDragMoveEvent* > : ObjectTypeConverter< ::QDragMoveEvent >
{
};

template<>
struct Converter< ::QDragMoveEvent > : ObjectTypeReferenceConverter< ::QDragMoveEvent >
{
};

template<>
struct Converter< ::QDragEnterEvent* > : ObjectTypeConverter< ::QDragEnterEvent >
{
};

template<>
struct Converter< ::QDragEnterEvent > : ObjectTypeReferenceConverter< ::QDragEnterEvent >
{
};

template<>
struct Converter< ::QInputMethodEvent::AttributeType > : EnumConverter< ::QInputMethodEvent::AttributeType >
{
};

template<>
struct Converter< ::QInputMethodEvent* > : ObjectTypeConverter< ::QInputMethodEvent >
{
};

template<>
struct Converter< ::QInputMethodEvent > : ObjectTypeReferenceConverter< ::QInputMethodEvent >
{
};

template<>
struct Converter< ::QInputMethodEvent::Attribute > : ValueTypeConverter< ::QInputMethodEvent::Attribute >
{
};

template<>
struct Converter< ::QHideEvent* > : ObjectTypeConverter< ::QHideEvent >
{
};

template<>
struct Converter< ::QHideEvent > : ObjectTypeReferenceConverter< ::QHideEvent >
{
};

template<>
struct Converter< ::QAccessibleEvent* > : ObjectTypeConverter< ::QAccessibleEvent >
{
};

template<>
struct Converter< ::QAccessibleEvent > : ObjectTypeReferenceConverter< ::QAccessibleEvent >
{
};

template<>
struct Converter< ::QShowEvent* > : ObjectTypeConverter< ::QShowEvent >
{
};

template<>
struct Converter< ::QShowEvent > : ObjectTypeReferenceConverter< ::QShowEvent >
{
};

template<>
struct Converter< ::QIconDragEvent* > : ObjectTypeConverter< ::QIconDragEvent >
{
};

template<>
struct Converter< ::QIconDragEvent > : ObjectTypeReferenceConverter< ::QIconDragEvent >
{
};

template<>
struct Converter< ::QCloseEvent* > : ObjectTypeConverter< ::QCloseEvent >
{
};

template<>
struct Converter< ::QCloseEvent > : ObjectTypeReferenceConverter< ::QCloseEvent >
{
};

template<>
struct Converter< ::QResizeEvent* > : ObjectTypeConverter< ::QResizeEvent >
{
};

template<>
struct Converter< ::QResizeEvent > : ObjectTypeReferenceConverter< ::QResizeEvent >
{
};

template<>
struct Converter< ::QMoveEvent* > : ObjectTypeConverter< ::QMoveEvent >
{
};

template<>
struct Converter< ::QMoveEvent > : ObjectTypeReferenceConverter< ::QMoveEvent >
{
};

template<>
struct Converter< ::QGraphicsSceneEvent* > : ObjectTypeConverter< ::QGraphicsSceneEvent >
{
};

template<>
struct Converter< ::QGraphicsSceneEvent > : ObjectTypeReferenceConverter< ::QGraphicsSceneEvent >
{
};

template<>
struct Converter< ::QGraphicsSceneMoveEvent* > : ObjectTypeConverter< ::QGraphicsSceneMoveEvent >
{
};

template<>
struct Converter< ::QGraphicsSceneMoveEvent > : ObjectTypeReferenceConverter< ::QGraphicsSceneMoveEvent >
{
};

template<>
struct Converter< ::QGraphicsSceneResizeEvent* > : ObjectTypeConverter< ::QGraphicsSceneResizeEvent >
{
};

template<>
struct Converter< ::QGraphicsSceneResizeEvent > : ObjectTypeReferenceConverter< ::QGraphicsSceneResizeEvent >
{
};

template<>
struct Converter< ::QGraphicsSceneDragDropEvent* > : ObjectTypeConverter< ::QGraphicsSceneDragDropEvent >
{
};

template<>
struct Converter< ::QGraphicsSceneDragDropEvent > : ObjectTypeReferenceConverter< ::QGraphicsSceneDragDropEvent >
{
};

template<>
struct Converter< ::QGraphicsSceneHelpEvent* > : ObjectTypeConverter< ::QGraphicsSceneHelpEvent >
{
};

template<>
struct Converter< ::QGraphicsSceneHelpEvent > : ObjectTypeReferenceConverter< ::QGraphicsSceneHelpEvent >
{
};

template<>
struct Converter< ::QGraphicsSceneHoverEvent* > : ObjectTypeConverter< ::QGraphicsSceneHoverEvent >
{
};

template<>
struct Converter< ::QGraphicsSceneHoverEvent > : ObjectTypeReferenceConverter< ::QGraphicsSceneHoverEvent >
{
};

template<>
struct Converter< ::QGraphicsSceneContextMenuEvent::Reason > : EnumConverter< ::QGraphicsSceneContextMenuEvent::Reason >
{
};

template<>
struct Converter< ::QGraphicsSceneContextMenuEvent* > : ObjectTypeConverter< ::QGraphicsSceneContextMenuEvent >
{
};

template<>
struct Converter< ::QGraphicsSceneContextMenuEvent > : ObjectTypeReferenceConverter< ::QGraphicsSceneContextMenuEvent >
{
};

template<>
struct Converter< ::QGraphicsSceneWheelEvent* > : ObjectTypeConverter< ::QGraphicsSceneWheelEvent >
{
};

template<>
struct Converter< ::QGraphicsSceneWheelEvent > : ObjectTypeReferenceConverter< ::QGraphicsSceneWheelEvent >
{
};

template<>
struct Converter< ::QGraphicsSceneMouseEvent* > : ObjectTypeConverter< ::QGraphicsSceneMouseEvent >
{
};

template<>
struct Converter< ::QGraphicsSceneMouseEvent > : ObjectTypeReferenceConverter< ::QGraphicsSceneMouseEvent >
{
};

template<>
struct Converter< ::QPaintEvent* > : ObjectTypeConverter< ::QPaintEvent >
{
};

template<>
struct Converter< ::QPaintEvent > : ObjectTypeReferenceConverter< ::QPaintEvent >
{
};

template<>
struct Converter< ::QFocusEvent* > : ObjectTypeConverter< ::QFocusEvent >
{
};

template<>
struct Converter< ::QFocusEvent > : ObjectTypeReferenceConverter< ::QFocusEvent >
{
};

template<>
struct Converter< ::QHoverEvent* > : ObjectTypeConverter< ::QHoverEvent >
{
};

template<>
struct Converter< ::QHoverEvent > : ObjectTypeReferenceConverter< ::QHoverEvent >
{
};

template<>
struct Converter< ::QGraphicsAnchor* > : ObjectTypeConverter< ::QGraphicsAnchor >
{
};

template<>
struct Converter< ::QGraphicsAnchor > : ObjectTypeReferenceConverter< ::QGraphicsAnchor >
{
};

template<>
struct Converter< ::QDataWidgetMapper::SubmitPolicy > : EnumConverter< ::QDataWidgetMapper::SubmitPolicy >
{
};

template<>
struct Converter< ::QDataWidgetMapper* > : ObjectTypeConverter< ::QDataWidgetMapper >
{
};

template<>
struct Converter< ::QDataWidgetMapper > : ObjectTypeReferenceConverter< ::QDataWidgetMapper >
{
};

template<>
struct Converter< ::QDrag* > : ObjectTypeConverter< ::QDrag >
{
};

template<>
struct Converter< ::QDrag > : ObjectTypeReferenceConverter< ::QDrag >
{
};

template<>
struct Converter< ::QClipboard::Mode > : EnumConverter< ::QClipboard::Mode >
{
};

template<>
struct Converter< ::QClipboard* > : ObjectTypeConverter< ::QClipboard >
{
};

template<>
struct Converter< ::QClipboard > : ObjectTypeReferenceConverter< ::QClipboard >
{
};

template<>
struct Converter< ::QGesture::GestureCancelPolicy > : EnumConverter< ::QGesture::GestureCancelPolicy >
{
};

template<>
struct Converter< ::QGesture* > : ObjectTypeConverter< ::QGesture >
{
};

template<>
struct Converter< ::QGesture > : ObjectTypeReferenceConverter< ::QGesture >
{
};

template<>
struct Converter< ::QTapGesture* > : ObjectTypeConverter< ::QTapGesture >
{
};

template<>
struct Converter< ::QTapGesture > : ObjectTypeReferenceConverter< ::QTapGesture >
{
};

template<>
struct Converter< ::QTapAndHoldGesture* > : ObjectTypeConverter< ::QTapAndHoldGesture >
{
};

template<>
struct Converter< ::QTapAndHoldGesture > : ObjectTypeReferenceConverter< ::QTapAndHoldGesture >
{
};

template<>
struct Converter< ::QSwipeGesture::SwipeDirection > : EnumConverter< ::QSwipeGesture::SwipeDirection >
{
};

template<>
struct Converter< ::QSwipeGesture* > : ObjectTypeConverter< ::QSwipeGesture >
{
};

template<>
struct Converter< ::QSwipeGesture > : ObjectTypeReferenceConverter< ::QSwipeGesture >
{
};

template<>
struct Converter< ::QPinchGesture::ChangeFlag > : EnumConverter< ::QPinchGesture::ChangeFlag >
{
};
template<>
struct Converter< ::QFlags<QPinchGesture::ChangeFlag> > : QFlagsConverter< ::QFlags<QPinchGesture::ChangeFlag> >
{
};

template<>
struct Converter< ::QPinchGesture* > : ObjectTypeConverter< ::QPinchGesture >
{
};

template<>
struct Converter< ::QPinchGesture > : ObjectTypeReferenceConverter< ::QPinchGesture >
{
};

template<>
struct Converter< ::QPanGesture* > : ObjectTypeConverter< ::QPanGesture >
{
};

template<>
struct Converter< ::QPanGesture > : ObjectTypeReferenceConverter< ::QPanGesture >
{
};

template<>
struct Converter< ::QItemSelectionModel::SelectionFlag > : EnumConverter< ::QItemSelectionModel::SelectionFlag >
{
};
template<>
struct Converter< ::QFlags<QItemSelectionModel::SelectionFlag> > : QFlagsConverter< ::QFlags<QItemSelectionModel::SelectionFlag> >
{
};

template<>
struct Converter< ::QItemSelectionModel* > : ObjectTypeConverter< ::QItemSelectionModel >
{
};

template<>
struct Converter< ::QItemSelectionModel > : ObjectTypeReferenceConverter< ::QItemSelectionModel >
{
};

template<>
struct Converter< ::QLayout::SizeConstraint > : EnumConverter< ::QLayout::SizeConstraint >
{
};

template<>
struct Converter< ::QLayout* > : ObjectTypeConverter< ::QLayout >
{
};

template<>
struct Converter< ::QLayout > : ObjectTypeReferenceConverter< ::QLayout >
{
};

template<>
struct Converter< ::QBoxLayout::Direction > : EnumConverter< ::QBoxLayout::Direction >
{
};

template<>
struct Converter< ::QBoxLayout* > : ObjectTypeConverter< ::QBoxLayout >
{
};

template<>
struct Converter< ::QBoxLayout > : ObjectTypeReferenceConverter< ::QBoxLayout >
{
};

template<>
struct Converter< ::QVBoxLayout* > : ObjectTypeConverter< ::QVBoxLayout >
{
};

template<>
struct Converter< ::QVBoxLayout > : ObjectTypeReferenceConverter< ::QVBoxLayout >
{
};

template<>
struct Converter< ::QHBoxLayout* > : ObjectTypeConverter< ::QHBoxLayout >
{
};

template<>
struct Converter< ::QHBoxLayout > : ObjectTypeReferenceConverter< ::QHBoxLayout >
{
};

template<>
struct Converter< ::QStackedLayout::StackingMode > : EnumConverter< ::QStackedLayout::StackingMode >
{
};

template<>
struct Converter< ::QStackedLayout* > : ObjectTypeConverter< ::QStackedLayout >
{
};

template<>
struct Converter< ::QStackedLayout > : ObjectTypeReferenceConverter< ::QStackedLayout >
{
};

template<>
struct Converter< ::QGridLayout* > : ObjectTypeConverter< ::QGridLayout >
{
};

template<>
struct Converter< ::QGridLayout > : ObjectTypeReferenceConverter< ::QGridLayout >
{
};

template<>
struct Converter< ::QFormLayout::FieldGrowthPolicy > : EnumConverter< ::QFormLayout::FieldGrowthPolicy >
{
};

template<>
struct Converter< ::QFormLayout::RowWrapPolicy > : EnumConverter< ::QFormLayout::RowWrapPolicy >
{
};

template<>
struct Converter< ::QFormLayout::ItemRole > : EnumConverter< ::QFormLayout::ItemRole >
{
};

template<>
struct Converter< ::QFormLayout* > : ObjectTypeConverter< ::QFormLayout >
{
};

template<>
struct Converter< ::QFormLayout > : ObjectTypeReferenceConverter< ::QFormLayout >
{
};

template<>
struct Converter< ::QAbstractItemDelegate::EndEditHint > : EnumConverter< ::QAbstractItemDelegate::EndEditHint >
{
};

template<>
struct Converter< ::QAbstractItemDelegate* > : ObjectTypeConverter< ::QAbstractItemDelegate >
{
};

template<>
struct Converter< ::QAbstractItemDelegate > : ObjectTypeReferenceConverter< ::QAbstractItemDelegate >
{
};

template<>
struct Converter< ::QStyledItemDelegate* > : ObjectTypeConverter< ::QStyledItemDelegate >
{
};

template<>
struct Converter< ::QStyledItemDelegate > : ObjectTypeReferenceConverter< ::QStyledItemDelegate >
{
};

template<>
struct Converter< ::QItemDelegate* > : ObjectTypeConverter< ::QItemDelegate >
{
};

template<>
struct Converter< ::QItemDelegate > : ObjectTypeReferenceConverter< ::QItemDelegate >
{
};

template<>
struct Converter< ::QGraphicsEffect::PixmapPadMode > : EnumConverter< ::QGraphicsEffect::PixmapPadMode >
{
};

template<>
struct Converter< ::QGraphicsEffect::ChangeFlag > : EnumConverter< ::QGraphicsEffect::ChangeFlag >
{
};
template<>
struct Converter< ::QFlags<QGraphicsEffect::ChangeFlag> > : QFlagsConverter< ::QFlags<QGraphicsEffect::ChangeFlag> >
{
};

template<>
struct Converter< ::QGraphicsEffect* > : ObjectTypeConverter< ::QGraphicsEffect >
{
};

template<>
struct Converter< ::QGraphicsEffect > : ObjectTypeReferenceConverter< ::QGraphicsEffect >
{
};

template<>
struct Converter< ::QGraphicsOpacityEffect* > : ObjectTypeConverter< ::QGraphicsOpacityEffect >
{
};

template<>
struct Converter< ::QGraphicsOpacityEffect > : ObjectTypeReferenceConverter< ::QGraphicsOpacityEffect >
{
};

template<>
struct Converter< ::QGraphicsDropShadowEffect* > : ObjectTypeConverter< ::QGraphicsDropShadowEffect >
{
};

template<>
struct Converter< ::QGraphicsDropShadowEffect > : ObjectTypeReferenceConverter< ::QGraphicsDropShadowEffect >
{
};

template<>
struct Converter< ::QGraphicsBlurEffect::BlurHint > : EnumConverter< ::QGraphicsBlurEffect::BlurHint >
{
};
template<>
struct Converter< ::QFlags<QGraphicsBlurEffect::BlurHint> > : QFlagsConverter< ::QFlags<QGraphicsBlurEffect::BlurHint> >
{
};

template<>
struct Converter< ::QGraphicsBlurEffect* > : ObjectTypeConverter< ::QGraphicsBlurEffect >
{
};

template<>
struct Converter< ::QGraphicsBlurEffect > : ObjectTypeReferenceConverter< ::QGraphicsBlurEffect >
{
};

template<>
struct Converter< ::QGraphicsColorizeEffect* > : ObjectTypeConverter< ::QGraphicsColorizeEffect >
{
};

template<>
struct Converter< ::QGraphicsColorizeEffect > : ObjectTypeReferenceConverter< ::QGraphicsColorizeEffect >
{
};

template<>
struct Converter< ::QPyTextObject* > : ObjectTypeConverter< ::QPyTextObject >
{
};

template<>
struct Converter< ::QPyTextObject > : ObjectTypeReferenceConverter< ::QPyTextObject >
{
};

template<>
struct Converter< ::QInputContext::StandardFormat > : EnumConverter< ::QInputContext::StandardFormat >
{
};

template<>
struct Converter< ::QInputContext* > : ObjectTypeConverter< ::QInputContext >
{
};

template<>
struct Converter< ::QInputContext > : ObjectTypeReferenceConverter< ::QInputContext >
{
};

template<>
struct Converter< ::QUndoStack* > : ObjectTypeConverter< ::QUndoStack >
{
};

template<>
struct Converter< ::QUndoStack > : ObjectTypeReferenceConverter< ::QUndoStack >
{
};

template<>
struct Converter< ::QGraphicsObject* > : ObjectTypeConverter< ::QGraphicsObject >
{
};

template<>
struct Converter< ::QGraphicsObject > : ObjectTypeReferenceConverter< ::QGraphicsObject >
{
};

template<>
struct Converter< ::QGraphicsWidget* > : ObjectTypeConverter< ::QGraphicsWidget >
{
};

template<>
struct Converter< ::QGraphicsWidget > : ObjectTypeReferenceConverter< ::QGraphicsWidget >
{
};

template<>
struct Converter< ::QGraphicsProxyWidget* > : ObjectTypeConverter< ::QGraphicsProxyWidget >
{
};

template<>
struct Converter< ::QGraphicsProxyWidget > : ObjectTypeReferenceConverter< ::QGraphicsProxyWidget >
{
};

template<>
struct Converter< ::QGraphicsTextItem* > : ObjectTypeConverter< ::QGraphicsTextItem >
{
};

template<>
struct Converter< ::QGraphicsTextItem > : ObjectTypeReferenceConverter< ::QGraphicsTextItem >
{
};

template<>
struct Converter< ::QActionGroup* > : ObjectTypeConverter< ::QActionGroup >
{
};

template<>
struct Converter< ::QActionGroup > : ObjectTypeReferenceConverter< ::QActionGroup >
{
};

template<>
struct Converter< ::QUndoGroup* > : ObjectTypeConverter< ::QUndoGroup >
{
};

template<>
struct Converter< ::QUndoGroup > : ObjectTypeReferenceConverter< ::QUndoGroup >
{
};

template<>
struct Converter< ::QAction::Priority > : EnumConverter< ::QAction::Priority >
{
};

template<>
struct Converter< ::QAction::ActionEvent > : EnumConverter< ::QAction::ActionEvent >
{
};

template<>
struct Converter< ::QAction::SoftKeyRole > : EnumConverter< ::QAction::SoftKeyRole >
{
};

template<>
struct Converter< ::QAction::MenuRole > : EnumConverter< ::QAction::MenuRole >
{
};

template<>
struct Converter< ::QAction* > : ObjectTypeConverter< ::QAction >
{
};

template<>
struct Converter< ::QAction > : ObjectTypeReferenceConverter< ::QAction >
{
};

template<>
struct Converter< ::QWidgetAction* > : ObjectTypeConverter< ::QWidgetAction >
{
};

template<>
struct Converter< ::QWidgetAction > : ObjectTypeReferenceConverter< ::QWidgetAction >
{
};

template<>
struct Converter< ::QSystemTrayIcon::MessageIcon > : EnumConverter< ::QSystemTrayIcon::MessageIcon >
{
};

template<>
struct Converter< ::QSystemTrayIcon::ActivationReason > : EnumConverter< ::QSystemTrayIcon::ActivationReason >
{
};

template<>
struct Converter< ::QSystemTrayIcon* > : ObjectTypeConverter< ::QSystemTrayIcon >
{
};

template<>
struct Converter< ::QSystemTrayIcon > : ObjectTypeReferenceConverter< ::QSystemTrayIcon >
{
};

template<>
struct Converter< ::QGraphicsTransform* > : ObjectTypeConverter< ::QGraphicsTransform >
{
};

template<>
struct Converter< ::QGraphicsTransform > : ObjectTypeReferenceConverter< ::QGraphicsTransform >
{
};

template<>
struct Converter< ::QGraphicsRotation* > : ObjectTypeConverter< ::QGraphicsRotation >
{
};

template<>
struct Converter< ::QGraphicsRotation > : ObjectTypeReferenceConverter< ::QGraphicsRotation >
{
};

template<>
struct Converter< ::QGraphicsScale* > : ObjectTypeConverter< ::QGraphicsScale >
{
};

template<>
struct Converter< ::QGraphicsScale > : ObjectTypeReferenceConverter< ::QGraphicsScale >
{
};

template<>
struct Converter< ::QCompleter::ModelSorting > : EnumConverter< ::QCompleter::ModelSorting >
{
};

template<>
struct Converter< ::QCompleter::CompletionMode > : EnumConverter< ::QCompleter::CompletionMode >
{
};

template<>
struct Converter< ::QCompleter* > : ObjectTypeConverter< ::QCompleter >
{
};

template<>
struct Converter< ::QCompleter > : ObjectTypeReferenceConverter< ::QCompleter >
{
};

template<>
struct Converter< ::QSyntaxHighlighter* > : ObjectTypeConverter< ::QSyntaxHighlighter >
{
};

template<>
struct Converter< ::QSyntaxHighlighter > : ObjectTypeReferenceConverter< ::QSyntaxHighlighter >
{
};

template<>
struct Converter< ::QValidator::State > : EnumConverter< ::QValidator::State >
{
};

template<>
struct Converter< ::QValidator* > : ObjectTypeConverter< ::QValidator >
{
};

template<>
struct Converter< ::QValidator > : ObjectTypeReferenceConverter< ::QValidator >
{
};

template<>
struct Converter< ::QRegExpValidator* > : ObjectTypeConverter< ::QRegExpValidator >
{
};

template<>
struct Converter< ::QRegExpValidator > : ObjectTypeReferenceConverter< ::QRegExpValidator >
{
};

template<>
struct Converter< ::QDoubleValidator::Notation > : EnumConverter< ::QDoubleValidator::Notation >
{
};

template<>
struct Converter< ::QDoubleValidator* > : ObjectTypeConverter< ::QDoubleValidator >
{
};

template<>
struct Converter< ::QDoubleValidator > : ObjectTypeReferenceConverter< ::QDoubleValidator >
{
};

template<>
struct Converter< ::QIntValidator* > : ObjectTypeConverter< ::QIntValidator >
{
};

template<>
struct Converter< ::QIntValidator > : ObjectTypeReferenceConverter< ::QIntValidator >
{
};

template<>
struct Converter< ::QWidget::RenderFlag > : EnumConverter< ::QWidget::RenderFlag >
{
};
template<>
struct Converter< ::QFlags<QWidget::RenderFlag> > : QFlagsConverter< ::QFlags<QWidget::RenderFlag> >
{
};

template<>
struct Converter< ::QWidget* > : ObjectTypeConverter< ::QWidget >
{
};

template<>
struct Converter< ::QWidget > : ObjectTypeReferenceConverter< ::QWidget >
{
};

template<>
struct Converter< ::QDesktopWidget* > : ObjectTypeConverter< ::QDesktopWidget >
{
};

template<>
struct Converter< ::QDesktopWidget > : ObjectTypeReferenceConverter< ::QDesktopWidget >
{
};

template<>
struct Converter< ::QX11EmbedContainer::Error > : EnumConverter< ::QX11EmbedContainer::Error >
{
};

template<>
struct Converter< ::QX11EmbedContainer* > : ObjectTypeConverter< ::QX11EmbedContainer >
{
};

template<>
struct Converter< ::QX11EmbedContainer > : ObjectTypeReferenceConverter< ::QX11EmbedContainer >
{
};

template<>
struct Converter< ::QX11EmbedWidget::Error > : EnumConverter< ::QX11EmbedWidget::Error >
{
};

template<>
struct Converter< ::QX11EmbedWidget* > : ObjectTypeConverter< ::QX11EmbedWidget >
{
};

template<>
struct Converter< ::QX11EmbedWidget > : ObjectTypeReferenceConverter< ::QX11EmbedWidget >
{
};

template<>
struct Converter< ::QWorkspace::WindowOrder > : EnumConverter< ::QWorkspace::WindowOrder >
{
};

template<>
struct Converter< ::QWorkspace* > : ObjectTypeConverter< ::QWorkspace >
{
};

template<>
struct Converter< ::QWorkspace > : ObjectTypeReferenceConverter< ::QWorkspace >
{
};

template<>
struct Converter< ::QToolBar* > : ObjectTypeConverter< ::QToolBar >
{
};

template<>
struct Converter< ::QToolBar > : ObjectTypeReferenceConverter< ::QToolBar >
{
};

template<>
struct Converter< ::QStatusBar* > : ObjectTypeConverter< ::QStatusBar >
{
};

template<>
struct Converter< ::QStatusBar > : ObjectTypeReferenceConverter< ::QStatusBar >
{
};

template<>
struct Converter< ::QSplitterHandle* > : ObjectTypeConverter< ::QSplitterHandle >
{
};

template<>
struct Converter< ::QSplitterHandle > : ObjectTypeReferenceConverter< ::QSplitterHandle >
{
};

template<>
struct Converter< ::QSplashScreen* > : ObjectTypeConverter< ::QSplashScreen >
{
};

template<>
struct Converter< ::QSplashScreen > : ObjectTypeReferenceConverter< ::QSplashScreen >
{
};

template<>
struct Converter< ::QDialog::DialogCode > : EnumConverter< ::QDialog::DialogCode >
{
};

template<>
struct Converter< ::QDialog* > : ObjectTypeConverter< ::QDialog >
{
};

template<>
struct Converter< ::QDialog > : ObjectTypeReferenceConverter< ::QDialog >
{
};

template<>
struct Converter< ::QFileDialog::FileMode > : EnumConverter< ::QFileDialog::FileMode >
{
};

template<>
struct Converter< ::QFileDialog::Option > : EnumConverter< ::QFileDialog::Option >
{
};
template<>
struct Converter< ::QFlags<QFileDialog::Option> > : QFlagsConverter< ::QFlags<QFileDialog::Option> >
{
};

template<>
struct Converter< ::QFileDialog::DialogLabel > : EnumConverter< ::QFileDialog::DialogLabel >
{
};

template<>
struct Converter< ::QFileDialog::ViewMode > : EnumConverter< ::QFileDialog::ViewMode >
{
};

template<>
struct Converter< ::QFileDialog::AcceptMode > : EnumConverter< ::QFileDialog::AcceptMode >
{
};

template<>
struct Converter< ::QFileDialog* > : ObjectTypeConverter< ::QFileDialog >
{
};

template<>
struct Converter< ::QFileDialog > : ObjectTypeReferenceConverter< ::QFileDialog >
{
};

template<>
struct Converter< ::QSizeGrip* > : ObjectTypeConverter< ::QSizeGrip >
{
};

template<>
struct Converter< ::QSizeGrip > : ObjectTypeReferenceConverter< ::QSizeGrip >
{
};

template<>
struct Converter< ::QProgressBar::Direction > : EnumConverter< ::QProgressBar::Direction >
{
};

template<>
struct Converter< ::QProgressBar* > : ObjectTypeConverter< ::QProgressBar >
{
};

template<>
struct Converter< ::QProgressBar > : ObjectTypeReferenceConverter< ::QProgressBar >
{
};

template<>
struct Converter< ::QPrintPreviewWidget::ZoomMode > : EnumConverter< ::QPrintPreviewWidget::ZoomMode >
{
};

template<>
struct Converter< ::QPrintPreviewWidget::ViewMode > : EnumConverter< ::QPrintPreviewWidget::ViewMode >
{
};

template<>
struct Converter< ::QPrintPreviewWidget* > : ObjectTypeConverter< ::QPrintPreviewWidget >
{
};

template<>
struct Converter< ::QPrintPreviewWidget > : ObjectTypeReferenceConverter< ::QPrintPreviewWidget >
{
};

template<>
struct Converter< ::QFrame::StyleMask > : EnumConverter< ::QFrame::StyleMask >
{
};

template<>
struct Converter< ::QFrame::Shape > : EnumConverter< ::QFrame::Shape >
{
};

template<>
struct Converter< ::QFrame::Shadow > : EnumConverter< ::QFrame::Shadow >
{
};

template<>
struct Converter< ::QFrame* > : ObjectTypeConverter< ::QFrame >
{
};

template<>
struct Converter< ::QFrame > : ObjectTypeReferenceConverter< ::QFrame >
{
};

template<>
struct Converter< ::QToolBox* > : ObjectTypeConverter< ::QToolBox >
{
};

template<>
struct Converter< ::QToolBox > : ObjectTypeReferenceConverter< ::QToolBox >
{
};

template<>
struct Converter< ::QAbstractScrollArea* > : ObjectTypeConverter< ::QAbstractScrollArea >
{
};

template<>
struct Converter< ::QAbstractScrollArea > : ObjectTypeReferenceConverter< ::QAbstractScrollArea >
{
};

template<>
struct Converter< ::QAbstractItemView::DragDropMode > : EnumConverter< ::QAbstractItemView::DragDropMode >
{
};

template<>
struct Converter< ::QAbstractItemView::SelectionBehavior > : EnumConverter< ::QAbstractItemView::SelectionBehavior >
{
};

template<>
struct Converter< ::QAbstractItemView::EditTrigger > : EnumConverter< ::QAbstractItemView::EditTrigger >
{
};
template<>
struct Converter< ::QFlags<QAbstractItemView::EditTrigger> > : QFlagsConverter< ::QFlags<QAbstractItemView::EditTrigger> >
{
};

template<>
struct Converter< ::QAbstractItemView::ScrollMode > : EnumConverter< ::QAbstractItemView::ScrollMode >
{
};

template<>
struct Converter< ::QAbstractItemView::CursorAction > : EnumConverter< ::QAbstractItemView::CursorAction >
{
};

template<>
struct Converter< ::QAbstractItemView::DropIndicatorPosition > : EnumConverter< ::QAbstractItemView::DropIndicatorPosition >
{
};

template<>
struct Converter< ::QAbstractItemView::ScrollHint > : EnumConverter< ::QAbstractItemView::ScrollHint >
{
};

template<>
struct Converter< ::QAbstractItemView::SelectionMode > : EnumConverter< ::QAbstractItemView::SelectionMode >
{
};

template<>
struct Converter< ::QAbstractItemView::State > : EnumConverter< ::QAbstractItemView::State >
{
};

template<>
struct Converter< ::QAbstractItemView* > : ObjectTypeConverter< ::QAbstractItemView >
{
};

template<>
struct Converter< ::QAbstractItemView > : ObjectTypeReferenceConverter< ::QAbstractItemView >
{
};

template<>
struct Converter< ::QTableView* > : ObjectTypeConverter< ::QTableView >
{
};

template<>
struct Converter< ::QTableView > : ObjectTypeReferenceConverter< ::QTableView >
{
};

template<>
struct Converter< ::QTableWidget* > : ObjectTypeConverter< ::QTableWidget >
{
};

template<>
struct Converter< ::QTableWidget > : ObjectTypeReferenceConverter< ::QTableWidget >
{
};

template<>
struct Converter< ::QColumnView* > : ObjectTypeConverter< ::QColumnView >
{
};

template<>
struct Converter< ::QColumnView > : ObjectTypeReferenceConverter< ::QColumnView >
{
};

template<>
struct Converter< ::QListView::ResizeMode > : EnumConverter< ::QListView::ResizeMode >
{
};

template<>
struct Converter< ::QListView::LayoutMode > : EnumConverter< ::QListView::LayoutMode >
{
};

template<>
struct Converter< ::QListView::ViewMode > : EnumConverter< ::QListView::ViewMode >
{
};

template<>
struct Converter< ::QListView::Flow > : EnumConverter< ::QListView::Flow >
{
};

template<>
struct Converter< ::QListView::Movement > : EnumConverter< ::QListView::Movement >
{
};

template<>
struct Converter< ::QListView* > : ObjectTypeConverter< ::QListView >
{
};

template<>
struct Converter< ::QListView > : ObjectTypeReferenceConverter< ::QListView >
{
};

template<>
struct Converter< ::QUndoView* > : ObjectTypeConverter< ::QUndoView >
{
};

template<>
struct Converter< ::QUndoView > : ObjectTypeReferenceConverter< ::QUndoView >
{
};

template<>
struct Converter< ::QListWidget* > : ObjectTypeConverter< ::QListWidget >
{
};

template<>
struct Converter< ::QListWidget > : ObjectTypeReferenceConverter< ::QListWidget >
{
};

template<>
struct Converter< ::QTreeView* > : ObjectTypeConverter< ::QTreeView >
{
};

template<>
struct Converter< ::QTreeView > : ObjectTypeReferenceConverter< ::QTreeView >
{
};

template<>
struct Converter< ::QTreeWidget* > : ObjectTypeConverter< ::QTreeWidget >
{
};

template<>
struct Converter< ::QTreeWidget > : ObjectTypeReferenceConverter< ::QTreeWidget >
{
};

template<>
struct Converter< ::QHeaderView::ResizeMode > : EnumConverter< ::QHeaderView::ResizeMode >
{
};

template<>
struct Converter< ::QHeaderView* > : ObjectTypeConverter< ::QHeaderView >
{
};

template<>
struct Converter< ::QHeaderView > : ObjectTypeReferenceConverter< ::QHeaderView >
{
};

template<>
struct Converter< ::QScrollArea* > : ObjectTypeConverter< ::QScrollArea >
{
};

template<>
struct Converter< ::QScrollArea > : ObjectTypeReferenceConverter< ::QScrollArea >
{
};

template<>
struct Converter< ::QStackedWidget* > : ObjectTypeConverter< ::QStackedWidget >
{
};

template<>
struct Converter< ::QStackedWidget > : ObjectTypeReferenceConverter< ::QStackedWidget >
{
};

template<>
struct Converter< ::QSplitter* > : ObjectTypeConverter< ::QSplitter >
{
};

template<>
struct Converter< ::QSplitter > : ObjectTypeReferenceConverter< ::QSplitter >
{
};

template<>
struct Converter< ::QPlainTextEdit::LineWrapMode > : EnumConverter< ::QPlainTextEdit::LineWrapMode >
{
};

template<>
struct Converter< ::QPlainTextEdit* > : ObjectTypeConverter< ::QPlainTextEdit >
{
};

template<>
struct Converter< ::QPlainTextEdit > : ObjectTypeReferenceConverter< ::QPlainTextEdit >
{
};

template<>
struct Converter< ::QRubberBand::Shape > : EnumConverter< ::QRubberBand::Shape >
{
};

template<>
struct Converter< ::QRubberBand* > : ObjectTypeConverter< ::QRubberBand >
{
};

template<>
struct Converter< ::QRubberBand > : ObjectTypeReferenceConverter< ::QRubberBand >
{
};

template<>
struct Converter< ::QTextEdit::AutoFormattingFlag > : EnumConverter< ::QTextEdit::AutoFormattingFlag >
{
};
template<>
struct Converter< ::QFlags<QTextEdit::AutoFormattingFlag> > : QFlagsConverter< ::QFlags<QTextEdit::AutoFormattingFlag> >
{
};

template<>
struct Converter< ::QTextEdit::LineWrapMode > : EnumConverter< ::QTextEdit::LineWrapMode >
{
};

template<>
struct Converter< ::QTextEdit* > : ObjectTypeConverter< ::QTextEdit >
{
};

template<>
struct Converter< ::QTextEdit > : ObjectTypeReferenceConverter< ::QTextEdit >
{
};

template<>
struct Converter< ::QTextEdit::ExtraSelection > : ValueTypeConverter< ::QTextEdit::ExtraSelection >
{
};

template<>
struct Converter< ::QTextBrowser* > : ObjectTypeConverter< ::QTextBrowser >
{
};

template<>
struct Converter< ::QTextBrowser > : ObjectTypeReferenceConverter< ::QTextBrowser >
{
};

template<>
struct Converter< ::QTabWidget::TabShape > : EnumConverter< ::QTabWidget::TabShape >
{
};

template<>
struct Converter< ::QTabWidget::TabPosition > : EnumConverter< ::QTabWidget::TabPosition >
{
};

template<>
struct Converter< ::QTabWidget* > : ObjectTypeConverter< ::QTabWidget >
{
};

template<>
struct Converter< ::QTabWidget > : ObjectTypeReferenceConverter< ::QTabWidget >
{
};

template<>
struct Converter< ::QTabBar::SelectionBehavior > : EnumConverter< ::QTabBar::SelectionBehavior >
{
};

template<>
struct Converter< ::QTabBar::ButtonPosition > : EnumConverter< ::QTabBar::ButtonPosition >
{
};

template<>
struct Converter< ::QTabBar::Shape > : EnumConverter< ::QTabBar::Shape >
{
};

template<>
struct Converter< ::QTabBar* > : ObjectTypeConverter< ::QTabBar >
{
};

template<>
struct Converter< ::QTabBar > : ObjectTypeReferenceConverter< ::QTabBar >
{
};

template<>
struct Converter< ::QMenuBar* > : ObjectTypeConverter< ::QMenuBar >
{
};

template<>
struct Converter< ::QMenuBar > : ObjectTypeReferenceConverter< ::QMenuBar >
{
};

template<>
struct Converter< ::QMenu* > : ObjectTypeConverter< ::QMenu >
{
};

template<>
struct Converter< ::QMenu > : ObjectTypeReferenceConverter< ::QMenu >
{
};

template<>
struct Converter< ::QAbstractSlider::SliderAction > : EnumConverter< ::QAbstractSlider::SliderAction >
{
};

template<>
struct Converter< ::QAbstractSlider::SliderChange > : EnumConverter< ::QAbstractSlider::SliderChange >
{
};

template<>
struct Converter< ::QAbstractSlider* > : ObjectTypeConverter< ::QAbstractSlider >
{
};

template<>
struct Converter< ::QAbstractSlider > : ObjectTypeReferenceConverter< ::QAbstractSlider >
{
};

template<>
struct Converter< ::QSlider::TickPosition > : EnumConverter< ::QSlider::TickPosition >
{
};

template<>
struct Converter< ::QSlider* > : ObjectTypeConverter< ::QSlider >
{
};

template<>
struct Converter< ::QSlider > : ObjectTypeReferenceConverter< ::QSlider >
{
};

template<>
struct Converter< ::QScrollBar* > : ObjectTypeConverter< ::QScrollBar >
{
};

template<>
struct Converter< ::QScrollBar > : ObjectTypeReferenceConverter< ::QScrollBar >
{
};

template<>
struct Converter< ::QMdiSubWindow::SubWindowOption > : EnumConverter< ::QMdiSubWindow::SubWindowOption >
{
};
template<>
struct Converter< ::QFlags<QMdiSubWindow::SubWindowOption> > : QFlagsConverter< ::QFlags<QMdiSubWindow::SubWindowOption> >
{
};

template<>
struct Converter< ::QMdiSubWindow* > : ObjectTypeConverter< ::QMdiSubWindow >
{
};

template<>
struct Converter< ::QMdiSubWindow > : ObjectTypeReferenceConverter< ::QMdiSubWindow >
{
};

template<>
struct Converter< ::QAbstractSpinBox::StepEnabledFlag > : EnumConverter< ::QAbstractSpinBox::StepEnabledFlag >
{
};
template<>
struct Converter< ::QFlags<QAbstractSpinBox::StepEnabledFlag> > : QFlagsConverter< ::QFlags<QAbstractSpinBox::StepEnabledFlag> >
{
};

template<>
struct Converter< ::QAbstractSpinBox::CorrectionMode > : EnumConverter< ::QAbstractSpinBox::CorrectionMode >
{
};

template<>
struct Converter< ::QAbstractSpinBox::ButtonSymbols > : EnumConverter< ::QAbstractSpinBox::ButtonSymbols >
{
};

template<>
struct Converter< ::QAbstractSpinBox* > : ObjectTypeConverter< ::QAbstractSpinBox >
{
};

template<>
struct Converter< ::QAbstractSpinBox > : ObjectTypeReferenceConverter< ::QAbstractSpinBox >
{
};

template<>
struct Converter< ::QDoubleSpinBox* > : ObjectTypeConverter< ::QDoubleSpinBox >
{
};

template<>
struct Converter< ::QDoubleSpinBox > : ObjectTypeReferenceConverter< ::QDoubleSpinBox >
{
};

template<>
struct Converter< ::QSpinBox* > : ObjectTypeConverter< ::QSpinBox >
{
};

template<>
struct Converter< ::QSpinBox > : ObjectTypeReferenceConverter< ::QSpinBox >
{
};

template<>
struct Converter< ::QMdiArea::WindowOrder > : EnumConverter< ::QMdiArea::WindowOrder >
{
};

template<>
struct Converter< ::QMdiArea::ViewMode > : EnumConverter< ::QMdiArea::ViewMode >
{
};

template<>
struct Converter< ::QMdiArea::AreaOption > : EnumConverter< ::QMdiArea::AreaOption >
{
};
template<>
struct Converter< ::QFlags<QMdiArea::AreaOption> > : QFlagsConverter< ::QFlags<QMdiArea::AreaOption> >
{
};

template<>
struct Converter< ::QMdiArea* > : ObjectTypeConverter< ::QMdiArea >
{
};

template<>
struct Converter< ::QMdiArea > : ObjectTypeReferenceConverter< ::QMdiArea >
{
};

template<>
struct Converter< ::QMainWindow::DockOption > : EnumConverter< ::QMainWindow::DockOption >
{
};
template<>
struct Converter< ::QFlags<QMainWindow::DockOption> > : QFlagsConverter< ::QFlags<QMainWindow::DockOption> >
{
};

template<>
struct Converter< ::QMainWindow* > : ObjectTypeConverter< ::QMainWindow >
{
};

template<>
struct Converter< ::QMainWindow > : ObjectTypeReferenceConverter< ::QMainWindow >
{
};

template<>
struct Converter< ::QLCDNumber::Mode > : EnumConverter< ::QLCDNumber::Mode >
{
};

template<>
struct Converter< ::QLCDNumber::SegmentStyle > : EnumConverter< ::QLCDNumber::SegmentStyle >
{
};

template<>
struct Converter< ::QLCDNumber* > : ObjectTypeConverter< ::QLCDNumber >
{
};

template<>
struct Converter< ::QLCDNumber > : ObjectTypeReferenceConverter< ::QLCDNumber >
{
};

template<>
struct Converter< ::QGroupBox* > : ObjectTypeConverter< ::QGroupBox >
{
};

template<>
struct Converter< ::QGroupBox > : ObjectTypeReferenceConverter< ::QGroupBox >
{
};

template<>
struct Converter< ::QLabel* > : ObjectTypeConverter< ::QLabel >
{
};

template<>
struct Converter< ::QLabel > : ObjectTypeReferenceConverter< ::QLabel >
{
};

template<>
struct Converter< ::QFocusFrame* > : ObjectTypeConverter< ::QFocusFrame >
{
};

template<>
struct Converter< ::QFocusFrame > : ObjectTypeReferenceConverter< ::QFocusFrame >
{
};

template<>
struct Converter< ::QDockWidget::DockWidgetFeature > : EnumConverter< ::QDockWidget::DockWidgetFeature >
{
};
template<>
struct Converter< ::QFlags<QDockWidget::DockWidgetFeature> > : QFlagsConverter< ::QFlags<QDockWidget::DockWidgetFeature> >
{
};

template<>
struct Converter< ::QDockWidget* > : ObjectTypeConverter< ::QDockWidget >
{
};

template<>
struct Converter< ::QDockWidget > : ObjectTypeReferenceConverter< ::QDockWidget >
{
};

template<>
struct Converter< ::QDialogButtonBox::ButtonLayout > : EnumConverter< ::QDialogButtonBox::ButtonLayout >
{
};

template<>
struct Converter< ::QDialogButtonBox::ButtonRole > : EnumConverter< ::QDialogButtonBox::ButtonRole >
{
};

template<>
struct Converter< ::QDialogButtonBox::StandardButton > : EnumConverter< ::QDialogButtonBox::StandardButton >
{
};
template<>
struct Converter< ::QFlags<QDialogButtonBox::StandardButton> > : QFlagsConverter< ::QFlags<QDialogButtonBox::StandardButton> >
{
};

template<>
struct Converter< ::QDialogButtonBox* > : ObjectTypeConverter< ::QDialogButtonBox >
{
};

template<>
struct Converter< ::QDialogButtonBox > : ObjectTypeReferenceConverter< ::QDialogButtonBox >
{
};

template<>
struct Converter< ::QDial* > : ObjectTypeConverter< ::QDial >
{
};

template<>
struct Converter< ::QDial > : ObjectTypeReferenceConverter< ::QDial >
{
};

template<>
struct Converter< ::QDateTimeEdit::Section > : EnumConverter< ::QDateTimeEdit::Section >
{
};
template<>
struct Converter< ::QFlags<QDateTimeEdit::Section> > : QFlagsConverter< ::QFlags<QDateTimeEdit::Section> >
{
};

template<>
struct Converter< ::QDateTimeEdit* > : ObjectTypeConverter< ::QDateTimeEdit >
{
};

template<>
struct Converter< ::QDateTimeEdit > : ObjectTypeReferenceConverter< ::QDateTimeEdit >
{
};

template<>
struct Converter< ::QDateEdit* > : ObjectTypeConverter< ::QDateEdit >
{
};

template<>
struct Converter< ::QDateEdit > : ObjectTypeReferenceConverter< ::QDateEdit >
{
};

template<>
struct Converter< ::QTimeEdit* > : ObjectTypeConverter< ::QTimeEdit >
{
};

template<>
struct Converter< ::QTimeEdit > : ObjectTypeReferenceConverter< ::QTimeEdit >
{
};

template<>
struct Converter< ::QComboBox::InsertPolicy > : EnumConverter< ::QComboBox::InsertPolicy >
{
};

template<>
struct Converter< ::QComboBox::SizeAdjustPolicy > : EnumConverter< ::QComboBox::SizeAdjustPolicy >
{
};

template<>
struct Converter< ::QComboBox* > : ObjectTypeConverter< ::QComboBox >
{
};

template<>
struct Converter< ::QComboBox > : ObjectTypeReferenceConverter< ::QComboBox >
{
};

template<>
struct Converter< ::QFontComboBox::FontFilter > : EnumConverter< ::QFontComboBox::FontFilter >
{
};
template<>
struct Converter< ::QFlags<QFontComboBox::FontFilter> > : QFlagsConverter< ::QFlags<QFontComboBox::FontFilter> >
{
};

template<>
struct Converter< ::QFontComboBox* > : ObjectTypeConverter< ::QFontComboBox >
{
};

template<>
struct Converter< ::QFontComboBox > : ObjectTypeReferenceConverter< ::QFontComboBox >
{
};

template<>
struct Converter< ::QCalendarWidget::HorizontalHeaderFormat > : EnumConverter< ::QCalendarWidget::HorizontalHeaderFormat >
{
};

template<>
struct Converter< ::QCalendarWidget::VerticalHeaderFormat > : EnumConverter< ::QCalendarWidget::VerticalHeaderFormat >
{
};

template<>
struct Converter< ::QCalendarWidget::SelectionMode > : EnumConverter< ::QCalendarWidget::SelectionMode >
{
};

template<>
struct Converter< ::QCalendarWidget* > : ObjectTypeConverter< ::QCalendarWidget >
{
};

template<>
struct Converter< ::QCalendarWidget > : ObjectTypeReferenceConverter< ::QCalendarWidget >
{
};

template<>
struct Converter< ::QAbstractButton* > : ObjectTypeConverter< ::QAbstractButton >
{
};

template<>
struct Converter< ::QAbstractButton > : ObjectTypeReferenceConverter< ::QAbstractButton >
{
};

template<>
struct Converter< ::QRadioButton* > : ObjectTypeConverter< ::QRadioButton >
{
};

template<>
struct Converter< ::QRadioButton > : ObjectTypeReferenceConverter< ::QRadioButton >
{
};

template<>
struct Converter< ::QToolButton::ToolButtonPopupMode > : EnumConverter< ::QToolButton::ToolButtonPopupMode >
{
};

template<>
struct Converter< ::QToolButton* > : ObjectTypeConverter< ::QToolButton >
{
};

template<>
struct Converter< ::QToolButton > : ObjectTypeReferenceConverter< ::QToolButton >
{
};

template<>
struct Converter< ::QPushButton* > : ObjectTypeConverter< ::QPushButton >
{
};

template<>
struct Converter< ::QPushButton > : ObjectTypeReferenceConverter< ::QPushButton >
{
};

template<>
struct Converter< ::QCommandLinkButton* > : ObjectTypeConverter< ::QCommandLinkButton >
{
};

template<>
struct Converter< ::QCommandLinkButton > : ObjectTypeReferenceConverter< ::QCommandLinkButton >
{
};

template<>
struct Converter< ::QCheckBox* > : ObjectTypeConverter< ::QCheckBox >
{
};

template<>
struct Converter< ::QCheckBox > : ObjectTypeReferenceConverter< ::QCheckBox >
{
};

template<>
struct Converter< ::QWizardPage* > : ObjectTypeConverter< ::QWizardPage >
{
};

template<>
struct Converter< ::QWizardPage > : ObjectTypeReferenceConverter< ::QWizardPage >
{
};

template<>
struct Converter< ::QWizard::WizardButton > : EnumConverter< ::QWizard::WizardButton >
{
};

template<>
struct Converter< ::QWizard::WizardStyle > : EnumConverter< ::QWizard::WizardStyle >
{
};

template<>
struct Converter< ::QWizard::WizardPixmap > : EnumConverter< ::QWizard::WizardPixmap >
{
};

template<>
struct Converter< ::QWizard::WizardOption > : EnumConverter< ::QWizard::WizardOption >
{
};
template<>
struct Converter< ::QFlags<QWizard::WizardOption> > : QFlagsConverter< ::QFlags<QWizard::WizardOption> >
{
};

template<>
struct Converter< ::QWizard* > : ObjectTypeConverter< ::QWizard >
{
};

template<>
struct Converter< ::QWizard > : ObjectTypeReferenceConverter< ::QWizard >
{
};

template<>
struct Converter< ::QProgressDialog* > : ObjectTypeConverter< ::QProgressDialog >
{
};

template<>
struct Converter< ::QProgressDialog > : ObjectTypeReferenceConverter< ::QProgressDialog >
{
};

template<>
struct Converter< ::QPrintPreviewDialog* > : ObjectTypeConverter< ::QPrintPreviewDialog >
{
};

template<>
struct Converter< ::QPrintPreviewDialog > : ObjectTypeReferenceConverter< ::QPrintPreviewDialog >
{
};

template<>
struct Converter< ::QMessageBox::ButtonRole > : EnumConverter< ::QMessageBox::ButtonRole >
{
};

template<>
struct Converter< ::QMessageBox::StandardButton > : EnumConverter< ::QMessageBox::StandardButton >
{
};
template<>
struct Converter< ::QFlags<QMessageBox::StandardButton> > : QFlagsConverter< ::QFlags<QMessageBox::StandardButton> >
{
};

template<>
struct Converter< ::QMessageBox::Icon > : EnumConverter< ::QMessageBox::Icon >
{
};

template<>
struct Converter< ::QMessageBox* > : ObjectTypeConverter< ::QMessageBox >
{
};

template<>
struct Converter< ::QMessageBox > : ObjectTypeReferenceConverter< ::QMessageBox >
{
};

template<>
struct Converter< ::QLineEdit::EchoMode > : EnumConverter< ::QLineEdit::EchoMode >
{
};

template<>
struct Converter< ::QLineEdit* > : ObjectTypeConverter< ::QLineEdit >
{
};

template<>
struct Converter< ::QLineEdit > : ObjectTypeReferenceConverter< ::QLineEdit >
{
};

template<>
struct Converter< ::QInputDialog::InputMode > : EnumConverter< ::QInputDialog::InputMode >
{
};

template<>
struct Converter< ::QInputDialog::InputDialogOption > : EnumConverter< ::QInputDialog::InputDialogOption >
{
};

template<>
struct Converter< ::QInputDialog* > : ObjectTypeConverter< ::QInputDialog >
{
};

template<>
struct Converter< ::QInputDialog > : ObjectTypeReferenceConverter< ::QInputDialog >
{
};

template<>
struct Converter< ::QFontDialog::FontDialogOption > : EnumConverter< ::QFontDialog::FontDialogOption >
{
};
template<>
struct Converter< ::QFlags<QFontDialog::FontDialogOption> > : QFlagsConverter< ::QFlags<QFontDialog::FontDialogOption> >
{
};

template<>
struct Converter< ::QFontDialog* > : ObjectTypeConverter< ::QFontDialog >
{
};

template<>
struct Converter< ::QFontDialog > : ObjectTypeReferenceConverter< ::QFontDialog >
{
};

template<>
struct Converter< ::QErrorMessage* > : ObjectTypeConverter< ::QErrorMessage >
{
};

template<>
struct Converter< ::QErrorMessage > : ObjectTypeReferenceConverter< ::QErrorMessage >
{
};

template<>
struct Converter< ::QColorDialog::ColorDialogOption > : EnumConverter< ::QColorDialog::ColorDialogOption >
{
};
template<>
struct Converter< ::QFlags<QColorDialog::ColorDialogOption> > : QFlagsConverter< ::QFlags<QColorDialog::ColorDialogOption> >
{
};

template<>
struct Converter< ::QColorDialog* > : ObjectTypeConverter< ::QColorDialog >
{
};

template<>
struct Converter< ::QColorDialog > : ObjectTypeReferenceConverter< ::QColorDialog >
{
};

template<>
struct Converter< ::QAbstractPrintDialog::PrintRange > : EnumConverter< ::QAbstractPrintDialog::PrintRange >
{
};

template<>
struct Converter< ::QAbstractPrintDialog::PrintDialogOption > : EnumConverter< ::QAbstractPrintDialog::PrintDialogOption >
{
};
template<>
struct Converter< ::QFlags<QAbstractPrintDialog::PrintDialogOption> > : QFlagsConverter< ::QFlags<QAbstractPrintDialog::PrintDialogOption> >
{
};

template<>
struct Converter< ::QAbstractPrintDialog* > : ObjectTypeConverter< ::QAbstractPrintDialog >
{
};

template<>
struct Converter< ::QAbstractPrintDialog > : ObjectTypeReferenceConverter< ::QAbstractPrintDialog >
{
};

template<>
struct Converter< ::QPrintDialog* > : ObjectTypeConverter< ::QPrintDialog >
{
};

template<>
struct Converter< ::QPrintDialog > : ObjectTypeReferenceConverter< ::QPrintDialog >
{
};

template<>
struct Converter< ::QAbstractPageSetupDialog* > : ObjectTypeConverter< ::QAbstractPageSetupDialog >
{
};

template<>
struct Converter< ::QAbstractPageSetupDialog > : ObjectTypeReferenceConverter< ::QAbstractPageSetupDialog >
{
};

template<>
struct Converter< ::QPageSetupDialog::PageSetupDialogOption > : EnumConverter< ::QPageSetupDialog::PageSetupDialogOption >
{
};
template<>
struct Converter< ::QFlags<QPageSetupDialog::PageSetupDialogOption> > : QFlagsConverter< ::QFlags<QPageSetupDialog::PageSetupDialogOption> >
{
};

template<>
struct Converter< ::QPageSetupDialog* > : ObjectTypeConverter< ::QPageSetupDialog >
{
};

template<>
struct Converter< ::QPageSetupDialog > : ObjectTypeReferenceConverter< ::QPageSetupDialog >
{
};

template<>
struct Converter< ::QStyle::PixelMetric > : EnumConverter< ::QStyle::PixelMetric >
{
};

template<>
struct Converter< ::QStyle::SubControl > : EnumConverter< ::QStyle::SubControl >
{
};
template<>
struct Converter< ::QFlags<QStyle::SubControl> > : QFlagsConverter< ::QFlags<QStyle::SubControl> >
{
};

template<>
struct Converter< ::QStyle::StandardPixmap > : EnumConverter< ::QStyle::StandardPixmap >
{
};

template<>
struct Converter< ::QStyle::StyleHint > : EnumConverter< ::QStyle::StyleHint >
{
};

template<>
struct Converter< ::QStyle::PrimitiveElement > : EnumConverter< ::QStyle::PrimitiveElement >
{
};

template<>
struct Converter< ::QStyle::ControlElement > : EnumConverter< ::QStyle::ControlElement >
{
};

template<>
struct Converter< ::QStyle::ContentsType > : EnumConverter< ::QStyle::ContentsType >
{
};

template<>
struct Converter< ::QStyle::StateFlag > : EnumConverter< ::QStyle::StateFlag >
{
};
template<>
struct Converter< ::QFlags<QStyle::StateFlag> > : QFlagsConverter< ::QFlags<QStyle::StateFlag> >
{
};

template<>
struct Converter< ::QStyle::ComplexControl > : EnumConverter< ::QStyle::ComplexControl >
{
};

template<>
struct Converter< ::QStyle::RequestSoftwareInputPanel > : EnumConverter< ::QStyle::RequestSoftwareInputPanel >
{
};

template<>
struct Converter< ::QStyle::SubElement > : EnumConverter< ::QStyle::SubElement >
{
};

template<>
struct Converter< ::QStyle* > : ObjectTypeConverter< ::QStyle >
{
};

template<>
struct Converter< ::QStyle > : ObjectTypeReferenceConverter< ::QStyle >
{
};

template<>
struct Converter< ::QCommonStyle* > : ObjectTypeConverter< ::QCommonStyle >
{
};

template<>
struct Converter< ::QCommonStyle > : ObjectTypeReferenceConverter< ::QCommonStyle >
{
};

template<>
struct Converter< ::QWindowsStyle* > : ObjectTypeConverter< ::QWindowsStyle >
{
};

template<>
struct Converter< ::QWindowsStyle > : ObjectTypeReferenceConverter< ::QWindowsStyle >
{
};

template<>
struct Converter< ::QPlastiqueStyle* > : ObjectTypeConverter< ::QPlastiqueStyle >
{
};

template<>
struct Converter< ::QPlastiqueStyle > : ObjectTypeReferenceConverter< ::QPlastiqueStyle >
{
};

template<>
struct Converter< ::QCleanlooksStyle* > : ObjectTypeConverter< ::QCleanlooksStyle >
{
};

template<>
struct Converter< ::QCleanlooksStyle > : ObjectTypeReferenceConverter< ::QCleanlooksStyle >
{
};

template<>
struct Converter< ::QMotifStyle* > : ObjectTypeConverter< ::QMotifStyle >
{
};

template<>
struct Converter< ::QMotifStyle > : ObjectTypeReferenceConverter< ::QMotifStyle >
{
};

template<>
struct Converter< ::QCDEStyle* > : ObjectTypeConverter< ::QCDEStyle >
{
};

template<>
struct Converter< ::QCDEStyle > : ObjectTypeReferenceConverter< ::QCDEStyle >
{
};

template<>
struct Converter< ::QTextObject* > : ObjectTypeConverter< ::QTextObject >
{
};

template<>
struct Converter< ::QTextObject > : ObjectTypeReferenceConverter< ::QTextObject >
{
};

template<>
struct Converter< ::QTextFrame* > : ObjectTypeConverter< ::QTextFrame >
{
};

template<>
struct Converter< ::QTextFrame > : ObjectTypeReferenceConverter< ::QTextFrame >
{
};

template<>
struct Converter< ::QTextTable* > : ObjectTypeConverter< ::QTextTable >
{
};

template<>
struct Converter< ::QTextTable > : ObjectTypeReferenceConverter< ::QTextTable >
{
};

template<>
struct Converter< ::QTextFrame::iterator > : ValueTypeConverter< ::QTextFrame::iterator >
{
};

template<>
struct Converter< ::QTextBlockGroup* > : ObjectTypeConverter< ::QTextBlockGroup >
{
};

template<>
struct Converter< ::QTextBlockGroup > : ObjectTypeReferenceConverter< ::QTextBlockGroup >
{
};

template<>
struct Converter< ::QTextList* > : ObjectTypeConverter< ::QTextList >
{
};

template<>
struct Converter< ::QTextList > : ObjectTypeReferenceConverter< ::QTextList >
{
};

template<>
struct Converter< ::QAbstractTextDocumentLayout* > : ObjectTypeConverter< ::QAbstractTextDocumentLayout >
{
};

template<>
struct Converter< ::QAbstractTextDocumentLayout > : ObjectTypeReferenceConverter< ::QAbstractTextDocumentLayout >
{
};

template<>
struct Converter< ::QAbstractTextDocumentLayout::Selection > : ValueTypeConverter< ::QAbstractTextDocumentLayout::Selection >
{
};

template<>
struct Converter< ::QAbstractTextDocumentLayout::PaintContext > : ValueTypeConverter< ::QAbstractTextDocumentLayout::PaintContext >
{
};

template<>
struct Converter< ::QPlainTextDocumentLayout* > : ObjectTypeConverter< ::QPlainTextDocumentLayout >
{
};

template<>
struct Converter< ::QPlainTextDocumentLayout > : ObjectTypeReferenceConverter< ::QPlainTextDocumentLayout >
{
};

template<>
struct Converter< ::QButtonGroup* > : ObjectTypeConverter< ::QButtonGroup >
{
};

template<>
struct Converter< ::QButtonGroup > : ObjectTypeReferenceConverter< ::QButtonGroup >
{
};

template<>
struct Converter< ::QGraphicsScene::SceneLayer > : EnumConverter< ::QGraphicsScene::SceneLayer >
{
};
template<>
struct Converter< ::QFlags<QGraphicsScene::SceneLayer> > : QFlagsConverter< ::QFlags<QGraphicsScene::SceneLayer> >
{
};

template<>
struct Converter< ::QGraphicsScene::ItemIndexMethod > : EnumConverter< ::QGraphicsScene::ItemIndexMethod >
{
};

template<>
struct Converter< ::QGraphicsScene* > : ObjectTypeConverter< ::QGraphicsScene >
{
};

template<>
struct Converter< ::QGraphicsScene > : ObjectTypeReferenceConverter< ::QGraphicsScene >
{
};

template<>
struct Converter< ::QGraphicsView::OptimizationFlag > : EnumConverter< ::QGraphicsView::OptimizationFlag >
{
};
template<>
struct Converter< ::QFlags<QGraphicsView::OptimizationFlag> > : QFlagsConverter< ::QFlags<QGraphicsView::OptimizationFlag> >
{
};

template<>
struct Converter< ::QGraphicsView::ViewportAnchor > : EnumConverter< ::QGraphicsView::ViewportAnchor >
{
};

template<>
struct Converter< ::QGraphicsView::ViewportUpdateMode > : EnumConverter< ::QGraphicsView::ViewportUpdateMode >
{
};

template<>
struct Converter< ::QGraphicsView::CacheModeFlag > : EnumConverter< ::QGraphicsView::CacheModeFlag >
{
};
template<>
struct Converter< ::QFlags<QGraphicsView::CacheModeFlag> > : QFlagsConverter< ::QFlags<QGraphicsView::CacheModeFlag> >
{
};

template<>
struct Converter< ::QGraphicsView::DragMode > : EnumConverter< ::QGraphicsView::DragMode >
{
};

template<>
struct Converter< ::QGraphicsView* > : ObjectTypeConverter< ::QGraphicsView >
{
};

template<>
struct Converter< ::QGraphicsView > : ObjectTypeReferenceConverter< ::QGraphicsView >
{
};

template<>
struct Converter< ::QSound* > : ObjectTypeConverter< ::QSound >
{
};

template<>
struct Converter< ::QSound > : ObjectTypeReferenceConverter< ::QSound >
{
};

template<>
struct Converter< ::QShortcut* > : ObjectTypeConverter< ::QShortcut >
{
};

template<>
struct Converter< ::QShortcut > : ObjectTypeReferenceConverter< ::QShortcut >
{
};

template<>
struct Converter< ::QSessionManager::RestartHint > : EnumConverter< ::QSessionManager::RestartHint >
{
};

template<>
struct Converter< ::QSessionManager* > : ObjectTypeConverter< ::QSessionManager >
{
};

template<>
struct Converter< ::QSessionManager > : ObjectTypeReferenceConverter< ::QSessionManager >
{
};

template<>
struct Converter< ::QGraphicsItemAnimation* > : ObjectTypeConverter< ::QGraphicsItemAnimation >
{
};

template<>
struct Converter< ::QGraphicsItemAnimation > : ObjectTypeReferenceConverter< ::QGraphicsItemAnimation >
{
};

template<>
struct Converter< ::QTextDocument::ResourceType > : EnumConverter< ::QTextDocument::ResourceType >
{
};

template<>
struct Converter< ::QTextDocument::Stacks > : EnumConverter< ::QTextDocument::Stacks >
{
};

template<>
struct Converter< ::QTextDocument::FindFlag > : EnumConverter< ::QTextDocument::FindFlag >
{
};
template<>
struct Converter< ::QFlags<QTextDocument::FindFlag> > : QFlagsConverter< ::QFlags<QTextDocument::FindFlag> >
{
};

template<>
struct Converter< ::QTextDocument::MetaInformation > : EnumConverter< ::QTextDocument::MetaInformation >
{
};

template<>
struct Converter< ::QTextDocument* > : ObjectTypeConverter< ::QTextDocument >
{
};

template<>
struct Converter< ::QTextDocument > : ObjectTypeReferenceConverter< ::QTextDocument >
{
};

template<>
struct Converter< ::QMovie::CacheMode > : EnumConverter< ::QMovie::CacheMode >
{
};

template<>
struct Converter< ::QMovie::MovieState > : EnumConverter< ::QMovie::MovieState >
{
};

template<>
struct Converter< ::QMovie* > : ObjectTypeConverter< ::QMovie >
{
};

template<>
struct Converter< ::QMovie > : ObjectTypeReferenceConverter< ::QMovie >
{
};

template<>
struct Converter< ::QImageWriter::ImageWriterError > : EnumConverter< ::QImageWriter::ImageWriterError >
{
};

template<>
struct Converter< ::QImageWriter* > : ObjectTypeConverter< ::QImageWriter >
{
};

template<>
struct Converter< ::QImageWriter > : ObjectTypeReferenceConverter< ::QImageWriter >
{
};

template<>
struct Converter< ::QImageReader::ImageReaderError > : EnumConverter< ::QImageReader::ImageReaderError >
{
};

template<>
struct Converter< ::QImageReader* > : ObjectTypeConverter< ::QImageReader >
{
};

template<>
struct Converter< ::QImageReader > : ObjectTypeReferenceConverter< ::QImageReader >
{
};

} // namespace Shiboken

// User defined converters --------------------------------------------
// Conversion rule for: QPixmap
namespace Shiboken {
inline bool Converter<QPixmap>::checkType(PyObject* pyObj)
{
    return ValueTypeConverter<QPixmap>::checkType(pyObj);
}

inline bool Converter<QPixmap>::isConvertible(PyObject* pyobj)
{
    if (ValueTypeConverter<QPixmap>::isConvertible(pyobj))
        return true;
    SbkObjectType* shiboType = reinterpret_cast<SbkObjectType*>(SbkType<QPixmap>());
    bool isVariant = Shiboken::Converter<QVariant>::checkType(pyobj);
    if (isVariant) {
        QVariant var(Shiboken::Converter<QVariant>::toCpp(pyobj));
        return var.type() == QVariant::Pixmap;
    } else if (Shiboken::Converter<QSize>::checkType(pyobj) || Shiboken::Converter<QString>::checkType(pyobj)) {
        return true;
    } else {
        return Shiboken::ObjectType::isExternalConvertible(shiboType, pyobj);
    }
    return false;

}

inline QPixmap Converter<QPixmap>::toCpp(PyObject* pyobj)
{
    SbkObjectType* shiboType = reinterpret_cast<SbkObjectType*>(SbkType<QPixmap>());
    bool isVariant = Converter<QVariant>::checkType(pyobj);
    if (isVariant) {
        QVariant var(Converter<QVariant>::toCpp(pyobj));
        return var.value<QPixmap>();
    } else if (Converter<QSize>::checkType(pyobj)) {
        return QPixmap(Shiboken::Converter<QSize >::toCpp(pyobj));
    } else if (Converter<QString>::checkType(pyobj)) {
        return QPixmap(Shiboken::Converter<QString >::toCpp(pyobj));
    } else if (Shiboken::ObjectType::isExternalConvertible(shiboType, pyobj) && Shiboken::ObjectType::hasExternalCppConversions(shiboType)) {
        QPixmap* cptr = reinterpret_cast<QPixmap*>(Shiboken::ObjectType::callExternalCppConversion(shiboType, pyobj));
        std::auto_ptr<QPixmap> cptr_auto_ptr(cptr);
        return *cptr;
    }

    return *Converter<QPixmap*>::toCpp(pyobj);
}

inline PyObject* Converter<QPixmap>::toPython(const QPixmap& cppObj)
{
    return ValueTypeConverter<QPixmap>::toPython(cppObj);
}
}
// Generated converters implemantations -------------------------------

inline bool Shiboken::Converter< ::QMatrix4x4 >::isConvertible(PyObject* pyobj)
{
    if (ValueTypeConverter< ::QMatrix4x4 >::isConvertible(pyobj))
        return true;
    SbkObjectType* shiboType = reinterpret_cast<SbkObjectType*>(SbkType< ::QMatrix4x4 >());
    return Shiboken::Converter< ::QMatrix >::checkType(pyobj)
         || Shiboken::Converter< ::QTransform >::checkType(pyobj)
         || (ObjectType::isExternalConvertible(shiboType, pyobj));
}

inline ::QMatrix4x4 Shiboken::Converter< ::QMatrix4x4 >::toCpp(PyObject* pyobj)
{
    if (PyObject_TypeCheck(pyobj, SbkType< ::QMatrix4x4 >()))
        return *Shiboken::Converter< ::QMatrix4x4* >::toCpp(pyobj);
    else if (Shiboken::Converter< ::QMatrix >::checkType(pyobj))
        return QMatrix4x4(Shiboken::Converter< ::QMatrix >::toCpp(pyobj));
    else if (Shiboken::Converter< ::QTransform >::checkType(pyobj))
        return QMatrix4x4(Shiboken::Converter< ::QTransform >::toCpp(pyobj));
    else
        return Shiboken::ValueTypeConverter< ::QMatrix4x4 >::toCpp(pyobj);
}

inline bool Shiboken::Converter< ::QVector4D >::isConvertible(PyObject* pyobj)
{
    if (ValueTypeConverter< ::QVector4D >::isConvertible(pyobj))
        return true;
    SbkObjectType* shiboType = reinterpret_cast<SbkObjectType*>(SbkType< ::QVector4D >());
    return Shiboken::Converter< ::QVector2D >::checkType(pyobj)
         || Shiboken::Converter< ::QVector3D >::checkType(pyobj)
         || (ObjectType::isExternalConvertible(shiboType, pyobj));
}

inline ::QVector4D Shiboken::Converter< ::QVector4D >::toCpp(PyObject* pyobj)
{
    if (PyObject_TypeCheck(pyobj, SbkType< ::QVector4D >()))
        return *Shiboken::Converter< ::QVector4D* >::toCpp(pyobj);
    else if (Shiboken::Converter< ::QVector2D >::checkType(pyobj))
        return QVector4D(Shiboken::Converter< ::QVector2D >::toCpp(pyobj));
    else if (Shiboken::Converter< ::QVector3D >::checkType(pyobj))
        return QVector4D(Shiboken::Converter< ::QVector3D >::toCpp(pyobj));
    else
        return Shiboken::ValueTypeConverter< ::QVector4D >::toCpp(pyobj);
}

inline bool Shiboken::Converter< ::QVector3D >::isConvertible(PyObject* pyobj)
{
    if (ValueTypeConverter< ::QVector3D >::isConvertible(pyobj))
        return true;
    SbkObjectType* shiboType = reinterpret_cast<SbkObjectType*>(SbkType< ::QVector3D >());
    return Shiboken::Converter< ::QVector2D >::checkType(pyobj)
         || (ObjectType::isExternalConvertible(shiboType, pyobj));
}

inline ::QVector3D Shiboken::Converter< ::QVector3D >::toCpp(PyObject* pyobj)
{
    if (PyObject_TypeCheck(pyobj, SbkType< ::QVector3D >()))
        return *Shiboken::Converter< ::QVector3D* >::toCpp(pyobj);
    else if (Shiboken::Converter< ::QVector2D >::checkType(pyobj))
        return QVector3D(Shiboken::Converter< ::QVector2D >::toCpp(pyobj));
    else
        return Shiboken::ValueTypeConverter< ::QVector3D >::toCpp(pyobj);
}

inline bool Shiboken::Converter< ::QKeySequence >::isConvertible(PyObject* pyobj)
{
    if (ValueTypeConverter< ::QKeySequence >::isConvertible(pyobj))
        return true;
    SbkObjectType* shiboType = reinterpret_cast<SbkObjectType*>(SbkType< ::QKeySequence >());
    return Shiboken::Converter< ::QKeySequence::StandardKey >::checkType(pyobj)
         || Shiboken::Converter< ::QString >::checkType(pyobj)
         || PyInt_Check(pyobj)
         || (ObjectType::isExternalConvertible(shiboType, pyobj));
}

inline ::QKeySequence Shiboken::Converter< ::QKeySequence >::toCpp(PyObject* pyobj)
{
    if (PyObject_TypeCheck(pyobj, SbkType< ::QKeySequence >()))
        return *Shiboken::Converter< ::QKeySequence* >::toCpp(pyobj);
    else if (Shiboken::Converter< ::QKeySequence::StandardKey >::checkType(pyobj))
        return QKeySequence(Shiboken::Converter< ::QKeySequence::StandardKey >::toCpp(pyobj));
    else if (Shiboken::Converter< ::QString >::checkType(pyobj))
        return QKeySequence(Shiboken::Converter< ::QString >::toCpp(pyobj));
    else if (PyInt_Check(pyobj))
        return QKeySequence(Shiboken::Converter< int >::toCpp(pyobj));
    else
        return Shiboken::ValueTypeConverter< ::QKeySequence >::toCpp(pyobj);
}

inline bool Shiboken::Converter< ::QCursor >::isConvertible(PyObject* pyobj)
{
    if (ValueTypeConverter< ::QCursor >::isConvertible(pyobj))
        return true;
    SbkObjectType* shiboType = reinterpret_cast<SbkObjectType*>(SbkType< ::QCursor >());
    return Shiboken::Converter< ::Qt::CursorShape >::checkType(pyobj)
         || PyLong_Check(pyobj)
         || Shiboken::Converter< ::QPixmap >::checkType(pyobj)
         || (ObjectType::isExternalConvertible(shiboType, pyobj));
}

inline ::QCursor Shiboken::Converter< ::QCursor >::toCpp(PyObject* pyobj)
{
    if (PyObject_TypeCheck(pyobj, SbkType< ::QCursor >()))
        return *Shiboken::Converter< ::QCursor* >::toCpp(pyobj);
    else if (Shiboken::Converter< ::Qt::CursorShape >::checkType(pyobj))
        return QCursor(Shiboken::Converter< ::Qt::CursorShape >::toCpp(pyobj));
    else if (PyLong_Check(pyobj))
        return QCursor(Shiboken::Converter< ::Qt::HANDLE >::toCpp(pyobj));
    else if (Shiboken::Converter< ::QPixmap >::checkType(pyobj))
        return QCursor(Shiboken::Converter< ::QPixmap >::toCpp(pyobj));
    else
        return Shiboken::ValueTypeConverter< ::QCursor >::toCpp(pyobj);
}

inline bool Shiboken::Converter< ::QPalette >::isConvertible(PyObject* pyobj)
{
    if (ValueTypeConverter< ::QPalette >::isConvertible(pyobj))
        return true;
    SbkObjectType* shiboType = reinterpret_cast<SbkObjectType*>(SbkType< ::QPalette >());
    return Shiboken::Converter< ::Qt::GlobalColor >::checkType(pyobj)
         || Shiboken::Converter< ::QColor >::checkType(pyobj)
         || (ObjectType::isExternalConvertible(shiboType, pyobj));
}

inline ::QPalette Shiboken::Converter< ::QPalette >::toCpp(PyObject* pyobj)
{
    if (PyObject_TypeCheck(pyobj, SbkType< ::QPalette >()))
        return *Shiboken::Converter< ::QPalette* >::toCpp(pyobj);
    else if (Shiboken::Converter< ::Qt::GlobalColor >::checkType(pyobj))
        return QPalette(Shiboken::Converter< ::Qt::GlobalColor >::toCpp(pyobj));
    else if (Shiboken::Converter< ::QColor >::checkType(pyobj))
        return QPalette(Shiboken::Converter< ::QColor >::toCpp(pyobj));
    else
        return Shiboken::ValueTypeConverter< ::QPalette >::toCpp(pyobj);
}

inline bool Shiboken::Converter< ::QPrinterInfo >::isConvertible(PyObject* pyobj)
{
    if (ValueTypeConverter< ::QPrinterInfo >::isConvertible(pyobj))
        return true;
    SbkObjectType* shiboType = reinterpret_cast<SbkObjectType*>(SbkType< ::QPrinterInfo >());
    return Shiboken::Converter< ::QPrinter >::checkType(pyobj)
         || (ObjectType::isExternalConvertible(shiboType, pyobj));
}

inline ::QPrinterInfo Shiboken::Converter< ::QPrinterInfo >::toCpp(PyObject* pyobj)
{
    if (PyObject_TypeCheck(pyobj, SbkType< ::QPrinterInfo >()))
        return *Shiboken::Converter< ::QPrinterInfo* >::toCpp(pyobj);
    else if (Shiboken::Converter< ::QPrinter >::checkType(pyobj))
        return QPrinterInfo(Shiboken::Converter< ::QPrinter >::toCpp(pyobj));
    else
        return Shiboken::ValueTypeConverter< ::QPrinterInfo >::toCpp(pyobj);
}

inline bool Shiboken::Converter< ::QFontMetricsF >::isConvertible(PyObject* pyobj)
{
    if (ValueTypeConverter< ::QFontMetricsF >::isConvertible(pyobj))
        return true;
    SbkObjectType* shiboType = reinterpret_cast<SbkObjectType*>(SbkType< ::QFontMetricsF >());
    return Shiboken::Converter< ::QFont >::checkType(pyobj)
         || Shiboken::Converter< ::QFontMetrics >::checkType(pyobj)
         || (ObjectType::isExternalConvertible(shiboType, pyobj));
}

inline ::QFontMetricsF Shiboken::Converter< ::QFontMetricsF >::toCpp(PyObject* pyobj)
{
    if (PyObject_TypeCheck(pyobj, SbkType< ::QFontMetricsF >()))
        return *Shiboken::Converter< ::QFontMetricsF* >::toCpp(pyobj);
    else if (Shiboken::Converter< ::QFont >::checkType(pyobj))
        return QFontMetricsF(Shiboken::Converter< ::QFont >::toCpp(pyobj));
    else if (Shiboken::Converter< ::QFontMetrics >::checkType(pyobj))
        return QFontMetricsF(Shiboken::Converter< ::QFontMetrics >::toCpp(pyobj));
    else
        return Shiboken::ValueTypeConverter< ::QFontMetricsF >::toCpp(pyobj);
}

inline bool Shiboken::Converter< ::QFontMetrics >::isConvertible(PyObject* pyobj)
{
    if (ValueTypeConverter< ::QFontMetrics >::isConvertible(pyobj))
        return true;
    SbkObjectType* shiboType = reinterpret_cast<SbkObjectType*>(SbkType< ::QFontMetrics >());
    return Shiboken::Converter< ::QFont >::checkType(pyobj)
         || (ObjectType::isExternalConvertible(shiboType, pyobj));
}

inline ::QFontMetrics Shiboken::Converter< ::QFontMetrics >::toCpp(PyObject* pyobj)
{
    if (PyObject_TypeCheck(pyobj, SbkType< ::QFontMetrics >()))
        return *Shiboken::Converter< ::QFontMetrics* >::toCpp(pyobj);
    else if (Shiboken::Converter< ::QFont >::checkType(pyobj))
        return QFontMetrics(Shiboken::Converter< ::QFont >::toCpp(pyobj));
    else
        return Shiboken::ValueTypeConverter< ::QFontMetrics >::toCpp(pyobj);
}

inline bool Shiboken::Converter< ::QFontInfo >::isConvertible(PyObject* pyobj)
{
    if (ValueTypeConverter< ::QFontInfo >::isConvertible(pyobj))
        return true;
    SbkObjectType* shiboType = reinterpret_cast<SbkObjectType*>(SbkType< ::QFontInfo >());
    return Shiboken::Converter< ::QFont >::checkType(pyobj)
         || (ObjectType::isExternalConvertible(shiboType, pyobj));
}

inline ::QFontInfo Shiboken::Converter< ::QFontInfo >::toCpp(PyObject* pyobj)
{
    if (PyObject_TypeCheck(pyobj, SbkType< ::QFontInfo >()))
        return *Shiboken::Converter< ::QFontInfo* >::toCpp(pyobj);
    else if (Shiboken::Converter< ::QFont >::checkType(pyobj))
        return QFontInfo(Shiboken::Converter< ::QFont >::toCpp(pyobj));
    else
        return Shiboken::ValueTypeConverter< ::QFontInfo >::toCpp(pyobj);
}

inline bool Shiboken::Converter< ::QFont >::isConvertible(PyObject* pyobj)
{
    if (ValueTypeConverter< ::QFont >::isConvertible(pyobj))
        return true;
    SbkObjectType* shiboType = reinterpret_cast<SbkObjectType*>(SbkType< ::QFont >());
    return Shiboken::Converter< ::QString >::checkType(pyobj)
         || (ObjectType::isExternalConvertible(shiboType, pyobj));
}

inline ::QFont Shiboken::Converter< ::QFont >::toCpp(PyObject* pyobj)
{
    if (PyObject_TypeCheck(pyobj, SbkType< ::QFont >()))
        return *Shiboken::Converter< ::QFont* >::toCpp(pyobj);
    else if (Shiboken::Converter< ::QString >::checkType(pyobj))
        return QFont(Shiboken::Converter< ::QString >::toCpp(pyobj));
    else
        return Shiboken::ValueTypeConverter< ::QFont >::toCpp(pyobj);
}

inline bool Shiboken::Converter< ::QPen >::isConvertible(PyObject* pyobj)
{
    if (ValueTypeConverter< ::QPen >::isConvertible(pyobj))
        return true;
    SbkObjectType* shiboType = reinterpret_cast<SbkObjectType*>(SbkType< ::QPen >());
    return Shiboken::Converter< ::Qt::PenStyle >::checkType(pyobj)
         || Shiboken::Converter< ::QColor >::checkType(pyobj)
         || (ObjectType::isExternalConvertible(shiboType, pyobj));
}

inline ::QPen Shiboken::Converter< ::QPen >::toCpp(PyObject* pyobj)
{
    if (PyObject_TypeCheck(pyobj, SbkType< ::QPen >()))
        return *Shiboken::Converter< ::QPen* >::toCpp(pyobj);
    else if (Shiboken::Converter< ::Qt::PenStyle >::checkType(pyobj))
        return QPen(Shiboken::Converter< ::Qt::PenStyle >::toCpp(pyobj));
    else if (Shiboken::Converter< ::QColor >::checkType(pyobj))
        return QPen(Shiboken::Converter< ::QColor >::toCpp(pyobj));
    else
        return Shiboken::ValueTypeConverter< ::QPen >::toCpp(pyobj);
}

inline bool Shiboken::Converter< ::QTextOption >::isConvertible(PyObject* pyobj)
{
    if (ValueTypeConverter< ::QTextOption >::isConvertible(pyobj))
        return true;
    SbkObjectType* shiboType = reinterpret_cast<SbkObjectType*>(SbkType< ::QTextOption >());
    return Shiboken::Converter< ::QFlags<Qt::AlignmentFlag> >::checkType(pyobj)
         || (ObjectType::isExternalConvertible(shiboType, pyobj));
}

inline ::QTextOption Shiboken::Converter< ::QTextOption >::toCpp(PyObject* pyobj)
{
    if (PyObject_TypeCheck(pyobj, SbkType< ::QTextOption >()))
        return *Shiboken::Converter< ::QTextOption* >::toCpp(pyobj);
    else if (Shiboken::Converter< ::QFlags<Qt::AlignmentFlag> >::checkType(pyobj))
        return QTextOption(Shiboken::Converter< ::QFlags<Qt::AlignmentFlag> >::toCpp(pyobj));
    else
        return Shiboken::ValueTypeConverter< ::QTextOption >::toCpp(pyobj);
}

inline bool Shiboken::Converter< ::QTileRules >::isConvertible(PyObject* pyobj)
{
    if (ValueTypeConverter< ::QTileRules >::isConvertible(pyobj))
        return true;
    SbkObjectType* shiboType = reinterpret_cast<SbkObjectType*>(SbkType< ::QTileRules >());
    return Shiboken::Converter< ::Qt::TileRule >::checkType(pyobj)
         || (ObjectType::isExternalConvertible(shiboType, pyobj));
}

inline ::QTileRules Shiboken::Converter< ::QTileRules >::toCpp(PyObject* pyobj)
{
    if (PyObject_TypeCheck(pyobj, SbkType< ::QTileRules >()))
        return *Shiboken::Converter< ::QTileRules* >::toCpp(pyobj);
    else if (Shiboken::Converter< ::Qt::TileRule >::checkType(pyobj))
        return QTileRules(Shiboken::Converter< ::Qt::TileRule >::toCpp(pyobj));
    else
        return Shiboken::ValueTypeConverter< ::QTileRules >::toCpp(pyobj);
}

inline bool Shiboken::Converter< ::QBrush >::isConvertible(PyObject* pyobj)
{
    if (ValueTypeConverter< ::QBrush >::isConvertible(pyobj))
        return true;
    SbkObjectType* shiboType = reinterpret_cast<SbkObjectType*>(SbkType< ::QBrush >());
    return Shiboken::Converter< ::Qt::BrushStyle >::checkType(pyobj)
         || Shiboken::Converter< ::Qt::GlobalColor >::checkType(pyobj)
         || Shiboken::Converter< ::QColor >::checkType(pyobj)
         || Shiboken::Converter< ::QGradient >::checkType(pyobj)
         || Shiboken::Converter< ::QImage >::checkType(pyobj)
         || Shiboken::Converter< ::QPixmap >::checkType(pyobj)
         || (ObjectType::isExternalConvertible(shiboType, pyobj));
}

inline ::QBrush Shiboken::Converter< ::QBrush >::toCpp(PyObject* pyobj)
{
    if (PyObject_TypeCheck(pyobj, SbkType< ::QBrush >()))
        return *Shiboken::Converter< ::QBrush* >::toCpp(pyobj);
    else if (Shiboken::Converter< ::Qt::BrushStyle >::checkType(pyobj))
        return QBrush(Shiboken::Converter< ::Qt::BrushStyle >::toCpp(pyobj));
    else if (Shiboken::Converter< ::Qt::GlobalColor >::checkType(pyobj))
        return QBrush(Shiboken::Converter< ::Qt::GlobalColor >::toCpp(pyobj));
    else if (Shiboken::Converter< ::QColor >::checkType(pyobj))
        return QBrush(Shiboken::Converter< ::QColor >::toCpp(pyobj));
    else if (Shiboken::Converter< ::QGradient >::checkType(pyobj))
        return QBrush(Shiboken::Converter< ::QGradient >::toCpp(pyobj));
    else if (Shiboken::Converter< ::QImage >::checkType(pyobj))
        return QBrush(Shiboken::Converter< ::QImage >::toCpp(pyobj));
    else if (Shiboken::Converter< ::QPixmap >::checkType(pyobj))
        return QBrush(Shiboken::Converter< ::QPixmap >::toCpp(pyobj));
    else
        return Shiboken::ValueTypeConverter< ::QBrush >::toCpp(pyobj);
}

inline bool Shiboken::Converter< ::QPolygonF >::isConvertible(PyObject* pyobj)
{
    if (ValueTypeConverter< ::QPolygonF >::isConvertible(pyobj))
        return true;
    SbkObjectType* shiboType = reinterpret_cast<SbkObjectType*>(SbkType< ::QPolygonF >());
    return Shiboken::Converter< ::QPolygon >::checkType(pyobj)
         || Shiboken::Converter< ::QRectF >::checkType(pyobj)
         || Shiboken::Converter< ::QVector<QPointF > >::checkType(pyobj)
         || PyInt_Check(pyobj)
         || (ObjectType::isExternalConvertible(shiboType, pyobj));
}

inline ::QPolygonF Shiboken::Converter< ::QPolygonF >::toCpp(PyObject* pyobj)
{
    if (PyObject_TypeCheck(pyobj, SbkType< ::QPolygonF >()))
        return *Shiboken::Converter< ::QPolygonF* >::toCpp(pyobj);
    else if (Shiboken::Converter< ::QPolygon >::checkType(pyobj))
        return QPolygonF(Shiboken::Converter< ::QPolygon >::toCpp(pyobj));
    else if (Shiboken::Converter< ::QRectF >::checkType(pyobj))
        return QPolygonF(Shiboken::Converter< ::QRectF >::toCpp(pyobj));
    else if (Shiboken::Converter< ::QVector<QPointF > >::checkType(pyobj))
        return QPolygonF(Shiboken::Converter< ::QVector<QPointF > >::toCpp(pyobj));
    else if (PyInt_Check(pyobj))
        return QPolygonF(Shiboken::Converter< int >::toCpp(pyobj));
    else
        return Shiboken::ValueTypeConverter< ::QPolygonF >::toCpp(pyobj);
}

inline bool Shiboken::Converter< ::QPolygon >::isConvertible(PyObject* pyobj)
{
    if (ValueTypeConverter< ::QPolygon >::isConvertible(pyobj))
        return true;
    SbkObjectType* shiboType = reinterpret_cast<SbkObjectType*>(SbkType< ::QPolygon >());
    return Shiboken::Converter< ::QRect >::checkType(pyobj)
         || Shiboken::Converter< ::QVector<QPoint > >::checkType(pyobj)
         || PyInt_Check(pyobj)
         || (ObjectType::isExternalConvertible(shiboType, pyobj));
}

inline ::QPolygon Shiboken::Converter< ::QPolygon >::toCpp(PyObject* pyobj)
{
    if (PyObject_TypeCheck(pyobj, SbkType< ::QPolygon >()))
        return *Shiboken::Converter< ::QPolygon* >::toCpp(pyobj);
    else if (Shiboken::Converter< ::QRect >::checkType(pyobj))
        return QPolygon(Shiboken::Converter< ::QRect >::toCpp(pyobj));
    else if (Shiboken::Converter< ::QVector<QPoint > >::checkType(pyobj))
        return QPolygon(Shiboken::Converter< ::QVector<QPoint > >::toCpp(pyobj));
    else if (PyInt_Check(pyobj))
        return QPolygon(Shiboken::Converter< int >::toCpp(pyobj));
    else
        return Shiboken::ValueTypeConverter< ::QPolygon >::toCpp(pyobj);
}

inline bool Shiboken::Converter< ::QColor >::isConvertible(PyObject* pyobj)
{
    if (ValueTypeConverter< ::QColor >::isConvertible(pyobj))
        return true;
    SbkObjectType* shiboType = reinterpret_cast<SbkObjectType*>(SbkType< ::QColor >());
    return Shiboken::Converter< ::Qt::GlobalColor >::checkType(pyobj)
         || Shiboken::Converter< ::QString >::checkType(pyobj)
         || PyInt_Check(pyobj)
         || (ObjectType::isExternalConvertible(shiboType, pyobj));
}

inline ::QColor Shiboken::Converter< ::QColor >::toCpp(PyObject* pyobj)
{
    if (PyObject_TypeCheck(pyobj, SbkType< ::QColor >()))
        return *Shiboken::Converter< ::QColor* >::toCpp(pyobj);
    else if (Shiboken::Converter< ::Qt::GlobalColor >::checkType(pyobj))
        return QColor(Shiboken::Converter< ::Qt::GlobalColor >::toCpp(pyobj));
    else if (Shiboken::Converter< ::QString >::checkType(pyobj))
        return QColor(Shiboken::Converter< ::QString >::toCpp(pyobj));
    else if (PyInt_Check(pyobj))
        return QColor(Shiboken::Converter< unsigned int >::toCpp(pyobj));
    else
        return Shiboken::ValueTypeConverter< ::QColor >::toCpp(pyobj);
}

inline bool Shiboken::Converter< ::QBitmap >::isConvertible(PyObject* pyobj)
{
    if (ValueTypeConverter< ::QBitmap >::isConvertible(pyobj))
        return true;
    SbkObjectType* shiboType = reinterpret_cast<SbkObjectType*>(SbkType< ::QBitmap >());
    return Shiboken::Converter< ::QPixmap >::checkType(pyobj)
         || (ObjectType::isExternalConvertible(shiboType, pyobj));
}

inline ::QBitmap Shiboken::Converter< ::QBitmap >::toCpp(PyObject* pyobj)
{
    if (PyObject_TypeCheck(pyobj, SbkType< ::QBitmap >()))
        return *Shiboken::Converter< ::QBitmap* >::toCpp(pyobj);
    else if (Shiboken::Converter< ::QPixmap >::checkType(pyobj))
        return QBitmap(Shiboken::Converter< ::QPixmap >::toCpp(pyobj));
    else
        return Shiboken::ValueTypeConverter< ::QBitmap >::toCpp(pyobj);
}

inline bool Shiboken::Converter< ::QIcon >::isConvertible(PyObject* pyobj)
{
    if (ValueTypeConverter< ::QIcon >::isConvertible(pyobj))
        return true;
    SbkObjectType* shiboType = reinterpret_cast<SbkObjectType*>(SbkType< ::QIcon >());
    return Shiboken::Converter< ::QPixmap >::checkType(pyobj)
         || (ObjectType::isExternalConvertible(shiboType, pyobj));
}

inline ::QIcon Shiboken::Converter< ::QIcon >::toCpp(PyObject* pyobj)
{
    if (PyObject_TypeCheck(pyobj, SbkType< ::QIcon >()))
        return *Shiboken::Converter< ::QIcon* >::toCpp(pyobj);
    else if (Shiboken::Converter< ::QPixmap >::checkType(pyobj))
        return QIcon(Shiboken::Converter< ::QPixmap >::toCpp(pyobj));
    else
        return Shiboken::ValueTypeConverter< ::QIcon >::toCpp(pyobj);
}

inline bool Shiboken::Converter< ::QRegion >::isConvertible(PyObject* pyobj)
{
    if (ValueTypeConverter< ::QRegion >::isConvertible(pyobj))
        return true;
    SbkObjectType* shiboType = reinterpret_cast<SbkObjectType*>(SbkType< ::QRegion >());
    return Shiboken::Converter< ::QBitmap >::checkType(pyobj)
         || Shiboken::Converter< ::QPolygon >::checkType(pyobj)
         || Shiboken::Converter< ::QRect >::checkType(pyobj)
         || (ObjectType::isExternalConvertible(shiboType, pyobj));
}

inline ::QRegion Shiboken::Converter< ::QRegion >::toCpp(PyObject* pyobj)
{
    if (PyObject_TypeCheck(pyobj, SbkType< ::QRegion >()))
        return *Shiboken::Converter< ::QRegion* >::toCpp(pyobj);
    else if (Shiboken::Converter< ::QBitmap >::checkType(pyobj))
        return QRegion(Shiboken::Converter< ::QBitmap >::toCpp(pyobj));
    else if (Shiboken::Converter< ::QPolygon >::checkType(pyobj))
        return QRegion(Shiboken::Converter< ::QPolygon >::toCpp(pyobj));
    else if (Shiboken::Converter< ::QRect >::checkType(pyobj))
        return QRegion(Shiboken::Converter< ::QRect >::toCpp(pyobj));
    else
        return Shiboken::ValueTypeConverter< ::QRegion >::toCpp(pyobj);
}

inline bool Shiboken::Converter< ::QTouchEvent::TouchPoint >::isConvertible(PyObject* pyobj)
{
    if (ValueTypeConverter< ::QTouchEvent::TouchPoint >::isConvertible(pyobj))
        return true;
    SbkObjectType* shiboType = reinterpret_cast<SbkObjectType*>(SbkType< ::QTouchEvent::TouchPoint >());
    return PyInt_Check(pyobj)
         || (ObjectType::isExternalConvertible(shiboType, pyobj));
}

inline ::QTouchEvent::TouchPoint Shiboken::Converter< ::QTouchEvent::TouchPoint >::toCpp(PyObject* pyobj)
{
    if (PyObject_TypeCheck(pyobj, SbkType< ::QTouchEvent::TouchPoint >()))
        return *Shiboken::Converter< ::QTouchEvent::TouchPoint* >::toCpp(pyobj);
    else if (PyInt_Check(pyobj))
        return QTouchEvent::TouchPoint(Shiboken::Converter< int >::toCpp(pyobj));
    else
        return Shiboken::ValueTypeConverter< ::QTouchEvent::TouchPoint >::toCpp(pyobj);
}


#endif // SBK_QTGUI_PYTHON_H

