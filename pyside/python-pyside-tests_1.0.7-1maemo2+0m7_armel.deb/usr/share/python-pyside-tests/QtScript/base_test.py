from PySide import QtScript


#only test if the module import works fine bug #278
