class PysideImportTest2(object):
    pass
