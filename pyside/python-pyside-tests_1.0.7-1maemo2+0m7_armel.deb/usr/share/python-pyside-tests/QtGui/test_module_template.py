from PySide.QtGui import *
from PySide.QtCore import *

class MyQObject(QObject):
    pass

class MyQWidget(QWidget):
    value = 10

