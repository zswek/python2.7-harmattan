<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="lt">
<defaultcodec></defaultcodec>
<context>
    <name>QObject</name>
    <message>
        <source>Hello World!</source>
        <translation>Orbis, te saluto!</translation>
    </message>
</context>
</TS>
