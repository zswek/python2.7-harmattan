<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="ru">
<defaultcodec></defaultcodec>
<context>
    <name>QObject</name>
    <message>
        <source>Hello World!</source>
        <translation>привет мир!</translation>
    </message>
</context>
</TS>
